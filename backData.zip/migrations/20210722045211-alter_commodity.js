'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all ([
      queryInterface.addColumn('commodity', 'buyer_min_qty', {
        type: Sequelize.FLOAT,
        allowNull:true
      }),
      queryInterface.addColumn('commodity', 'seller_min_qty', {
        type: Sequelize.FLOAT,
        allowNull:true
      }),
      
     
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      
    ]);
  }
};
