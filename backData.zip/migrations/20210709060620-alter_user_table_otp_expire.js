module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('users', 'otp_sent_at', {
        type: Sequelize.DATE,
        allowNull:true
      }),
      
     
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      
    ]);
  }
};