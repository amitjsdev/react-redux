'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all ([
      queryInterface.addColumn('purchase_order', 'tax', {
        type: Sequelize.STRING,
        allowNull:true
      }),
      queryInterface.addColumn('purchase_order', 'total', {
        type: Sequelize.FLOAT,
        allowNull:true
      }),
      
     
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      
    ]);
  }
};
