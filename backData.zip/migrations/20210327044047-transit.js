'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('transit', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      buyer_contact_person: {
        type: Sequelize.STRING
      },
      buyer_contact_number: {
        type: Sequelize.STRING
      },
      buyer_address: {
        type: Sequelize.TEXT
      },
      delivery_acceptance: {
        type: Sequelize.STRING
      },
       seller_contact_person: {
        type: Sequelize.STRING
      },
      seller_contact_number: {
        type: Sequelize.STRING
      },
      tracking_number: {
        type: Sequelize.STRING
      },
      vehicle_number: {
        type: Sequelize.STRING
      },
      transit_address: {
        type: Sequelize.TEXT
      },
      transit_status: {
        type: Sequelize.STRING
      },
      
      tradeId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'trade',
          key: 'id'
        },
      },
      

      status: {
        type: Sequelize.INTEGER,
        defaultValue: 1,
        comment: "1=>active,0=>deactive"
      },
      
      createdBy: {
        type: Sequelize.INTEGER
      },
      updatedBy: {
        type: Sequelize.INTEGER
      },
      expected_delivery_date: {
        allowNull: true,
        type: Sequelize.DATE
      },
      delivery_initiated_date: {
        allowNull: true,
        type: Sequelize.DATE
      },
      delivery_date: {
        allowNull: true,
        type: Sequelize.DATE
      },createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('transit');
  }
};
