'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('payment', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      mode: {
        type: Sequelize.STRING
      },
      amount: {
        type: Sequelize.FLOAT
      },
      commision: {
        type: Sequelize.FLOAT
      },
       tax: {
        type: Sequelize.FLOAT
      },
       total: {
        type: Sequelize.FLOAT
      },
      
      tradeId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'trade',
          key: 'id'
        },
      },
      

      status: {
        type: Sequelize.INTEGER,
        defaultValue: 1,
        comment: "1=>active,0=>deactive"
      },
      
      createdBy: {
        type: Sequelize.INTEGER
      },
      updatedBy: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('payment');
  }
};
