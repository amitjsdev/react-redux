module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('purchase_order', 'qid', {
        type: Sequelize.INTEGER,
        allowNull:true,
      }),
      queryInterface.removeColumn ('purchase_order', 'tradeId'),
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      
    ]);
  }
};