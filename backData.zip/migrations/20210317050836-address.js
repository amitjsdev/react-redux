'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('address', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      type: {
        type: Sequelize.STRING,
      },
       address1: {
        type: Sequelize.STRING,
      },
       address2: {
        type: Sequelize.STRING,
      },
       city: {
        type: Sequelize.STRING,
      },
       district: {
        type: Sequelize.STRING,
      },
       state: {
        type: Sequelize.STRING,
      },
       country: {
        type: Sequelize.STRING,
      },
       zip: {
        type: Sequelize.STRING,
      },
       lat: {
        type: Sequelize.STRING,
      },
      lng: {
        type: Sequelize.STRING,
      },
      userId:{
        type: Sequelize.INTEGER,
        references: { model: 'users', key: 'id' }
      },
      status: {
        type: Sequelize.INTEGER,
        defaultValue: 1,
        comment: "1=>active,0=>deactive"
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      createdBy:{
        type: Sequelize.INTEGER,
      },
      updatedBy:{
        type: Sequelize.INTEGER,
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('address');
  }
};
