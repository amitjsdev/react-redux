module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('purchase_order', 'canceledAt', {
        type: Sequelize.DATE,
        allowNull:true,
      }),
     
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      
    ]);
  }
};