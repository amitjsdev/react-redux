module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('purchase_order', 'acceptedAt', {
        type: Sequelize.DATE,
        allowNull:true,
      }),
      queryInterface.addColumn('purchase_order', 'rejectedAt', {
        type: Sequelize.DATE,
        allowNull:true,
      }),
      queryInterface.addColumn('purchase_order', 'submittedAt', {
        type: Sequelize.DATE,
        allowNull:true,
      }),
     
     
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      
    ]);
  }
};