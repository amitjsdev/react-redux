module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('transactions', 'tId', {
        type: Sequelize.STRING,
        allowNull:true
      }),
      queryInterface.addColumn('transactions', 'qid', {
        type: Sequelize.STRING,
        allowNull:true
      }),
      
     
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      
    ]);
  }
};