module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('qoutes', 'qoutes_status', {
        type: Sequelize.STRING,
        defaultValue:'active'
      }),
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('qoutes', 'qoutes_status'),
    ]);
  }
};