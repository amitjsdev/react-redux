'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('purchase_order', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      buyer_comment: {
        type: Sequelize.TEXT
      },
      seller_comment: {
        type: Sequelize.TEXT
      },
      seller_response: {
        type: Sequelize.STRING
      },
      seller_response_date: {
        type: Sequelize.DATE
      },
      
      tradeId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'trade',
          key: 'id'
        },
      },

      status: {
        type: Sequelize.INTEGER,
        defaultValue: 1,
        comment: "1=>active,0=>deactive"
      },
      
      createdBy: {
        type: Sequelize.INTEGER
      },
      updatedBy: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('purchase_order');
  }
};
