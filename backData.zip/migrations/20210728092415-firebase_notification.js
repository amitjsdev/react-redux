module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.createTable('firebase_token', {
        id: {
          allowNull: false,
          autoIncrement: true,
          primaryKey: true,
          type: Sequelize.INTEGER
        },
        userId: {
          type: Sequelize.INTEGER,
          allowNull: true
        },
        token: {
          type: Sequelize.STRING,
        },
       
        mobile: {
          type: Sequelize.STRING,
          allowNull: true
        },
         createdAt: {
          allowNull: false,
          type: Sequelize.DATE
        },
        updatedAt: {
          allowNull: false,
          type: Sequelize.DATE
        }
      })

    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([

    ]);
  }
};