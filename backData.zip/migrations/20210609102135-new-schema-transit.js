module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.dropTable('transit'),
      queryInterface.createTable('transit', {
        id: {
          allowNull: false,
          autoIncrement: true,
          primaryKey: true,
          type: Sequelize.INTEGER
        },


        qid: {
          type: Sequelize.INTEGER,
        },
        seller_id: {
          type: Sequelize.INTEGER,
        },
        buyer_id: {
          type: Sequelize.INTEGER,
        },
        vehical: {
          type: Sequelize.STRING,
          allowNull: true
        },
        tracking_number: {
          type: Sequelize.STRING,
          allowNull: true
        },
        initiated: {
          type: Sequelize.DATE,
          allowNull: true
        },
        expected: {
          type: Sequelize.DATE,
          allowNull: true
        },
        delivery_date: {
          type: Sequelize.DATE,
          allowNull: true
        },
        comment: {
          type: Sequelize.STRING,
          allowNull: true
        },
        transit_status: {
          type: Sequelize.STRING,
          allowNull: true
        },
        status: {
          type: Sequelize.INTEGER,
          defaultValue: 1,
        },

        createdBy: {
          allowNull: false,
          type: Sequelize.INTEGER
        },
        updatedBy: {
          allowNull: false,
          type: Sequelize.INTEGER
        },
         createdAt: {
          allowNull: false,
          type: Sequelize.DATE
        },
        updatedAt: {
          allowNull: false,
          type: Sequelize.DATE
        }
      })

    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([

    ]);
  }
};