module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('qoutes', 'acceptedAt', {
        type: Sequelize.DATE,
        allowNull:true,
      }),
      queryInterface.removeColumn('qoutes', 'qoutes_status'),
     
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      
    ]);
  }
};