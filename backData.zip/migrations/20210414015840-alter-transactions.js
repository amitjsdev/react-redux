module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('transactions', 'commision', {
        type: Sequelize.FLOAT,
        allowNull:true,
      }),
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('transactions', 'commision'),
    ]);
  }
};