module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('trade', 'is_rejected', {
        type: Sequelize.BOOLEAN,
        allowNull:true
      }),
        queryInterface.addColumn('trade', 'is_canceled', {
        type: Sequelize.BOOLEAN,
        allowNull:true
      }),
       queryInterface.addColumn('trade', 'rejected_at', {
        type: Sequelize.DATE,
        allowNull:true
      }),
        queryInterface.addColumn('trade', 'canceled_at', {
        type: Sequelize.DATE,
        allowNull:true
      }),
      
     
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      
    ]);
  }
};