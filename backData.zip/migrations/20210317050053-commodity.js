'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('commodity', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING,
        unique: true
      },
       description: {
        type: Sequelize.STRING,
      },
       other: {
        type: Sequelize.STRING,
      },
      max_price: {
        type: Sequelize.FLOAT,
        default: 0,
      },
      min_price: {
        type: Sequelize.FLOAT,
        default: 0,
      },
      nodal_price: {
        type: Sequelize.FLOAT,
        default: 0,
      },
      buyer_min_qty: {
        type: Sequelize.FLOAT,
        default: 0,
      },
      seller_min_qty: {
        type: Sequelize.FLOAT,
        default: 0,
      },
      type: {
        type: Sequelize.STRING
      },
     
      status: {
        type: Sequelize.INTEGER,
        defaultValue: 1,
        comment: "1=>active,0=>deactive"
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      createdBy:{
        type: Sequelize.INTEGER,
      },
      updatedBy:{
        type: Sequelize.INTEGER,
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('commodity');
  }
};
