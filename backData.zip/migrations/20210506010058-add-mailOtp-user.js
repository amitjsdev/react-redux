module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('users', 'mailOtp', {
        type: Sequelize.INTEGER,
        allowNull:true,
      }),
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('users', 'mailOtp'),
    ]);
  }
};