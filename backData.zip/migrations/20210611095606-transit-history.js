'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('transit_history', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },


      transitId: {
        type: Sequelize.INTEGER,
      },
      comment: {
        type: Sequelize.STRING,
      },
      expected: {
        type: Sequelize.DATE,
      },
      delivery_date: {
        type: Sequelize.DATE,
      },
      vehical: {
        type: Sequelize.STRING,
      },
      tracking_number: {
        type: Sequelize.STRING,
      },

      status: {
        type: Sequelize.INTEGER,
        defaultValue: 1,
        
      },
      createdBy: {
        type: Sequelize.INTEGER,
        allowNull:true
        
      },

      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('transit_history');
  }
};
