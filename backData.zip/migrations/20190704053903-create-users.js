'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('users', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      userName: {
        type: Sequelize.STRING
      },
       first_name: {
        type: Sequelize.STRING
      },
       last_name: {
        type: Sequelize.STRING
      },
      email: {
        type: Sequelize.STRING,
        unique: true
      },
      password: {
        type: Sequelize.STRING
      },
     
      mobile: {
        type: Sequelize.BIGINT,
        unique: true

      },
      otp: {
        type: Sequelize.BIGINT
      },
      dob: {
        type: Sequelize.DATE
      },
      userRoleId: {
        type: Sequelize.INTEGER,
        defaultValue: 1,
      },
      status: {
        type: Sequelize.INTEGER,
        defaultValue: 1,
        comment: "1=>approved,0=>deactive,2=>rejected,3=>pending"
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('users');
  }
};
