module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('qoutes', 'quantity', {
        type: Sequelize.INTEGER,
        allowNull:true,
        defaultValue:1
      }),
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      
    ]);
  }
};