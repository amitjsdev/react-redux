'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('units', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      
     
      name:{
        type: Sequelize.STRING,
      },
      
      minimum_required: {
        type: Sequelize.INTEGER,
        allowNull:true
      },
       minimum: {
        type: Sequelize.INTEGER,
        allowNull:true
      },

      status: {
        type: Sequelize.INTEGER,
        defaultValue: 1,
        comment: "1=>active,0=>deactive"
      },
      
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('tax');
  }
};
