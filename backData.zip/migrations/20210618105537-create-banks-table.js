module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.createTable('banks', {
        id: {
          allowNull: false,
          autoIncrement: true,
          primaryKey: true,
          type: Sequelize.INTEGER
        },
        user_id: {
          type: Sequelize.INTEGER,
        },
        holder_name: {
          type: Sequelize.STRING,
        },
        account_number: {
          type: Sequelize.STRING,
        },
        bank: {
          type: Sequelize.STRING,
        },
        ifsc: {
          type: Sequelize.STRING,
        },
        swift: {
          type: Sequelize.STRING,
          allowNull: true
        },
        status: {
          type: Sequelize.INTEGER,
          defaultValue: 1,
        },

        createdBy: {
          allowNull: true,
          type: Sequelize.INTEGER
        },
        updatedBy: {
          allowNull: true,
          type: Sequelize.INTEGER
        },
         createdAt: {
          allowNull: false,
          type: Sequelize.DATE
        },
        updatedAt: {
          allowNull: false,
          type: Sequelize.DATE
        }
      })

    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([

    ]);
  }
};