module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('payment', 'sellerId', {
        type: Sequelize.INTEGER
        ,
        references: {
          model: 'users',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      }),
      queryInterface.addColumn('payment', 'buyerId', {
        type: Sequelize.INTEGER
        ,
        references: {
          model: 'users',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      }),
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('payment', 'sellerId'),
      queryInterface.removeColumn('payment', 'buyerId'),
    ]);
  }
};