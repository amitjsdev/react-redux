module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('purchase_order', 'seller_id', {
        type: Sequelize.INTEGER,
        allowNull:true,
      }),
      queryInterface.addColumn('purchase_order', 'buyer_id', {
        type: Sequelize.INTEGER,
        allowNull:true,
      }),
     
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      
    ]);
  }
};