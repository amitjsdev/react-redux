module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('commodity', 'attributes', {
        type: Sequelize.JSON,
        allowNull:true,
      }),
       queryInterface.addColumn('commodity', 'certifications', {
        type: Sequelize.JSON,
        allowNull:true,
      }),
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('commodity', 'attributes'),
      queryInterface.removeColumn('commodity', 'certifications'),
    ]);
  }
};