module.exports = {
  up: function (queryInterface, Sequelize) {
    return Promise.all ([
      queryInterface.addColumn('payment', 'qid', {
        type: Sequelize.INTEGER,
      }),
      queryInterface.removeColumn('payment', 'tradeId'),
     
    ]);
  },

  down: function (queryInterface, Sequelize) {
    return Promise.all([
      
    ]);
  }
};