const db = require('../models');
const jwtDecode = require('jwt-decode');

var checkUserPermission = async function (req, res, next) {
    try {
        var allow = false;
        if (req.headers.authorization && req.headers.authorization.split(' ')[0] === 'Bearer') {
            var token = req.headers.authorization.split(' ')[1];
            var user = jwtDecode(token);
            var userRoleId = user.userRoleId;
            var records = await db.user_permission_actions.findAll({
                where: {
                    userRoleId: userRoleId
                },
                raw: true
            });

            if (records && records.length === 0) {
                return res.status(403).json({ "success": false, "message": "Not authorised to perform this action", "status": 403 });
            } else {
                records.forEach(record => {
                    if (req.method == 'POST' && record.action == 'Add') {
                        allow = true;
                    } else if (req.method == 'GET' && record.action == 'View') {
                        allow = true;
                    }
                    else if (req.method == 'PUT' && record.action == 'Edit') {
                        allow = true;
                    }
                    else if (req.method == 'DELETE' && record.action == 'Delete') {
                        allow = true;
                    }
                    else if (req.method == 'POST' && record.action == 'Transfer/Deligate') {
                        allow = true;
                    }
                });
                if (allow) {
                    next();
                } else {
                    res.status(403).json({ "success": false, "message": "Not authorised to perform this action", "status": 403 })
                }
            }
        } else {
            return res.status(500).json({ "success": false, "message": "Access token is empty", "status": 500 });
        }


    } catch (e) {
        return res.status(500).json({ "success": false, "message": e.message, "status": 500 });

    }
};
module.exports = checkUserPermission;