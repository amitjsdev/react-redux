const express = require('express');
const router = express.Router();

const poController = require('../../../controllers/poController');

router.get('/qoute/:id', poController.getQoutePO);
router.get('/trade/:id', poController.getTradePO);
router.get('/:id', poController.getItemById);
router.put('/:id',  poController.updateItem);
router.delete('/:id',  poController.deleteItem);
router.post('/',  poController.validate('new'), poController.createNewItem);

module.exports = router;
