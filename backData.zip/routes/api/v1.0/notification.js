const express = require('express');
const router = express.Router();
const notificationController = require('../../../controllers/notificationController');

router.get('/', notificationController.getNotification);

router.put('/markRead',notificationController.markNotificationsRead);

router.put('/markUnRead',notificationController.markNotificationsUnRead);
router.get('/unreadCount',notificationController.getNotificationsUnReadCount);
router.get('/unread',notificationController.getNotificationsUnRead);
module.exports = router;