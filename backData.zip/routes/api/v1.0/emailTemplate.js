const express = require('express');
const router = express.Router();

const emailTemplateController = require('../../../controllers/emailTemplateControllers');

router.get('/', emailTemplateController.getAllItems);
router.get('/:id', emailTemplateController.getItemById);
router.put('/:id',  emailTemplateController.updateItem);
router.delete('/:id',  emailTemplateController.deleteItem);
router.post('/',  emailTemplateController.validate('new'), emailTemplateController.createNewItem);

module.exports = router;
