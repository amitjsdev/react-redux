const express = require('express');
const router = express.Router();
const fileController = require('../../../controllers/filesController');
const locationController = require('../../../controllers/locationController');
const masterDataController = require('../../../controllers/masterDataController');
router.get('/file/:id', fileController.getFile);

router.get('/countries/:id', locationController.getState);
router.get('/state/:id', locationController.getCity);
router.get('/countries', locationController.countries);
router.get('/roles', locationController.getRoles);
router.get('/entity', locationController.getEntityType);
router.get('/tradestatus', masterDataController.tradestatus);
router.get('/transitstatus', masterDataController.transitStatus);
router.get('/taxes', masterDataController.getTaxes);
router.get('/units', masterDataController.Unites);
module.exports = router;
