const express = require('express');
const router = express.Router();

const emailNotificationController = require('../../../controllers/emailNotificationControllers');

router.get('/', emailNotificationController.getAllItems);
router.get('/:id', emailNotificationController.getItemById);
router.put('/:id',  emailNotificationController.updateItem);
router.delete('/:id',  emailNotificationController.deleteItem);
router.post('/',  emailNotificationController.validate('new'), emailNotificationController.createNewItem);

module.exports = router;
