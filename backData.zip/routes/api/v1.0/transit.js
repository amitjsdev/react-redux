const express = require('express');
const router = express.Router();

const transitController = require('../../../controllers/transitController');

router.get('/qoute/:id', transitController.getQouteTransit);
router.get('/trade/:id', transitController.getTradeTransit);
router.get('/:id', transitController.getItemById);
router.put('/:id',  transitController.updateItem);
router.delete('/:id',  transitController.deleteItem);
router.post('/',  transitController.validate('new'), transitController.createNewItem);

module.exports = router;
