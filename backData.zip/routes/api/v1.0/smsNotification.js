const express = require('express');
const router = express.Router();

const smsNotificationController = require('../../../controllers/smsNotificationControllers');

router.get('/', smsNotificationController.getAllItems);
router.get('/:id', smsNotificationController.getItemById);
router.put('/:id',  smsNotificationController.updateItem);
router.delete('/:id',  smsNotificationController.deleteItem);
router.post('/',  smsNotificationController.validate('new'), smsNotificationController.createNewItem);

module.exports = router;
