const express = require('express');
const router = express.Router();

const settingsController = require('../../../controllers/settingsController');

router.get('/', settingsController.getAllItems);
router.get('/:id', settingsController.getItemById);
router.put('/:id',  settingsController.updateItem);
router.delete('/:id',  settingsController.deleteItem);
router.post('/',  settingsController.validate('new'), settingsController.createNewItem);

module.exports = router;
