const express = require('express');
const router = express.Router();

const banksController = require('../../../controllers/bankController');
router.get('/', banksController.getAllItems);
router.get('/:id', banksController.getItemById);
router.put('/:id',  banksController.updateItem);
router.delete('/:id',  banksController.deleteItem);
router.post('/',  banksController.validate('new'), banksController.createNewItem);

module.exports = router;
