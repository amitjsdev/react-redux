const express = require('express');
const router = express.Router();

const qoutesController = require('../../../controllers/qoutesController');


router.get('/getmyqoutes/:id', qoutesController.getMyQuoteSingle);
router.get('/getmyqoutes', qoutesController.getMyQoutes);
router.get('/buyeracceptedqoutes', qoutesController.buyerAcceptedQoutes);
router.get('/', qoutesController.getAllItems);
router.get('/:id', qoutesController.getItemById);
router.put('/:id',  qoutesController.updateItem);
router.delete('/:id',  qoutesController.deleteItem);
router.post('/',  qoutesController.validate('new'), qoutesController.createNewItem);

module.exports = router;
