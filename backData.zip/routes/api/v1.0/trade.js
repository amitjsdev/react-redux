const express = require('express');
const router = express.Router();
const userController = require('../../../controllers/userController');
const tradeController = require('../../../controllers/tradeController');
router.put('/close/:id', tradeController.closeRequest);
router.get('/', tradeController.getAllItems);
router.get('/usertrades/:id', tradeController.getAllItemsOfUser);
router.get('/getliveauctions/:id', tradeController.getliveauctionsSingle);
router.get('/getliveauctionsofBuyer', tradeController.getliveauctionsofBuyer);
router.get('/getliveauctions', tradeController.getliveauctions);
router.get('/myrequest', tradeController.getMyRequest);
router.get('/myrequest/:id', tradeController.getMySingleRequest);
router.get('/myalltrades/', tradeController.getMyAllTradeRequest);
router.get('/crontest/', tradeController.checkTrade);

router.put('/accept/:id/:qid', tradeController.acceptQuote);
router.get('/quote/:id', tradeController.getQuote);
router.get('/live', tradeController.getLiveRequest);
router.get('/accepted', tradeController.getAcceptedRequest);
router.put('/approveOrReject/:id', userController.isAdmin,tradeController.validate('approveReject'),  tradeController.approveReject);

router.get('/history/:entity/:entityId', tradeController.getHistory);
router.get('/:id/qoutes', tradeController.getItemQoutes);
router.get('/:id', tradeController.getItemById);
router.put('/:id',  tradeController.updateItem);
router.delete('/:id',  tradeController.deleteItem);
router.post('/search',  tradeController.search);
router.post('/', tradeController.validate('new'), tradeController.createNewItem);

module.exports = router;
