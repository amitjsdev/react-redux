const express = require('express');
const router = express.Router();
const authController = require('../../../controllers/authController');
const userController = require('../../../controllers/userController');
const commodityController = require('../../../controllers/commodityController');
const notificationController = require('../../../controllers/notificationController');

router.post(
    '/login',
    authController.validate('login'), 
    authController.login
);

router.post(
    '/signup', 
    userController.validate('createNewUser'),
    userController.createNewUser
);
router.post('/resend', authController.validate('loginMobile'), authController.ResendOTP);
router.post('/mobileLogin', authController.validate('loginMobile'), authController.loginMobile);
router.post('/verifyOtp', authController.validate('loginMobileOTP'), authController.otpVerify);
router.post('/registerVerify', authController.validate('registerVerify'), authController.registerVerify);
router.get('/commodity/all',  commodityController.All);
router.get('/notificationtest',  notificationController.test);

// router.post(
//     '/passwordGenerate', 
//     authController.validate('passwordGenerate'),
//     authController.passwordGenerate
// );
// router.post(
//     '/forgotPassword', 
//     authController.validate('forgotPassword'),
//     authController.forgotPassword
// );

module.exports = router;
