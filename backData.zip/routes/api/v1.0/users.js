const express = require('express');
const router = express.Router();

const userController = require('../../../controllers/userController');

router.get('/', userController.getAllUsers);
router.get('/me',  userController.me);
router.post('/token', userController.validate('firebaseToken'), userController.saveFirebaseToken);
router.put('/token', userController.validate('firebaseTokenUpdate'), userController.updateFirebaseToken);
router.put('/logout', userController.validate('firebaseToken'), userController.removeFirebaseToken);

router.get('/:id', userController.getUserById);
router.put('/approveOrReject/:id', userController.isAdmin,userController.validate('approveReject'),  userController.approveOrRejectUser);
router.put('/:id', userController.isAdmin, userController.updateUser);
router.delete('/:id', userController.isAdmin, userController.deleteUser);
router.get('/resetPassword/:id', userController.isAdmin, userController.resetPassword);
router.post('/', userController.validate('createNewUser'), userController.createNewUser);



router.post('/logout', userController.logout);
router.post('/search', userController.search);

module.exports = router;
