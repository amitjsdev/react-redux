const express = require('express');
const router = express.Router();

const paymentController = require('../../../controllers/paymentController');

router.get('/my', paymentController.getMyPayment);
router.get('/qid/:id', paymentController.getQoutePayment);
router.get('/trade/:id', paymentController.getTradePayment);
router.get('/:id', paymentController.getItemById);
router.put('/:id',  paymentController.updateItem);
router.delete('/:id',  paymentController.deleteItem);
router.post('/',  paymentController.validate('new'), paymentController.createNewItem);

module.exports = router;
