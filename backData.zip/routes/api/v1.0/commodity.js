const express = require('express');
const router = express.Router();

const commodityController = require('../../../controllers/commodityController');
const userController = require('../../../controllers/userController');

router.get('/mycommodity', commodityController.getUserCommodity);
router.get('/', commodityController.getAllCommodity);
router.get('/:id', commodityController.getItemById);
router.put('/:id', userController.isAdmin, commodityController.updateItem);
router.delete('/:id', userController.isAdmin, commodityController.deleteItem);
router.post('/',  userController.isAdmin,commodityController.validate('new'), commodityController.createNewItem);

module.exports = router;
