const express = require('express');
const authRoutes = require('./auth');
const masterDataRoutes = require('./master');
const usersRoutes = require('./users');
const commodityRoutes = require('./commodity');
const tradeRoutes = require('./trade');
const qoutesRoutes = require('./qoute');
const poRoutes = require('./po');
const banks = require('./banks');
const settingsRoutes = require('./settings');
const paymentRoutes = require('./payment');
const openRoutes = require('./open');
const templateRoutes = require('./emailTemplate');
const transitRoutes = require('./transit');
const notificationRoutes = require('./notification');
const emailRoutes = require('./emailNotification');
const smsRoutes = require('./smsNotification');


module.exports = passport => {
  const router = express.Router();
  router.use('/auth', authRoutes);
  router.use('/master-data', /*validateSession*/ passport.authenticate('jwt', { session: false }), masterDataRoutes);
  router.use('/users',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  usersRoutes);
  router.use('/settings',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  settingsRoutes);
  router.use('/commodity',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  commodityRoutes);
  router.use('/trade',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  tradeRoutes);
  router.use('/banks',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  banks);
  router.use('/email-template',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  templateRoutes);
  router.use('/email-notification',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  emailRoutes);
  router.use('/sms-notification',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  smsRoutes);

  router.use('/qoutes',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  qoutesRoutes);
  router.use('/po',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  poRoutes);
  router.use('/transit',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  transitRoutes);
  router.use('/payment',   /*  validateSession,  */  passport.authenticate('jwt', { session: false }),  paymentRoutes);
  router.use('/notification', /*validateSession*/ passport.authenticate('jwt', { session: false }), notificationRoutes);
  router.use('/postUserSocket', /*validateSession*/ passport.authenticate('jwt', { session: false }), masterDataRoutes);
  router.use('/', openRoutes);


  return router;
};
