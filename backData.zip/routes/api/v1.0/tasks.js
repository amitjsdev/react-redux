const express = require('express');
const router = express.Router();
const taskController = require('../../../controllers/taskController');

/** GET all TASKS */
router.get('/', taskController.getTasks);

/** GET pending tasks count */
router.get(
    '/pending-tasks-count',
    taskController.getPendingTasksCount
);

/** ADD TASK */
router.post(
    '/',
    taskController.validate('addTask'),
    taskController.addTask
);

/** UPDATE TASK */
router.put(
    '/updateTask/:id',
    taskController.validate('updateTask'),
    taskController.updateTask
);

/** MARK COMPLETE TASK */
router.put(
    '/markComplete',
    taskController.validate('markTasksComplete'),
    taskController.markTasksComplete
);

/** MARK READ TASK */
router.put(
    '/markRead',
    taskController.validate('markTasksRead'),
    taskController.markTasksRead
);

/** DELETE Task */
router.delete('/:id', taskController.deleteTask);
router.post('/bulk-delete', taskController.deleteTaskBulk);

module.exports = router;
