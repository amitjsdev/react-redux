const express = require('express');
const statusRoutes = require('./status');
const paymentRoutes = require('./payment');
module.exports = passport => {
  const router = express.Router();
  router.use('/status',  statusRoutes);
  router.use('/c',   passport.authenticate('jwt', { session: false }),  paymentRoutes);

  return router;
};
