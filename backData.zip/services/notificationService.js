const { Op } = require('sequelize');
const Sequelize = require('sequelize');
const config = require('../config/config');
const { getAllNotifications } = require('../controllers/notificationController');
const parseTemplate = (template, data) => {
    template = template.split('<<');
    template = template.map(item => {
        if (item && item.includes('>>')) {
            let sub = item.substr(0, item.indexOf('>>'));
            if (data && data[sub]) {
                item = item.replace(sub, data[sub])
            } else {
                item = item.replace(sub, '')
            }
           

        }
        return item.replace('>>', '')
    })
   return template.join('')
}


// const ck =await notificationService.addNotification(req,to, from, entity, entityStage, entityId,data)
    
module.exports.addNotification = async (req, to, from,entity, entityStage, entityId, data) => {
    console.log({entity, entityStage, entityId});
    const record = await req.db.Notification.findOne({
        where: {entity,entityStage},
        attributes: ['id', 'content','subject']
    });
    if(!record){
        console.log('notification not found for ',entity, entityStage);
        return;
    }

    let content = parseTemplate(record.content, data)
    let subject = parseTemplate(record.subject, data)
    const notificationId =record.id;
    
    
    const fetchAllUsers = await req.db.User.findAll({
        where: {id:{[Op.in]:to}},
        include: [
            {
                model: req.db.UserSocket,
                attributes: ['socketId'],
                order:[
                    [ 'id',  'DESC']
                ],
                limit : 5
            }
        ],
        attributes:['id', 'userName']
        
    });
    var sockets = [];
    var users = [];
    for (let fetchAllUser of fetchAllUsers) {
        for (let user of fetchAllUser.dataValues.UserSockets) {
            sockets.push({socketId:user.socketId, userId:fetchAllUser.id});
        }
        users.push(fetchAllUser.dataValues.id);
    }
    await sendPushNotification(req,sockets,subject, content, users, from,notificationId, entityId);
    return true;
};
const getNotificationOfUser =async(req, id)=>{
    let c = await req.db.User.findOne({
        where:{id},
        attributes:['notification']
    });
    c= c && c.notification ? c.notification:0;
    return c;
}
var sendPushNotification = async(req,sockets,subject, content, users, from,notificationId,entityId ) =>{
    
    const createdBy  = from
    var UserNotificationInsertArray = [];
    for (var i = 0; i < users.length; i++) {
        var UserNotificationTableObj = {
            fromUserId: from,
            toUserId: users[i],
            entityId: entityId,
            // entityRecordId,
            notificationId,
            createdBy,
            updatedBy:createdBy,
        };
        UserNotificationInsertArray.push(UserNotificationTableObj);
        // await increaseUserNotificationCount(req, users[i]);
    }
    const addUserNotification = await req.db.UserNotification.bulkCreate(UserNotificationInsertArray);
    // first increase user notification table then get count then send by socket updated count
    if(!req.app){
        // do not send notification for cron 
        console.log('return fro cron scoket not available');
        return;
    }
    var socketio = req.app.get('socket');
    for(const recipient of sockets){
    //     const notification =await getNotificationOfUser(req,recipient.userId );
    //    // formatedContent = {...formatedContent, notification};
        var socketIdNew = recipient.socketId;
        socketio = req.app.get('socket');
        socketio.to(socketIdNew).emit('fromServerNotification', {subject,content});
       
    }
    return addUserNotification;
};
/**
 * increaseUserNotificationCount
 * @param req
 * @param payload
 */
var increaseUserNotificationCount = async (req, userId) => {
    await req.db.User.increment({notification: 1}, { where: { id: userId } });
    
};
