const moment = require('moment');
const config = require('../config/config');

module.exports.getConfiguration = async (req, key, addIfNotExist=false) => {
    console.log('getConfiguration key',key)
    let data = await req.db.Configuration.findOne({
        where: { configurationName: key },
        attributes: ['value']
    });
    if(addIfNotExist && !data){
        let newVal = await module.exports.addConfiguration(req, key, 0);
        if(newVal){
            newVal =newVal.toJSON();
            return newVal.value;
        } else {
            return false;
        }
        
    } else {

        return data && data.value ? JSON.parse(data.value) : false;
    }

    
}
module.exports.addConfiguration = async (req, key, value=1) => {
    console.log(`adding config ${key} =>> ${value}`)
    let val = JSON.stringify(value);
    console.log(`adding config ${key} =>> ${val}`)
     return await req.db.Configuration.create(
        {configurationName: key, value:val });
}

module.exports.updateConfiguration = async (req, key, value) => {
    const OldConfig = await module.exports.getConfiguration(req, key);
    if(!OldConfig){
        await module.exports.addConfiguration(req, key, value);
    }
    let data = await req.db.Configuration.update(
        { value },
        {
            where: {
                configurationName: key
            }
        });
        const newConfig = await module.exports.getConfiguration(req, key); 
        return newConfig;   
}

module.exports.InvertConfiguration = async (req, key) => {
    const OldConfig = await module.exports.getConfiguration(req, key);
    if(!OldConfig){
        await module.exports.addConfiguration(req, key);
    }
    let data = await req.db.Configuration.update(
        { value: !OldConfig },
        {
            where: {
                configurationName: key
            }
        });
        return data;
}

module.exports.lastActivityTime= async(req,user)=>{
    const last  = moment().utc().diff(moment(user.last_activity_time), 'minutes');
    if(last === undefined || last=== null ||last > 3){
        // console.log('last=>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>',last)
        const isUpdated =await req.db.User.update(                    
            {last_activity_time:moment().utc().format('YYYY-MM-DD HH:mm:ss').toString()},
            { where: { id: user.id } }
            );
            // console.log({isUpdated});
    }
    return 1;
}
