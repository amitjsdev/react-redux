const config = require('../config/config');
const Sequelize = require('sequelize');
const fs = require('fs');
const path = require('path');

const logging =false;
//const logging =false;

module.exports.getClientAllModels = async () => {
    const clientConnection = new Sequelize(config.database, config.username, config.password, {
        dialect: config.databaseType,
        host: config.databaseHost,
        logging
    });
    clientConnection.options.logging = logging;
    // load the models for this client
    const modelsPath = path.join(__dirname, '../models/');
    const modelFileList = fs.readdirSync(modelsPath);
    const filteredList = modelFileList.filter(file => {
        return (
            (file.indexOf('.js') !== 0) &&
            (file !== 'index.js') &&
            (file !== 'setup.js') &&
            (file.slice(-3) === '.js')
        );
    });
    
    let modelList={};
    filteredList.forEach(file => {
        const model = clientConnection.import(path.join(modelsPath, file));
        modelList[model.name] = model;
    });
    Object.keys(modelList).forEach(modelName => {
        if (modelList[modelName].associate) {
            modelList[modelName].associate(modelList);
        }
    });

    return modelList;
};



