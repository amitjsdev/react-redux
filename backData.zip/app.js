const createError = require('http-errors');
const express = require('express');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const cors = require('cors');
const bodyParser = require('body-parser');
const moment =require('moment')

const v1Routes = require('./routes/api/v1.0');
const webviewRoutes = require('./routes/webview');
const passport = require('./config/passport');
const config = require('./config/config');
var cron = require('node-cron');
const { getClientAllModels } = require('./services/clients');
const tradeController = require('./controllers/tradeController');
const app = express();


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/'));
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.set('views', __dirname);
var fs = require('fs');

var trueLog = console.log;
console.log = function (msg,b='', c='') {
  fs.writeFile(__dirname + `/debug/${moment().format('DD-MM-YYYY').toString()}-debug.log`, `\n  ${JSON.stringify(msg)} ${JSON.stringify(b)} ${JSON.stringify(c)} `, { flag: 'a+' }, function (err) {
    if (err) throw err;

  });
  trueLog(msg,b,c); //uncomment if you want logs
}
app.use(cors());



//app.use(logger('combined', { stream: winston.stream }));

// app.use(express.json({limit: '50mb'}));
// app.use(express.urlencoded({limit: '50mb'}));
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));
app.use(cookieParser());

app.use(async(req,res, next)=>{
  const db = await getClientAllModels();
  req.db = db;
  next()
})
app.use(session({
  secret: config.sessionSecret,
  resave: true,
  saveUninitialized: true
}));
app.use('*',(req,res, next)=>{
  // const fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
  // console.log('url',fullUrl, new Date());
  console.log('url',req.originalUrl,);
  console.log('urlParam',JSON.stringify(req.params) , JSON.stringify(req.query));
  next();
})
app.use(passport.initialize());
app.use(passport.session());
app.use('/api/v1.0', v1Routes(passport));
app.use('/payment', webviewRoutes(passport));

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});
// error handler
app.use(function (err, req, res, next) {
  //console.log('req for app',req);
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  // render the error page
  res.status(err.status || 500);
  res.json({
    message: err.message,
    error: err
  });
});
cron.schedule(`* * * * *`, () => {
  //cron.schedule(`* * * * *`, () => {
  console.log('running a task every 1 hour');
  tradeController.checkTrade();
});
module.exports = app;
