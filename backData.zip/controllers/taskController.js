const parseObject = require('../services/helpers');
const { Op } = require('sequelize');
const UserActivityService = require('../services/userActivityService');
const { userActivityActions, entities, entityAbbr } = require('../lib/utils');
const auditTrail = require('../services/auditTrail');
const moment = require('moment');
const taskNotificationService = require('../services/taskNotificationService');

const auditAfterOptionsTask = {
    entity: 'Tasks',
    mappings: [
        { field: 'description', fieldName: 'Description' },
        {
            field: 'dateAssigned',
            fieldName: 'Assigned Date'
        },
        { field: 'dueDate', fieldName: 'Due Date' },
        {
            field: 'assignedBy',
            fieldName: 'Assigned By User'
        },
        { field: 'assignedTo', fieldName: 'Assigned To User' },
        { field: 'completed', fieldName: 'Task Completed' },
        {
            field: 'completedDate',
            fieldName: 'Completed Date'
        },
        {
            field: 'read',
            fieldName: 'Read Status'
        },
        { field: 'status', fieldName: 'Status' },
    ]
};

exports.validate = (method) => {
    switch (method) {
        case 'addTask':
            return [
                // check('title', 'title is required').not().isEmpty(),
                // check('countryId', 'country is required').not().isEmpty(),
                // check('productTypeId', 'product type is required').not().isEmpty()
            ];
        default:
            return [];
    }
};

exports.getTasks = async (req, res, next) => {
    try {
        return fetchTasks(req, res, next);
    } catch (error) {
        return res.status(500).send(error);
    }
};

exports.getPendingTasksCount = async (req, res, next) => {
   const tasks =await this.getUserTaskCount(req);
    return res.status(200).json(tasks ? tasks : 0)
   
};

var fetchTasks = async (req, res, next, whereClause = {}) => {
    const { id: userId } = parseObject(req.user);
    let where = {
        status: 1,
        [Op.or]: {
            createdBy: userId,
            assignedBy: userId,
            assignedTo: userId
        },
        ...whereClause,
    };
    try {
        const tasks = await req.db.EntityTask.findAll({
            where,
            order: [['updatedAt', 'DESC']],
            include: [
                {
                    attributes: ['id', 'userName', 'email'],
                    model: req.db.User,
                    as: 'AssignedTo'
                },
                {
                    attributes: ['id', 'userName', 'email'],
                    model: req.db.User,
                    as: 'AssignedBy'
                }
            ]
        });
        return res.status(200).json(tasks);
    } catch (error) {
        return res.status(500).send(error);
    }
};

exports.deleteTaskFromRI = async (req, riId, res) => {
    try {
        const tasks  = await req.db.EntityTask.findAll({
            where: {
                taskableId: riId,
                taskAble: entityAbbr.RI
            },
            attributes: ['id', 'completed', 'assignedTo']
        });
        let taskRecordAfter = {};
        var afterDataTask = {};
        var beforeTaskData = {};
        if(tasks.length > 0){
            for(let task of tasks){ 
                let taskRecordBefore = await getTaskAuditTrail(req, task.id);
                if(task.completed == 1){
                    await req.db.EntityTask.update({
                        taskAble: null,
                        taskableId: null
                    }, {
                        where: {
                            id: task.id
                        }
                    });
                    taskRecordAfter = await getTaskAuditTrail(req, task.id); 
                    afterDataTask = makeTaskObject(taskRecordAfter);
                }else{
                    await req.db.EntityTask.destroy({
                        where: {
                            id: task.id
                        }
                    });
                    //console.log('task.assignedTo',task) 
                    await decreaseUserTaskCount(req, task.assignedTo);                    
                }
                       
                beforeTaskData = makeTaskObject(taskRecordBefore);
                await decreaseUserTaskCount(req, taskRecordBefore.assignedTo);
                await taskNotificationService.deleteTaskNotification(req, {
                    ...taskRecordBefore.dataValues,
                    assignerName: req.user.userName
                });
                await auditTrail.processAuditTrail(req, afterDataTask, beforeTaskData, { ...auditAfterOptionsTask, event: 'Delete' }, parseObject(req.user));
                await UserActivityService.processUserActivity(req, entities.TASK, userActivityActions.DT, beforeTaskData.entityId, riId);
                
            }
            return true;
        }
    } catch (error) {
        console.log(error);
        return res.status(500).send(error);
    }
};

exports.deleteTask = async (req, res, next) => {
    try {
        var afterDataTask = {};
        var beforeTaskData = {};
        let taskRecordBefore = await getTaskAuditTrail(req, req.params.id);
        const task = await req.db.EntityTask.update({
            status:false
        },{
            where: {
                id: req.params.id
            }
        });
        //let taskRecordAfter = await getTaskAuditTrail(req, req.params.id);

        beforeTaskData = makeTaskObject(taskRecordBefore);
        //afterDataTask = makeTaskObject(taskRecordAfter);
        if (task) {
            await decreaseUserTaskCount(req, taskRecordBefore.assignedTo);
            await taskNotificationService.deleteTaskNotification(req, {
                ...taskRecordBefore.dataValues,
                assignerName: req.user.userName
            });
            await auditTrail.processAuditTrail(req, afterDataTask, beforeTaskData, { ...auditAfterOptionsTask, event: 'Delete' }, parseObject(req.user));
            await UserActivityService.processUserActivity(req, entities.TASK, userActivityActions.DT, beforeTaskData.entityId, req.params.id);
           
            return res.status(200).json({ success: true, message: 'Success' });
        } else {
            return res.status(404).json({ success: false, message: 'Error' });
        }
    } catch (error) {
        console.log(error);
        return res.status(500).send(error);
    }
};
exports.deleteTaskBulk = async (req, res, next) => {
    try {
        for (let taskId of req.body.taskIds) {
            let afterDataTask = {};
            let beforeTaskData = {};
            let taskRecordBefore = await getTaskAuditTrail(req, taskId);
            await req.db.EntityTask.destroy({
                where: {
                    id: taskId
                }
            });
            //let taskRecordAfter = await getTaskAuditTrail(req, taskId);

            beforeTaskData = makeTaskObject(taskRecordBefore);
            //afterDataTask = makeTaskObject(taskRecordAfter);
            await auditTrail.processAuditTrail(req, afterDataTask, beforeTaskData, { ...auditAfterOptionsTask, event: 'Delete' }, parseObject(req.user));
            await UserActivityService.processUserActivity(req, entities.TASK, userActivityActions.DT, beforeTaskData.entityId, taskId);
            await decreaseUserTaskCount(req, taskRecordBefore.assignedTo);
        }
        return res.status(200).json({ Success: true });
    } catch (error) {
        return res.status(500).send(error);
    }
};
exports.addTask = async (req, res, next) => {
    var afterDataTask = {};
    var beforeTaskData = {};
    const { id } = parseObject(req.user);
    if (req._validationErrors && req._validationErrors.length > 0) {
        return res.status(400).send(req._validationErrors);
    }
    //try {
        const task = await req.db.EntityTask.create({
            ...req.body,
            createdBy: id,
            updatedBy: id,
            assignedBy: id,
            ownerId: id
        });
        if (task && task.id) {
            const taskPrefix = await req.db.Configuration.findOne({
                where: {
                    configurationName: 'task_prefix'
                },
                attributes: ['value'],
                row: true
            });
            const count = 10 - (taskPrefix.value).length;
            const taskId = taskPrefix.value + String(task.id).padStart(count, '0');
            await req.db.EntityTask.update({
                taskId
            }, {
                where: {
                    id: task.id
                }
            });
            var taskRecord = await getTaskAuditTrail(req, task.id);

            afterDataTask = makeTaskObject(taskRecord);
            await increaseUserTaskCount(req, req.body.assignedTo);
            await taskNotificationService.addTaskNotification(req, {
                ...task.dataValues,
                taskId,
                assignerName: req.user.userName,
            });
            await auditTrail.processAuditTrail(req, afterDataTask, beforeTaskData, { ...auditAfterOptionsTask, event: "Create" }, parseObject(req.user));
            await UserActivityService.processUserActivity(req, entities.TASK, userActivityActions.AT, taskId, task.id);
        }
        
        return fetchTasks(req, res, next, { id: task.id });
    // } catch (error) {
    //     return res.status(500).send(error);
    // }
}


exports.updateTask = async (req, res, next) => {
    const { completed } = req.body; console.log('->>>>>>>>>>>>>>>>>>>>>>>>.', completed)
    if (completed == 1) {
        req.body.tasks = [req.params.id];
        await this.markTasksComplete(req, res, next);
    } else {
        console.log('->>>>>>>>>>>>>>>>>>.....update')
        if (req._validationErrors && req._validationErrors.length > 0) {
            return res.status(400).send(req._validationErrors);
        }
        // try {
        var afterDataTask = {};
        var beforeTaskData = {};
        let taskRecordBefore = await getTaskAuditTrail(req, req.params.id);
        await req.db.EntityTask.update(req.body, {
            where: {
                id: req.params.id
            }
        });
        let taskRecordAfter = await getTaskAuditTrail(req, req.params.id);

        beforeTaskData = makeTaskObject(taskRecordBefore);
        afterDataTask = makeTaskObject(taskRecordAfter);
        let task = await getTask(req, req.params.id);

        await decreaseUserTaskCount(req, taskRecordBefore.assignedTo);
        await increaseUserTaskCount(req, req.body.assignedTo);
        let assignedTo = req.body.assignedTo;
        if (taskRecordBefore.createdBy !== req.user.id) {
            assignedTo = taskRecordBefore.assignedBy;
        }
        await taskNotificationService.updateTaskNotification(req, {
            title: req.body.title,
            assignedTo: assignedTo,
            assignerName: req.user.userName
        });
        await auditTrail.processAuditTrail(req, afterDataTask, beforeTaskData, { ...auditAfterOptionsTask, event: "Update" }, parseObject(req.user));
        await UserActivityService.processUserActivity(req, entities.TASK, userActivityActions.UT, task.taskId, req.params.id);
        //await updateUserTask(req);

        if (taskRecordBefore.assignedTo != req.body.assignedTo) {
            await taskNotificationService.deleteTaskNotification(req, {
                ...taskRecordBefore.dataValues,
                assignerName: req.user.userName
            });
        }

        // } catch (error) {
        //     return res.status(500).send(error);
        // }
    }
    return await fetchTasks(req, res, next, { id: req.params.id });
};

exports.markTasksComplete = async (req, res, next) => {
    if (req._validationErrors && req._validationErrors.length > 0) {
        return res.status(400).send(req._validationErrors);
    }
   // try {
        console.log('->>>>>>>>>>>>>>>>>>.....comp')
        var afterDataTask = {};
        var beforeTaskData = {};
        for (let taskId of req.body.tasks) {
            let taskRecordBefore = await getTaskAuditTrail(req, taskId);
            await req.db.EntityTask.update({
                completed: 1,
                read: 1,
                completedDate: moment()
                    .utc()
                    .toDate()
            }, {
                where: {
                    id: taskId
                }
            });
            let taskRecordAfter = await getTaskAuditTrail(req, taskId);
            beforeTaskData = makeTaskObject(taskRecordBefore);
            afterDataTask = makeTaskObject(taskRecordAfter);
            const completedTask = await req.db.EntityTask.findOne({
                where: {
                    id: taskId
                },
                include: [
                    {
                        attributes: ['userName'],
                        model: req.db.User,
                        as: 'AssignedTo'
                    },
                    {
                        attributes: ['userName'],
                        model: req.db.User,
                        as: 'AssignedBy'
                    }
                ]
            });
            console.log('->>>>>>>>',taskRecordBefore.assignedTo);
            const isCreatorUpdating = req.user && req.user.id === taskRecordBefore.createdBy ? true: false;
            await decreaseUserTaskCount(req, taskRecordBefore.assignedTo);
            console.log('->>>>>>>>isCreatorUpdating',isCreatorUpdating);
            await taskNotificationService.completeTaskNotification(req, {
                ...completedTask.dataValues,
                assigneeName: isCreatorUpdating ?  completedTask.AssignedBy.dataValues.userName : completedTask.AssignedTo.dataValues.userName
            },isCreatorUpdating);
            await auditTrail.processAuditTrail(req, afterDataTask, beforeTaskData, { ...auditAfterOptionsTask, event: "Update" }, parseObject(req.user));
            await UserActivityService.processUserActivity(req, entities.TASK, userActivityActions.MCT, beforeTaskData.entityId, taskId);
            
        }
        return await fetchTasks(req, res, next, { id: req.body.tasks });
        //return res.status(200).json({ 'status': 'Success' });
    // } catch (error) {
    //     return res.status(500).send(error);
    // }
}

exports.markTasksRead = async (req, res, next) => {
    if (req._validationErrors && req._validationErrors.length > 0) {
        return res.status(400).send(req._validationErrors);
    }
    try {
        const result = await req.db.EntityTask.update({
            read: 1
        }, {
            where: {
                id: {
                    [Op.in]: req.body.tasks
                }
            }
        });
        //await updateUserTask(req);
        return res.status(200).json(result);
    } catch (error) {
        return res.status(500).send(error);
    }
};
var getTask = async (req, id) => {
    return req.db.EntityTask.findOne({
        where: {
            id
        },
        attributes: ['taskId']
    });
};
var getTaskAuditTrail = async (req, id) => {
    return req.db.EntityTask.findOne({
        where: {
            id
        },
        include: [
            {
                model: req.db.User,
                as: 'AssignedBy',
                attributes: ['userName']
            },
            {
                model: req.db.User,
                as: 'AssignedTo',
                attributes: ['userName']
            }
        ]
    });
};
function makeTaskObject(taskObject) {

    var afterModifiedData = {};
    afterModifiedData.description = taskObject.description;
    afterModifiedData.assignedBy = taskObject.AssignedBy.userName;
    afterModifiedData.assignedTo = taskObject.AssignedTo.userName;
    afterModifiedData.dateAssigned = taskObject.dateAssigned + '';
    afterModifiedData.dueDate = taskObject.dueDate + '';
    afterModifiedData.completed = (taskObject.completed == 1) ? 'Completed' : 'Incomplete';
    afterModifiedData.read = (taskObject.read == 1) ? 'Read' : 'Unread';
    afterModifiedData.completedDate = taskObject.completedDate + '';
    afterModifiedData.status = (taskObject.status == 1) ? 'Active' : 'Inactive';
    afterModifiedData.entityId = taskObject.taskId;
    afterModifiedData.id = taskObject.id;
    afterModifiedData.parentId = taskObject.id;
    return afterModifiedData;
}

const increaseUserTaskCount = async (req, userId) => {
    await req.db.User.increment({ task: 1 }, { where: { id: userId } });

};
const decreaseUserTaskCount = async (req, userId) => {
    await req.db.User.decrement({ task: 1 }, { where: { id: userId } });
};
exports.getUserTaskCount = async (req) => {
    const { id: userId } = parseObject(req.user);
    let entityTasks = await req.db.EntityTask.findAll({
        where: {
            status: 1,
            assignedTo: userId
        }
    });
    const userTaskCount = entityTasks && entityTasks.length ? entityTasks.length : 0;
    await req.db.User.update({ task: userTaskCount }, { where: { id: userId } });
    return userTaskCount;
};