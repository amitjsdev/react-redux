const { check, custom, validationResult } = require('express-validator/check');
const { sendMail } = require('./mailController');
const parseObject = require('../services/helpers')
const notificationService = require('../services/notificationService')

const notificationController = require('./notificationController')
const fileController = require('./filesController')
const { Op } = require('sequelize')
const sequelize = require('sequelize')
const config = require('../config/config');
const { getConfiguration,  } = require('../services/helpers');
const util = require('./util')
exports.validate = (functionName) => {

    switch (functionName) {

        case 'firebaseToken':
            return [
                check('token', 'Token is required ').not().isEmpty(),
            ];
        case 'firebaseTokenUpdate':
        return [
            check('token', 'Token is required ').not().isEmpty(),
            check('oldToken', 'Old Token is required ').not().isEmpty(),
        ];
        case 'createNewUser':
            return [
                // check('userName', 'username is required and must be at least 3 characters long').isLength({ min: 3 }),
                check('first_name', 'First Name is required and must be at least 3 characters long').isLength({ min: 3 }),
                check('last_name', 'Last Name is required and must be at least 3 characters long').isLength({ min: 3 }),

                check('email', 'Email is required').not().isEmpty().isEmail().normalizeEmail(),
                // check('dob', 'Date of birth is required').not().isEmpty(),
                check('aadhar.number', 'Aadhar  is required and must be valid').not().isEmpty().isLength({ min: 12, max: 12 }),
                check('pan.number', 'PAN  is required and must be valid').not().isEmpty().isLength({ min: 10, max: 10 }),
                check('gstin.number', 'GSTIN  is required').not().isEmpty(),
                check('mobile', 'Mobile  is required').not().isEmpty().isLength({ min: 10, max: 10 }),
                check('residential.address1', 'Address  is required').not().isEmpty(),
                check('residential.city', 'City  is required').not().isEmpty(),
                check('residential.state', 'State  is required').not().isEmpty(),
                check('residential.zip', 'Zip  is required').not().isEmpty().isLength({ min: 6, max: 6 }),
                check('residential.country', 'Country  is required').not().isEmpty(),
                // check('residential.district', 'District  is required').not().isEmpty(),
                check('commodity', 'Commodity  is required').isArray(),
                check('type', 'User Type  is required').not().isEmpty(),
                // check('aadhar.file', 'Aadhar attachment  is required').not().isEmpty(),
                // check('pan.file', 'PAN attachment  is required').not().isEmpty(),
                // check('gstin.file', 'GSTIN attachment  is required').not().isEmpty(),
                check('token', 'Firebase Token is required').not().isEmpty(),

                // check('pan.file', 'Pan attachment  is required').custom((value,req,q)=>{
                //     console.log({value,q});
                // }),



            ];
        case 'updateUser':
            return [
                check('userName', 'username is required and must be at least 3 characters long').isLength({ min: 3 }),
                check('roleId', 'a numeric role id is required').isNumeric({ min: 1, max: 5 })
            ];
        case 'approveReject':
            return [
                check('status', 'Status is required ').isNumeric({ min: 0, max: 30 }),
            ];
        

        default:
            throw new Error('invalid user controller function name');
    }
};
exports.Overview = async (req) => {
    const q = {

        attributes: [
            'status', 'statusStr',
            [sequelize.fn('count', sequelize.col('status')), 'count'],
        ],
        where: { userRoleId: { [Op.ne]: 1 } },
        group: ['status']
    };
    const results = await req.db.User.findAll(q);
    return results;
}
exports.getAllUsers = async (req, res, next) => {
    try {
        const users = await req.db.User.findAll({
            attributes: ['id', 'userName', 'email', 'status', 'mobile', 'createdAt', 'updatedAt'],
            include: [
                {
                    model: req.db.UserRole,
                    attributes: ['role']
                }
            ]
        });
        return res.status(200).json(users);
    } catch (error) {
        return res.status(500).send(error);
    }
};

exports.getUserById = async (req, res) => {
    const { all } = req.query;

    try {
        let include = []
        if (all) {
            include = [
                {
                    model: req.db.Address,
                    where: { status: 1 },
                    required: false,
                    include: ['Country', 'State', 'City']
                },
                {
                    model: req.db.Banks,
                    required: false
                    // as: 'userbank',
                },
                {
                    model: req.db.Identity,
                    where: { status: 1 },
                    required: false,
                    include: [
                        {
                            model: req.db.EntityFile,
                            where: { status: 1 },
                            required: false,
                            include: [
                                {
                                    model: req.db.File,
                                    where: { status: 1 },
                                    attributes: {
                                        exclude: ['fileName']
                                    }
                                }
                            ]
                        }
                    ]
                },
                {
                    model: req.db.EntityCommodity,
                    where: { commodityTypeable: 'user' },
                    required: false,
                    include: [
                        {
                            model: req.db.Commodity,
                            where: { status: 1 }
                        }
                    ]
                },
                {
                    model: req.db.UserRole,
                    required: false
                },
                {
                    model: req.db.History,
                    required: false,
                    as: 'history',
                    include: [
                        {
                            model: req.db.User,
                            as: 'CreatedUser',
                            attributes: ['first_name', 'last_name', 'userName']
                        },
                        {
                            model: req.db.User,
                            as: 'UpdatedUser',
                            attributes: ['first_name', 'last_name', 'userName']
                        }
                    ]
                }
            ]
        }
        const user = await req.db.User.findOne({
            where: {
                id: req.params.id
            },
            attributes: {
                exclude: ['password']
            },
            include

        });
        return res.status(200).json(user);
    } catch (error) {
        console.log({ error });
        return res.status(500).send(error);
    }
}
const UsersByRole = async (req) => {
    let data = [];
    let consumed = 0;
    let roles = await req.db.UserRole.findAll({
        include: [
            {
                model: req.db.User,
                attributes: ['id'],
                where: {
                    status: true
                }
            }
        ],

    });
    if (roles && roles.length > 0) {
        for (role of roles) {

            role = role.toJSON();
            role.count = role.Users ? role.Users.length : 0;
            consumed += role.count;
            const configKey = role.role.trim().replace(/ /g, '');
            role.allowed = await getConfiguration({ db: req.db }, `${configKey}_Allowed`, true);
            delete role.Users;
            data.push(role);
        }
    }
    return { consumed, roles: data };

}
exports.getAddress = async (req, type, userId) => {
    const address = await req.db.Address.findOne({
        where: {
            userId,
            type,
            status: 1
        }
    }
    )

    return address;
}
exports.addAddress = async (req, type, userId, data) => {
    data.userId = userId;
    data.updatedBy = req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : userId
    data.type = type;
    const hasAddress = await this.getAddress(req, type, userId)
    let newAddress = undefined;
    if (hasAddress) {
        newAddress = await req.db.Address.update(data, { where: { userId, type } })
    } else {
        // console.log({hasAddress});
        newAddress = await req.db.Address.create(data)
    }

    return newAddress;

}
exports.getBanks = async (req, userId) => {
    const bank = await req.db.Banks.findOne({
        where: {
            user_id: userId,
            status: 1
        }
    }
    )

    return bank;
}
exports.addBank = async (req, userId, data) => {
    data.userId = userId;
    data.updatedBy = req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : userId
    const hasBank = await this.getBanks(req, userId)
    let newBank = undefined;
    if (hasBank) {
        newAddress = await req.db.Banks.update(data, { where: { id: hasBank.id } })
    } else {
        // console.log({hasAddress});
        data.createdBy = data.updatedBy;
        newBank = await req.db.Banks.create(data)
    }

    return newBank;

}
exports.getUserCommodity = async (req, commodityId, userId) => {
    const record = await req.db.EntityCommodity.findOne({
        where: {
            commodityTypeable: 'user',
            commodityTypeableId: userId,
            commodityId,

        }
    })
    return record;
}
exports.addCommodityToUser = async (req, commodity, userId) => {
    let data = [];
    const updater = req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0
    if (commodity && commodity.length > 0) {
        //await req.db.EntityCommodity.update({status:1, updatedBy:updater})
        commodity.map(async (c) => {
            let has = await this.getUserCommodity(req, c, userId)
            if (!has) {
                has = await req.db.EntityCommodity.create({
                    commodityTypeable: 'user',
                    commodityTypeableId: userId,
                    commodityId: c,
                    status: 1,
                    updatedBy: updater
                })
            }
            data.push(has);
        })
    }
    return data;
}

exports.getUserIdentity = async (req, title, userId) => {
    const record = await req.db.Identity.findOne({
        where: {
            title,
            status: 1,
            userId
        }
    })
    return record;
}

exports.addIdentityToUser = async (req, title, item, userId) => {
    let has = await this.getUserIdentity(req, title, userId)

    if (has && has.id) {
        const updatedBy = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : userId

        const updated = await req.db.Identity.update({
            status: 0,
            updatedBy,
            number: item.number,
            updatedAt: new Date()
        }, { where: { id: has.id } })
        console.log({ updated });
    }
    has = await req.db.Identity.create({
        title,
        number: item.number,
        status: 1,
        userId
    })
    if (has && has.id) {
        if (item.file) {
            await fileController.addFile(req, item.file, userId, 'identity', has.id)
        }

    }


    return has;
}


exports.createNewUser = async (req, res, next) => {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errors: errors.array() });
    }
    // return res.json({'data':req.body})
    const newUserData = {
        ...req.body,
        status: -1
    };
    console.log(req.body);

    //make unique string with timestamp
    const ciper = {
        'userName': req.body.userName,
        'email': req.body.email,
        'timestamp': (new Date()).getTime()
    };

    newUserData.token = '';
    newUserData.password = Math.random() + (new Date()).getTime();
    newUserData.status = -1;
    // newUserData.userRoleId = newUserData.type == 'seller' ? 3 : 2;
    newUserData.userRoleId = newUserData.type
    newUserData.password = newUserData.password.toString()
    const otp = Math.floor(1000 + Math.random() * 9000);
    const mailotp = Math.floor(1000 + Math.random() * 9000);
    newUserData.otp = otp
    newUserData.mailOtp = mailotp
    return req.db.User.create(newUserData)
        .then(async (newUser) => {
            newUser.password = '';
            newUser.token = '';

            await this.addAddress(req, 'residential', newUser.id, req.body.residential)
            // if (req.body.type ==3) {
            await this.addAddress(req, 'bussiness', newUser.id, req.body.bussiness)
            // }
            if (req.body.latLong) {
                await this.addAddress(req, 'geo', newUser.id, req.body.latLong)
            }
            await this.addCommodityToUser(req, req.body.commodity, newUser.id)
            const identityArr = ['aadhar', 'pan', 'gstin', 'kyc', 'import', 'export'];
            identityArr.map(async (identity) => {
                if (identity && req.body[identity]) {
                    await this.addIdentityToUser(req, identity, req.body[identity], newUser.id)
                }
            })

            // const adminId = 1;
            const notificationData = {
                email: newUser.email,
                userName: newUser.userName,
                first_name: newUser.first_name,
                userType: newUserData.type,
                id: newUser.id,
                mailotp
            }
            // notificationService.addNotification(req, adminId, 'user', 'signup',notificationData);
            const otp_expire_in = await notificationController.getConfig(req, 'otp_expire_in')
            const mailData = {
                first_name: newUser.first_name,
                otp: mailotp,
                otp_expire_in,
                email: newUser.email,
            }
            sendMail(req, 'account_verify_for_user', mailData);
            await notificationController.sendSMS(req, newUser.mobile, 'user', 'verify_otp', { otp });
            await req.db.FireBaseToken.create({
                token:req.body.token,
                mobile:req.body.mobile
            })
            return res.status(200).json({ status: true, data: newUser, otp, mailotp });
        })
        .catch(err => {
            console.log({ err });
            // return res.status(200).json({ errors: err && err.errors && err.errors[0] && err.errors[0].message ? err.errors[0].message : 'Oops something went wrong' ,status:false});
            return res.status(200).json({ errors: [{ 'msg': err.errors[0].message }] });
            // return res.status(200).json({ errors: err});
        });

};
exports.approveOrRejectUser = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errors: errors.array() });
    }
    const updatedBy = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0;

    let comment = req.body.comment;
    comment = comment ? comment : ''
    return await req.db.User.update(
        { status: req.body.status, comment, updatedBy },
        {
            where: { id: req.params.id },
            returning: true,
            plain: true
        }
    ).then(async () => {
        await req.db.History.create({
            entity: 'user',
            entityId: req.params.id,
            comment,
            newData: util.status.user[req.body.status],
            createdBy: updatedBy,

        })
        const data = await req.db.User.findOne({
            where: {
                id: req.params.id
            },
            attributes: {
                exclude: ['password', 'token']
            },
            include: ['UserRole']
        });
        const status = req.body.status == 1 ? 'Approved' : 'Rejected';
        const userId = req.jwtPayload.id;
        // notificationService.addNotification(req, userId, 'user', 'signup', updateUser);
        const notificationdata = {
            first_name: data.first_name,
            userType: data && data.UserRole && data.UserRole.role ? data.UserRole.role : '',
            email: data.email,
            toemail: data.email,
            comment
        }
        // const to =adminIds;
        // const from =hasUser.id;
        // const entityId=1;
        // const entityStage='signup';
        // const entity ='user'
        // const ck =await notificationService.addNotification(req,to, from, entity, entityStage, entityId,notificationdata)
        sendMail(req, req.body.status == 1 ? 'account_approved' : 'account_rejected', notificationdata);
        return res.status(200).json({ status: true, data });
    })
        .catch(err => {
            res.status(200).send(err);
        })

}
exports.updateUser = async (req, res, next) => {
    let query = {};
    const id = req.params.id;
    const { first_name, last_name, email, mobile, userName, commodity, residential, bussiness, banks, latlng } = req.body;
    if (first_name !== undefined) {
        query = { first_name }
    } if (last_name) {
        query = { ...query, last_name };
    } if (email) {
        query = { ...query, email };
    } if (mobile) {
        query = { ...query, mobile };
    } if (userName) {
        query = { ...query, userName };
    }
    if (Object.keys(query).length > 0) {
        await req.db.User.update(query, { where: { id } })
    }
    if (bussiness) {
        await this.addAddress(req, 'bussiness', id, bussiness)
    }
    if (residential) {
        await this.addAddress(req, 'residential', id, residential)
    }
    if (latlng) {
        await this.addAddress(req, 'latlng', id, latlng)
    }
    if (banks) {
        banks.userId = req.params.id;
        banks.user_id = req.params.id;
        await this.addBank(req, id, banks)
    }

    if (commodity && commodity.length > 0) {
        await req.db.EntityCommodity.destroy({ where: { commodityTypeable: 'user', commodityTypeableId: req.params.id } })
        await this.addCommodityToUser(req, commodity, id)
    }
    const identityArr = ['aadhar', 'pan', 'gstin', 'kyc', 'import', 'export'];
    // const identityArr = ['aadhar', 'pan', 'gstin'];
    identityArr.map(async (identity) => {
        if (identity && req.body[identity]) {
            await this.addIdentityToUser(req, identity, req.body[identity], id)
        }
    })
    req.query = { all: true }
    return this.getUserById(req, res);

};
exports.resetPassword = async (req, res, next) => {
    const id = req.params.id;
    const user = await req.db.User.findOne({ where: { id } })
        .then(d => d)
        .catch(err => console.log('resetPasswordError', err));

    if (!user) {
        return res.status(500).send();
    }
    const ciper = {
        'userName': user.userName,
        'email': user.email,
        'timestamp': (new Date()).getTime()
    };

    const bytes = CryptoJS.AES.encrypt(JSON.stringify(ciper), config.AES_SECRET);
    const token = bytes.toString();
    user.token = token;
    return await req.db.User.update({ token, password: token }, { where: { id } })
        .then(data => {
            user.link = `${config.clientUrl}/generatepassword?token=${token}`;
            sendMail(user, `Password reset by Administrator`);
            return res.status(200).send({ status: data });
        }).catch(err => {
            res.status(200).send(err);
        });
};
exports.deleteUser = async (req, res, next) => {

    return await req.db.User.update(
        { status: false },
        {
            where: { id: req.params.id },
        }
    ).then(async () => {
        const updateUser = await req.db.User.findOne({
            where: {
                id: req.params.id
            },
            attributes: {
                exclude: ['password', 'token']
            }
        });
        return res.status(200).send(updateUser);
    })
        .catch(err => {
            res.status(200).send(err);
        })
};

exports.logout = async (req, res, next) => {
    try {
        const { id } = parseObject(req.user);
        await req.db.User.update({
            loggedOutTime: new Date()
        }, {
            where: {
                id
            }
        });
        return res.send(true);
    } catch (error) {
        res.status(500).send({
            message: error.message
        });
    }
};
exports.search = async (req, res, next) => {
    const { status, limit, offset, roles,fromDate, toDate,sort } = req.body;
    let query = {};
    if (roles && roles.length > 0) {
        query = { userRoleId: { [Op.in]: roles } };
    } else {
        query = { userRoleId: { [Op.in]: [2, 3] } };
    }
    if (status && status.length > 0) {
        query = { ...query, status: { [Op.in]: status } };
    } else {
        query = { ...query, status: { [Op.in]: [0, 1] } };
    }
    if (fromDate && toDate) {
        query = { ...query, createdAt: { [Op.between]: [fromDate, toDate] } };
    }
    let sorting;
    if(!!sort){
        sorting = sort
    }else{
        sorting = 'DESC'
    }
    const orderBy = [['createdAt', sorting]]
    const data = await req.db.User.findAndCountAll({
        where: query,
        attributes: {
            exclude: ['password',]
        },
        include: [
            {
                model: req.db.UserRole,
                attributes: ['role']
            },
            {
                model: req.db.Address,
                as: 'bAddress',
                include: ['Country', 'State', 'City']

            }
        ],
        limit,
        offset,
        order: orderBy
    });

    res.status(200).json({ status: true, data });
};
exports.isAdmin = async (req, res, next) => {
    if (req.jwtPayload && req.jwtPayload.userRoleId == 1) {
        next()
    } else {
        return res.status(200).json({ status: false, errors: [{ msg: 'You are not authorised' }] })
    }
}
exports.MeData = async (req) => {
    if (req.jwtPayload && req.jwtPayload.id) {
        return await req.db.User.findOne({
            where: {
                status: 1,
                id: req.jwtPayload.id
            },
            attributes: { exclude: ['password', 'token'] },
            include: [
                {
                    model: req.db.Banks,
                    // as: 'userbank',
                },
                {
                    model: req.db.Address,
                    as: 'bAddress',
                    include: ['Country', 'State', 'City']
                },
                {
                    model: req.db.Address,
                    as: 'residential',
                    include: ['Country', 'State', 'City']
                },
                {
                    model: req.db.Identity,
                    as: 'aadhar',
                    where: { status: 1 },
                    required: false,
                    // attributes:['id','title','description',],
                    include: [
                        {
                            model: req.db.EntityFile,
                            where: { status: 1 },
                            attributes: ['id', 'fileId'],
                            include: [
                                {
                                    model: req.db.File,
                                    where: { status: 1 },
                                    attributes: ['id', 'title']
                                }
                            ]
                        }
                    ]
                }, {
                    model: req.db.Identity,
                    as: 'pan',
                    where: { status: 1 },
                    required: false,
                    // attributes:['id','title','description',],
                    include: [
                        {
                            model: req.db.EntityFile,
                            where: { status: 1 },
                            attributes: ['id', 'fileId'],
                            include: [
                                {
                                    model: req.db.File,
                                    where: { status: 1 },
                                    attributes: ['id', 'title']
                                }
                            ]
                        }
                    ]
                }, {
                    model: req.db.Identity,
                    as: 'gstin',
                    where: { status: 1 },
                    required: false,
                    // attributes:['id','title','description',],
                    include: [
                        {
                            model: req.db.EntityFile,
                            where: { status: 1 },
                            attributes: ['id', 'fileId'],
                            include: [
                                {
                                    model: req.db.File,
                                    where: { status: 1 },
                                    attributes: ['id', 'title']
                                }
                            ]
                        }
                    ]
                }, {
                    model: req.db.Identity,
                    as: 'export',
                    where: { status: 1 },
                    required: false,
                    // attributes:['id','title','description',],
                    include: [
                        {
                            model: req.db.EntityFile,
                            where: { status: 1 },
                            attributes: ['id', 'fileId'],
                            required: false,
                            include: [
                                {
                                    model: req.db.File,
                                    where: { status: 1 },
                                    attributes: ['id', 'title'],
                                    required: false,

                                }
                            ]
                        }
                    ]
                }, {
                    model: req.db.Identity,
                    as: 'import',
                    where: { status: 1 },
                    required: false,
                    // attributes:['id','title','description',],
                    include: [
                        {
                            model: req.db.EntityFile,
                            where: { status: 1 },
                            attributes: ['id', 'fileId'],
                            required: false,
                            include: [
                                {
                                    model: req.db.File,
                                    where: { status: 1 },
                                    attributes: ['id', 'title'],
                                    required: false,
                                }
                            ]
                        }
                    ]
                },
                // {
                //     model: req.db.EntityCommodity,
                //     where: { commodityTypeable: 'user' },
                //     attributes:['id'],
                //     required: false,
                //     include: [
                //         {
                //             model: req.db.Commodity,
                //             // attributes:['fileId'],
                //             where: { status: 1 },
                //             // include:['EntityFile'],
                //             include: [
                //                 {
                //                     model: req.db.EntityFile,
                //                     where: { status: 1 },
                //                     attributes:['id','fileId'],
                //                     required:false,
                //                     include: [
                //                         {
                //                             model: req.db.File,
                //                             where: { status: 1 },
                //                             attributes:['id','title'],
                //                             required:false
                //                         }
                //                     ]
                //                 }
                //             ]
                //         }
                //     ]
                // },
                {
                    model: req.db.EntityCommodity,
                    where: { commodityTypeable: 'user' },
                    required: false,
                    include: [
                        {
                            model: req.db.Commodity,
                            where: { status: 1 },
                            include: [
                                {
                                    model: req.db.EntityFile,
                                    where: { status: 1 },
                                    attributes: ['id', 'fileId'],
                                    include: [
                                        {
                                            model: req.db.File,
                                            where: { status: 1 },
                                            attributes: ['id', 'title']
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                },
                {
                    model: req.db.UserRole,
                    attributes: ['role'],
                    required: false
                },
            ]

        })
        return res.json({ status: user ? true : false, data: user })
    } else {
        return null
    }
}
exports.me = async (req, res, next) => {
    const data = await this.MeData(req)
    if (data) {

        return res.json({ status: data ? true : false, data })
    } else {
        return res.status(200).json({ status: false, errors: [{ msg: 'You are not authorised' }] })
    }
}
exports.saveFirebaseToken = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({status:false, errors: errors.array() });
    }
    try {
        const id = req.jwtPayload.id;
        const {token} = req.body;
        if(!token) {
            return res.json({status:false, data:'Token required'})
        }
        await req.db.FireBaseToken.create({
            token, userId: id
        })
        return res.json({status:true})
    } catch (e) {
        return res.json({status:false})
    }
}
exports.updateFirebaseToken = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({status:false, errors: errors.array() });
    }
    try {
        const id = req.jwtPayload.id;
        const {token, oldToken} = req.body;
        if(!token) {
            return res.json({status:false, data:'Token required'})
        }
        const fb =await req.db.FireBaseToken.findOne({
            where:{token:oldToken,userId:id}
        })
        if(!fb){
            return res.json({status:false})
        }
        await req.db.FireBaseToken.update({token},{where:{id:fb.id}})
        return res.json({status:true})
    } catch (e) {
        return res.json({status:false})
    }
}
exports.removeFirebaseToken = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({status:false, errors: errors.array() });
    }
    try {
        const id = req.jwtPayload.id;
        const {token} = req.body;
        if(!token) {
            return res.json({status:false, data:'Token required'})
        }
        await req.db.FireBaseToken.destroy({
            where:{token,userId:id}
        })
        return res.json({status:true})
    } catch (e) {
        return res.json({status:false})
    }
}
