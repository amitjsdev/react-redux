exports.status={
   user:{
       1:'Approved',0:'Deactive',2:'Rejected',3:'Pending',  	
   },
    trade:{
       0:'Rejected',1:'Pending',
       2:'Live', 
    //    3:'Live ',
    //    4:'Quote Accepted'  ,
    //    5:'Quote Reject',6:'Closed',7:'PO Submitted',8:'PO Accepted',
    //    9:'PO Rejected',10:'Goods in Transit',11:'Good Delivered',12:'Goods Delivery Accepted',
    //    13:'Paid',
       14:'Canceled',15:'Expired',
       98:'QTY Met',
       99:'Closed'

   }, 
   qt:{
       0:'Quote Cancelled',1:'Waiting Quote Acceptance',2:'Quote Accepted'  ,
       3:'Quote Reject',4:'Closed',5:'Waiting PO Acceptance',6:'PO Accepted',
       7:'PO Rejected',8:'Goods in Transit',9:'Good Delivered',10:'Goods Delivery Accepted',
       11:'Paid',12:'PO canceled',
       31:'Delivery Initiated',32:'Dispatched',33:'in Transit',34:'Delivered',
       98:'QTY Met, Closing Quote',
       99:'Closed'

   },
   //transit status 
   ts:{
       1:'Delivery Initiated', 2:'Dispatched',3:'in Transit',4:'Delivered',99:'Closed'
   },
   payment:{
       0:'InActive',1:'Initiated', 2:'Success',3:'Failed',4:'Pending',99:'Closed'
   },
   po:{
       0:'Canceled', 1:'Submitted',2:'Rejected',3:'Accepted',4:'Initiated',99:'Closed'
   },
   entity:{
       0:'Individual',1:'Proprietor',2:'Partnership',3:'Company',4:'Other'
   }
}