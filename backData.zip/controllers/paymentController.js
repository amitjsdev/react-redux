const { check, custom, validationResult } = require('express-validator/check');
const poController = require('./poController')
const sequelize = require('sequelize')
const { Op } = require('sequelize')
const { notify } = require('./tradeController')
var crypto = require('crypto');
const config = require('../config/config');
const axios = require('axios');
const qs = require('qs');
const key = 'BC50nb'
const salt = 'Bwxo1cPe'
// const key= 'gtKFFx'
// const salt= 'wia56q6O'
const payu_base_url = 'https://test.payu.in/'
const payu_verify_url = 'https://test.payumoney.com/payment/op/getPaymentResponse'
exports.validate = (functionName) => {

    switch (functionName) {


        case 'new':
            return [

                check('qid', 'Qoute id  is required').not().isEmpty(),
            ];

        default:
            throw new Error('invalid user controller function name');
    }
};



exports.getQoutePayment = async (req, res, next) => {
    try {
        const where = { qid: req.params.id }
        let data = await req.db.Payment.findOne({
            where,
            include: [
                {
                    model: req.db.Transaction,
                    as: 'transactions',
                    // attributes:{exclude:['']}
                }, {
                    model: req.db.Transaction,
                    as: 'success',
                    where: { transaction_status: 'success' }
                }

            ]
        });
        data = data ? data.toJSON() : {}

        data.po = await poController.QoutePO(req, where, req.params.id)

        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};
exports.getTradePayment = async (req, res, next) => {
    try {
        let qid = await req.db.Qoutes.findAll({
            where: { tradeId: req.params.id },
            attributes: ['id']
        })
        qid = qid && qid.length > 0 ? qid.map(q => q.id) : null;
        if (!qid) {
            return res.status(200).json({ status: true, data: [] });

        }
        const where = { qid: { [Op.in]: qid } }
        let data = await req.db.Payment.findAll({
            where,
            include: [
                {
                    model: req.db.Transaction,
                    as: 'transactions',
                    required:false
                },
                //  {
                //     model: req.db.Transaction,
                //     as: 'success',
                //     where: { transaction_status: 'success' }
                // }

            ]
        });
        console.log(data.length);
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};

const getPaymentRecord = async (req, id) => {
    return await req.db.Payment.findByPk(id, {
        include: [
            {
                model: req.db.Transaction,
                as: 'transactions',

            },


        ],
        order: [['transactions', 'id', 'desc']]

    });
}
exports.getItemById = async (req, res) => {
    try {
        let data = await getPaymentRecord(req, req.params.id)

        if (data) {
            data = data.toJSON()
            const transaction_status = ['success', 'failure']
            if ((data.payu && !data.payu.transaction_status) || (data.payu.transaction_status && !transaction_status.includes(data.payu.transaction_status))) {
                const txnid = data.payu.id + 'TIM' + data.payu.tId;
                const req_status = await verifyStatus(txnid)
                console.log({ req_status });
                if (req_status && req_status.postBackParam && req_status.postBackParam.status != data.payu.transaction_status) {
                    await req.db.Transaction.update({
                        meta: req_status,
                        mode: req_status.mode,
                        transaction_status: req_status.status ? req_status.status : ''

                    }, { where: { id: txnid } })
                }
                data = await getPaymentRecord(req, req.params.id)
                data = data.toJSON()
            }

            let po = await poController.QoutePO(req, { qid: data.qid })
            if (po) {
                // po =po.toJSON()
                data.po = po
            }

        }
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}
exports.getMyPayment = async (req, res) => {
    try {
        const data = await req.db.Payment.findAll({
            where: {
                [Op.or]: [{ buyerId: req.jwtPayload.id }, { sellerId: req.jwtPayload.id, status: 2 }]

            },
            include: [
                {
                    model: req.db.Qoutes,
                    as: 'qt',
                    attributes: ['id'],
                    include: {
                        model: req.db.PurchaseOrder,
                        as: 'po',
                        attributes: ['id']
                    }
                },
                {
                    model: req.db.Transaction,
                    as: 'transactions',

                },


            ],
            order: [['transactions', 'id', 'desc']]


        });
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}


const checkPaymentInitiated = async (req, qid) => {
    return await req.db.Payment.findOne({
        where: {
            status: 1,
            qid
        }

    })
}

exports.createNewItem = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errors: errors.array() });
    }
    const { qid } = req.body;
    const IsPaymentInitiated = await checkPaymentInitiated(req, qid)
    if (IsPaymentInitiated) {
        req.params.id = IsPaymentInitiated.id;
        return this.getItemById(req, res);
    }
    let po = await poController.QoutePO(req, { qid })
    if (!po) {
        return res.json({ status: false, error: 'data not found' })
    }
    //return res.json({status:false, data:po})
    await req.db.PurchaseOrder.update({
        tax: po.taxTotal,
        total: po.total

    },{where:{qid}})
    const creater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0;
    let price = po.qt.price;
    let quantity = po.qt.quantity;
    let amount = po.total
    let commision = po.platformCharge;
    let tax = po.taxTotal;
    let total = po.total;
    let data = {
        price,
        quantity,
        mode: 'PayU',
        amount,
        commision,
        tax,
        total,
        qid: qid,
        createdBy: creater,
        sellerId: po.seller_id,
        buyerId: po.buyer_id
    }
    // console.log({data});
    const item = await req.db.Payment.create(data);
    await req.db.Qoutes.update({ status: 11 }, { where: { id: qid } })

    if (item && item.id) {
        await req.db.Transaction.create({
            ...data,
            paymentId: item.id,
            transaction_status: 'success'
        })
        req.params.id = item.id;
        return this.getItemById(req, res);
    } else {
        return res.status(200).json({ status: false });
    }
};

exports.updateItem = async (req, res, next) => {
    try {
        const { qid } = req.body;
        const IsPaymentInitiated = await checkPaymentInitiated(req, qid)
        if (IsPaymentInitiated) {
            req.params.id = IsPaymentInitiated.id;
            return this.getItemById(req, res);
        }
        let po = await poController.QoutePO(req, { qid })
        if (!po) {
            return res.json({ status: false, error: 'data not found' })
        }
        const data = await req.db.Payment.findOne({
            where: { qid, status: 1 },
            include: [
                {
                    model: req.db.Transaction,
                    as: 'transactions',
                    // attributes:{exclude:['']}
                }, {
                    model: req.db.Transaction,
                    as: 'success',
                    where: { transaction_status: 'success' }
                }

            ]
        });
        return res.status(200).json({ status: true, data });
        // const arr =[
        // 'buyer_contact_person', 'buyer_contact_number', 'buyer_address',
        // 'delivery_acceptance','seller_contact_person','seller_contact_number',
        // 'tracking_number','vehicle_number','transit_address','transit_status',
        // 'expected_delivery_date','delivery_initiated_date','delivery_date',
        // ]
        // arr.map(key=>{
        //     if(key && req.body[key]){
        //         query = { ...query, [key]:req.body[key] }; 
        //     }
        // })
        // const updater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0
        // if (Object.keys(query).length > 0) {
        //     query = { ...query, updatedBy: updater }
        //     await req.db.Transit.update(query, { where: { id } })
        // }

    } catch (error) {
        console.log({ error });
        return res.json({ status: false, error })
    }

};

exports.deleteItem = async (req, res, next) => {

    return await req.db.PurchaseOrder.update(
        { status: false },
        {
            where: { id: req.params.id },
        }
    ).then(async () => {
        return this.getItemById(req, res);
    })
        .catch(err => {
            res.status(200).send(err);
        })
};


// webview payment 
const generateHash = async (payuData) => {
    var cryp = crypto.createHash('sha512');
    // sha512(key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5||||||SALT)

    var text = payuData.key + '|' + payuData.txnid + '|' + payuData.amount + '|' + payuData.productinfo
        + '|' + payuData.firstname + '|' + payuData.email + '|'
        + payuData.udf1 + '|' + payuData.udf2 + '|' + payuData.udf3 + '|' + payuData.udf4 + '|' + payuData.udf5 + '||||||'
        + payuData.salt;
    console.log({ text });
    cryp.update(text);
    return cryp.digest('hex');
}
// MerchantId: 4825049
// key: BC50nb
// Salt: Bwxo1cPe
const preparePayuData = (data, id) => {
    // const paymentParts = {
    //     name: "splitID1",
    //     value: 1,
    //     merchantId: '4825049',
    //     description: 'test description',
    //     commission: 1
    // };
    const paymentParts = {
        "paymentParts":
            [{ "name": "testchild1@bK.cc", "description": "test", "value": (data.amount - data.commision).toFixed(2), "merchantId": "4825050", "commission": data.commision.toFixed(2) },
            ]
    }
    // const paymentParts= {"paymentParts":[{"name":"Invoice#265~11d6e214-344f-45a3-971e-e654763185ce","description":"test","value":".5","merchantId":"4825050","commission":".5"}]}


    const payuData = {
        key,
        txnid: id,
        amount: data.amount,
        productinfo: JSON.stringify(paymentParts),
        firstname: data.buyer.first_name,
        email: data.buyer.email,
        mobile: data.buyer.mobile,
        udf1: '',
        udf2: '',
        udf3: '',
        udf4: '',
        udf5: '',
        salt
    }
    return payuData

}

const verifyStatus = async (txnid) => {
    console.log({ txnid });
    var config = {
        method: 'post',
        url: `${payu_verify_url}?merchantKey=${key}&merchantTransactionIds=${txnid}`,
        headers: {
            'authorization': 'Ki5bSM5oiDd1xDnpM9YCGgXTweuLYGIReZQmDA4ekrk='
        }
    };

    return axios(config)
        .then(function ({ data, status }) {
            console.log({ data });
            if (status == 200 && data && data.result && data.result[0]) {
                return { status: true, data: data.result[0] }
            } else {
                return { status: false, data }
            }
        })
        .catch(function (error) {
            return { status: false, data: error }
        });
}
exports.PayUGetHandler = async (req, res, next) => {
    // const req_status = await verifyStatus('57TIM1625460327933')
    //     return res.json(req_status)
    let error = ''
    const { qid } = req.params
    const data = await req.db.Payment.findOne({
        where: { qid, buyerId: req.jwtPayload.id },
        include: ['buyer']
    });

    if (!data) {
        error = 'Invalid Payment'
        return res.render(__dirname + '/../view/response.html', { error });
    }
    if (data && data.status == 2) {
        error = 'Payment already completed'
        return res.render(__dirname + '/../view/response.html', { error });
    }
    const url = `${payu_base_url}_payment`
    const surl = config.surl  //"http://localhost:8003/payment/status/check";
    const furl = config.furl //"http://localhost:8003/payment/status/check";

    const t = (new Date()).getTime()
    const created = await req.db.Transaction.create({
        qId: qid,
        paymentId: data.id,
        mode: 'payu',
        amount: data.amount,
        createdBy: req.jwtPayload.id,
        tId: t
    })
    if (!created) {
        error = 'Something went wrong'
        return res.render(__dirname + '/../view/response.html', { error });
    }
    const payuData = await preparePayuData(data, created.id + 'TIM' + t);

    const hash = await generateHash(payuData)
    console.log('send hash', hash);
    return res.render(__dirname + '/../view/checkout.html', { payuData, hash, url, surl, furl });
}


exports.PayUPostHandler = async (req, res, next) => {
    const { body } = req;
    const { status, txnid } = body
    console.log({ body });
    let error = ''
    if (body && txnid) {
        let id = '';
        console.log(txnid);
        id = txnid.split('TIM');

        id = id && id[0] ? id[0] : null
        console.log(id);
        if (!id) {
            error = 'Invalid Transaction ID'
            return res.render(__dirname + '/../view/response.html', { error });

        }
        const transaction = await req.db.Transaction.findByPk(id, {
            include: [
                {
                    model: req.db.Payment,
                    as: 'payment',
                    // include:['buyer']
                }
            ]
        })
        if (!transaction) {
            error = 'Invalid Transaction ID'
            return res.render(__dirname + '/../view/response.html', { error });
        }
        const req_status = await verifyStatus(txnid)
        // return res.json(req_status)
        if (!req_status) {
            error = 'Invalid Payment response'
            return res.render(__dirname + '/../view/response.html', { error });
        }
        if (req_status.postBackParam && req_status.postBackParam.status != status) {
            error = 'Invalid Payment response'
            return res.render(__dirname + '/../view/response.html', { error });
        }

        await req.db.Transaction.update({
            meta: { body, req_status },
            mode: body.mode,
            transaction_status: status ? status : ''

        }, { where: { id } })

        if (status == 'success') {
            error = 'Payment completed'
            await req.db.Payment.update({
                status: 2
            }, { where: { id: transaction.payment.id } })
        } else {

            await req.db.Payment.update({
                status: 3
            }, { where: { id: transaction.payment.id } })
            error = `Payment ${status} : ${body.error_Message}`;
        }

        notify(req, 'payment', status, transaction, [transaction.payment.sellerId, transaction.payment.buyerId], transaction.id)
        return res.render(__dirname + '/../view/response.html', { error });
    }

    return res.json(body)
}