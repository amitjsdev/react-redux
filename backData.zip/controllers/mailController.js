var nodemailer = require("nodemailer");
const config = require('../config/config');

let transporter = nodemailer.createTransport(
    {
        host: config.smtpHost,
        port: config.smtpPort,
        secure: false,
        secureConnection: false,
        auth: {
            user: config.smtpUser,
            pass: config.smtpPassword
        },
        logger: true,
        debug: false
    },
    {
        from: `${config.smtpFromName} <${config.smtpFromEmail}>`,
        headers: {
            'X-Laziness-level': 1000
        }
    }
);

const getTemplate = async (req, name) => {
    let data = await req.db.EmailTemplate.findOne({
        where: { name }
    })
    return data ? data.toJSON() : null
}

const parseTemplate = (template, data) => {
    template = template.split('<<');
    template = template.map(item => {
        if (item && item.includes('>>')) {
            let sub = item.substr(0, item.indexOf('>>'));
            if (data && data[sub]) {
                item = item.replace(sub, data[sub])
            } else {
                item = item.replace(sub, '')
            }
           

        }
        return item.replace('>>', '')
    })
   return template.join('')
}

exports.sendMail = async (req, name, data) => {
    const template = await getTemplate(req, name)
    if (!template) {
        console.log('email template not found', name);
        return { status: false, data: 'Template not found' }
    }
    const html = parseTemplate(template.body, data);
    console.log({html});

    const mailOptions = {
        from: `${config.smtpFromName} <${config.smtpFromEmail}>`,
        to: `${data.toemail ? data.toemail  :data.email  }`,
        subject: template.subject,
        html
    }

    transporter.sendMail(mailOptions, function (error, response) {
        if (error) {
            console.log(error);
        } else {
            console.log("Message sent: " + response.message);
        }
    });
}