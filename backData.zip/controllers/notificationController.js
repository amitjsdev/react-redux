const parseObject = require('../services/helpers');
const fbAdmin = require('firebase-admin');
const axios = require('axios');
const { Op } = require('sequelize');
const notificationService = require('../services/notificationService')
const serviceAccount = require("../firebase.json");
fbAdmin.initializeApp({
    credential: fbAdmin.credential.cert(serviceAccount)
});
const parseTemplate = (template, data) => {
    template = template.split('<<');
    template = template.map(item => {
        if (item && item.includes('>>')) {
            let sub = item.substr(0, item.indexOf('>>'));
            if (data && data[sub]) {
                item = item.replace(sub, data[sub])
            } else {
                item = item.replace(sub, '')
            }


        }
        return item.replace('>>', '')
    })
    return template.join('')
}

exports.validate = method => {
    switch (method) {
        default:
            return [];
    }
};
const getRecords = async (req, where) => {
    const toUserId = req.jwtPayload.id;
    let { limit } = req.query;
    limit = limit ? parseInt(limit) : 10000;
    var fetchNotifications = await req.db.UserNotification.findAll({
        where,
        include: [
            {
                model: req.db.Notification
            },
            {
                model: req.db.User,
                as: 'Assignor',
                attributes: ['id', 'email', 'first_name'],
                include: ['UserRole']
            },
            {
                model: req.db.User,
                as: 'Assignee',
                attributes: ['id', 'email', 'first_name'],
                include: ['UserRole']
            }
        ],
        order: [
            ['createdAt', 'DESC']
        ],
        limit
    });
    if (fetchNotifications.length > 0) {
        for (let fetchNotification of fetchNotifications) {

            fetchNotification.dataValues.content = fetchNotification.dataValues.Notification.content;
            if (fetchNotification && fetchNotification.Assignor && fetchNotification.id) {
                fetchNotification.dataValues.content = fetchNotification.dataValues.content
                    .replace('<<userName>>', ` ${fetchNotification.Assignor.userName}`)
                    .replace('<<first_name>>', ` ${fetchNotification.Assignor.first_name}`)
                    .replace('<<userType>>', ` ${fetchNotification.Assignor.userRoleId == 3 ? 'seller' : 'buyer'}`)
                    .replace('<<email>>', ` ${fetchNotification.Assignor.email}`);
            }

        }
    }
    //fetchNotifications = fetchNotifications.map(notifications => ({ ...notifications.dataValues, entity: notifications.dataValues.entity,content:notifications.dataValues.Notification.content }));
    return fetchNotifications;

}
var getAllNotificationsData = exports.getAllNotifications = async (req, res) => {
    const toUserId = req.jwtPayload.id;
    const where = {
        status: 1,
        toUserId,
    }
    return await getRecords(req, where);

};



exports.getNotification = async (req, res, next) => {
    const newUser = await req.db.User.findAll({ where: { status: 3, userRoleId: { [Op.notIn]: [1] } } })
    const newTrade = await req.db.Trade.findAll({ where: { status: 1 } })
    try {
        let data = await getAllNotificationsData(req, res);
        if (data && data.length > 0) {
            data = data.map(item => {
                let datum = {}
                if (item && item.Notification) {
                    const toParse = {
                        first_name: item.Assignor && item.Assignor.first_name ? item.Assignor.first_name : '',
                        email: item.Assignor && item.Assignor.email ? item.Assignor.email : '',
                        userType: item.Assignor && item.Assignor.UserRole && item.Assignor.UserRole.role ? item.Assignor.UserRole.role : '',

                    }

                    datum = {
                        type: item.Notification.entity,
                        id: item.entityId,
                        subject: parseTemplate(item.Notification.subject, toParse),
                        content: parseTemplate(item.Notification.content, toParse),
                        createdAt: item.createdAt,
                        isRead: item.isRead
                    }
                }

                return datum;
            })
        }
        return res.status(200).json({
            data,
            newUser: newUser ? newUser.length : 0,
            newTrade: newTrade ? newTrade.length : 0,
        });
    } catch (error) {
        console.log(error);
        return res.status(500).send(error);
    }
}


exports.markNotificationsRead = async (req, res, next) => {
    const { notifications } = req.body;
    try {
        const result = await req.db.UserNotification.update({
            isRead: 1
        }, {
            where: {
                id: { [Op.in]: notifications }
            }
        });
        await this.getUserNotificationCount(req);
        return res.status(200).json(result);
    } catch (error) {
        console.log(error);
        return res.status(500).send(error);
    }
}

exports.markNotificationsUnRead = async (req, res, next) => {
    const { notifications } = req.body;
    try {
        const result = await req.db.UserNotification.update({
            isRead: 0
        }, {
            where: {
                id: { [Op.in]: notifications }
            }
        });
        await this.getUserNotificationCount(req, true);
        return res.status(200).json(result);
    } catch (error) {
        console.log(error);
        return res.status(500).send(error);
    }
};
var getTask = async (req, id) => {
    let task;
    const taskObj = await req.db.EntityTask.findOne({
        where: {
            id
        },
        attributes: ['title'],


    });
    if (taskObj != undefined) {

        task = taskObj.dataValues.title;
    }
    return task;
};

exports.getUserNotificationCount = async (req) => {
    const { id: userId } = req.jwtPayload;
    let notificatios = await req.db.UserNotification.findAll({
        where: {
            status: 1,
            isRead: 0,
            toUserId: userId
        }
    });
    const notificatiosCount = notificatios && notificatios.length ? notificatios.length : 0;
    await req.db.User.update({ notification: notificatiosCount }, { where: { id: userId } });
    return notificatiosCount;
};

exports.getNotificationsUnReadCount = async (req, res) => {
    var fetchNotifications = await this.getUserNotificationCount(req);

    return res.status(200).json({ status: true, data: fetchNotifications ? fetchNotifications : 0 })
}
exports.getNotificationsUnRead = async (req, res) => {
    const toUserId = req.jwtPayload.id;
    const where = {
        status: 1,
        toUserId,
        isRead: 0
    }
    const data = await getRecords(req, where);
    return res.status(200).json({ status: true, data })
}
exports.getConfig = async (req, configurationName) => {
    let data = await req.db.Configuration.findOne({ where: { configurationName, status: 1 } })
    data = data.toJSON()
    //    console.log({data});
    return data && data.value ? data.value : ''
}
exports.sendSMS = async (req, mobile, entity, entityStage, data) => {
    const sms_username = await this.getConfig(req, 'sms_username')
    const sms_password = await this.getConfig(req, 'sms_password')
    let template = await req.db.Notification.findOne({ where: { entity, entityStage } })

    if (!template || !sms_username || !sms_password) {
        console.log({ template, sms_username, sms_password });
        console.log('Please set DB', template, sms_username, sms_password);
        return { status: false, data: 'SET DB' }
    }

    let str = parseTemplate(template.content, data)
    const url = `http://login.bulksmsservice.net.in/api/mt/SendSMS?user=${sms_username}&password=${sms_password}&senderid=VALUEI&channel=TRANS&DCS=0&flashsms=0&number=${mobile}&text=${str}&route=19`;
    console.log({ url });
    var config = {
        method: 'get',
        url,
        headers: {}
    };

    return axios(config)
        .then(function (response) {
            console.log(JSON.stringify(response.data));
            return { status: true }
        })
        .catch(function (error) {

            console.log(error);
            return { status: false, data: error }
        });

}
exports.fbNotification = async (req, users, entity, entityStage, data) => {
    const sms_username = await this.getConfig(req, 'sms_username')
    const sms_password = await this.getConfig(req, 'sms_password')
    let template = await req.db.Notification.findOne({ where: { entity, entityStage } })

    if (!template || !sms_username || !sms_password) {
        console.log({ template, sms_username, sms_password });
        console.log('Please set DB');
        return { status: false, data: 'SET DB' }
    }

    let str = parseTemplate(template.content, data)
    let tokens = [];
    for (const user of users) {
        if (user && user.fb && user.fb.length > 0) {
            for (const row of user.fb) {
                if (row.token) {
                    tokens.push(row.token)
                }
            }
        }
    }
    if (tokens && tokens.length > 0) {


        try {
        const kuchhHuaa = await fbAdmin.messaging().sendToDevice(
            tokens, // ['token_1', 'token_2', ...]
            {
                data: {
                    msg: str,
                    entity, entityStage, data: JSON.stringify(data)
                },
            },
            {
                // Required for background/quit data-only messages on iOS
                contentAvailable: true,
                // Required for background/quit data-only messages on Android
                priority: 'high',
            },
        );
        console.log({ kuchhHuaa });
        // console.log( kuchhHuaa.results);
        } catch (e) {
            console.log(e);
        }
       
    }

}

exports.test = async (req, res) => {
    // const data ={
    //     first_name:'lak',
    //     userType:'Seller',
    //     email:'email'
    // }
    // const ck =await notificationService.addNotification(req, 1,'user','signup',data)  
    const data = {
        first_name: 'lak',
        userType: 'Seller',
        email: 'email',
        title: 'I need bajra',

    }
    const to = 1;
    const from = 33;
    const entityId = 1;
    const entityStage = 'created';
    const entity = 'request'
    const ck = await notificationService.addNotification(req, to, from, entity, entityStage, entityId, data)
    return res.json({ ck })
}
