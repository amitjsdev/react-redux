const { check, custom, validationResult } = require('express-validator/check');
const fileController = require('./filesController')
const sequelize = require('sequelize')
const { Op } = require('sequelize')
const {notify} = require('./tradeController')
exports.validate = (functionName) => {

    switch (functionName) {


        case 'new':
            return [
                // check('comment', 'Comment required and must be at least 3 characters long').isLength({ min: 3 }),
                // check('document', 'Purchase document  is required').not().isEmpty(),
                check('qid', 'Qoute id  is required').not().isEmpty(),


            ];

        default:
            throw new Error('invalid user controller function name');
    }
};
const include =(req)=>{
    return [
        {
            model: req.db.User,
            as: 'buyer',
            attributes: ['id', 'first_name', 'last_name'],
            include:[
                {
                    model:req.db.Address,
                    as:'bAddress',
                    include:['Country','State','City']

                }
                
            ]
        },
        {
            model: req.db.User,
            as: 'seller',
            attributes: ['id', 'first_name', 'last_name'],
            include:[
                {
                    model:req.db.Address,
                    as:'bAddress',
                    include:['Country','State','City']

                }
                
            ]
        },
      
        {
            model: req.db.Qoutes,
            as: 'qt',
            include:{
                model:req.db.Trade,
                as:'trade',
                attributes:['id','title'],
                include:['unit','commodity']
            }
            // attributes: ['id', 'description']
        }


    ]
}
exports.QoutePO = async (req,where,checkDeliveryid=false) => {
        let data = await req.db.PurchaseOrder.findOne({
            where,
            include: include(req)
        });
        let taxes =await req.db.Tax.findAll({where:{status:1}})
        let hasDelivery =false;
        const platformCharge =12
        if(checkDeliveryid){
            hasDelivery= await req.db.Transit.findOne({where:{qid:checkDeliveryid}}) 
        }
        if(data){
            let price =data.qt.price ? data.qt.price :0
            price =parseFloat(price)
           
            let  total =price+platformCharge 
            total =parseFloat(total.toFixed(2))
            data =data.toJSON()
            let taxTotal =0
            if(taxes && taxes.length > 0){
                taxes = taxes.map(tax=>{
                    tax =tax.toJSON()
                    tax.cal =0
                    // if(data.seller.bAddress && data.buyer.bAddress ){
                       
                    //     if(tax.name ==='CSGT' && data.seller.bAddress.state == data.buyer.bAddress.state){
                    //         const t =((subtotal*(parseFloat(tax.value)))/100)
                    //         taxTotal =taxTotal+t
                    //         total =total+t;
                    //         tax.tax =t.toFixed(2)
                    //     }
                    //     if(tax.name ==='SGST' && data.seller.bAddress.state == data.buyer.bAddress.state){
                    //         const t =((subtotal*(parseFloat(tax.value)))/100)
                    //         taxTotal =taxTotal+t
                    //         total =total+t;
                    //         tax.tax =t.toFixed(2)
                    //     }
                    //     if(tax.name ==='IGST' && data.seller.bAddress.state != data.buyer.bAddress.state){
                    //         const t =((subtotal*(parseFloat(tax.value)))/100)
                    //         taxTotal =taxTotal+t
                    //         total =total+t;
                    //         tax.tax =t.toFixed(2)
                    //     }
                    // } else {
                    //     if(tax.name ==='IGST' ){
                    //         const t =((subtotal*(parseFloat(tax.value)))/100)
                    //         taxTotal =taxTotal+t
                    //         total =total+t;
                    //         tax.tax =t.toFixed(2)
                    //     } 
                    // }
                    const t =((total*(parseFloat(tax.value)))/100)
                            taxTotal =taxTotal+t
                            total =total+t;
                            tax.tax =t.toFixed(2)
                  return tax  

                })
            }
           
            data.taxTotal =taxTotal
            data.taxes =taxes
            data.total =total
            data.platformCharge =platformCharge
            data.payable =data.total
            data.hasDelivery =hasDelivery ? hasDelivery.id :null
        }
       return data
};

exports.getQoutePO = async (req, res, next) => {
   
    try {
        const where ={qid:req.params.id,
            // status:{[Op.in]:[-1,1]}
        }
        let data = await this.QoutePO(req, where,req.params.id)
        return res.status(200).json({ status: true, data });
    } catch (error) {
        return res.status(500).send({ status: false, error });
    }
};
exports.getTradePO = async (req, res, next) => {
   
    try {
        let qid = await req.db.Qoutes.findAll({
            where:{tradeId:req.params.id},
            attributes:['id']
        })
        qid = qid && qid.length > 0 ? qid.map(q=>q.id): null;
        if(!qid){
            return res.status(200).json({ status: true, data:[] });
           
        }
        const where ={qid:{[Op.in]:qid}}
        let data = await req.db.PurchaseOrder.findAll({
            where,
            include: include(req)
        });
        return res.status(200).json({ status: true, data });
       
    } catch (error) {
        return res.status(500).send({ status: false, error });
    }
};

exports.getItemById = async (req, res) => {
    try {
        const data = await req.db.PurchaseOrder.findOne({
            where:{id:req.params.id},
            include: [
                {
                    model: req.db.User,
                    as: 'seller',
                    attributes: ['id', 'first_name', 'last_name'],
                    required:false,
                    include:[
                        {
                            model:req.db.Address,
                            as:'bAddress',
                            include:['Country','State','City']

                        }
                        
                    ]
                },
                {
                    model: req.db.User,
                    as: 'buyer',
                    attributes: ['id', 'first_name', 'last_name'],
                    required:false,
                    include:[
                        {
                            model:req.db.Address,
                            as:'bAddress',
                            include:['Country','State','City']

                        }
                        
                    ]
                },
                {
                    model: req.db.Qoutes,
                    as: 'qt',
                    include:{
                        model:req.db.Trade,
                        as:'trade',
                        attributes:['id'],
                        include:['unit','commodity']
                    }
                    // attributes: ['id', 'description']
                }

            ]
        });
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({error});
        return res.status(500).send({ status: false, error });
    }
}


exports.createNewItem = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errors: errors.array() });
    }
    const creater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0;
    const {qid}=req.body;
    const qoute =await req.db.Qoutes.findOne({
        where:{id:qid},
        include:'trade'
    })
    if(!qoute){
        return res.json({status:false, msg:'Qoute not found'})
    }
    if(!qoute.trade){
        return res.json({status:false, msg:'Trade not found'})
    }
    
    const item = await req.db.PurchaseOrder.create({
        qid,
        // buyer_comment:comment ? comment:'',
        createdBy: creater,
        status:4,
        seller_id:qoute.createdBy,
        buyer_id:qoute.trade.createdBy
    });

    if (item && item.id ) {
        // if(req.body.document){
        //     await fileController.addFile(req, req.body.document, creater, 'po', item.id)
        // }
       
        // return res.status(200).json({ status: true, data: item });
        req.params.id=item.id;
       
        return this.getItemById(req, res);
    } else {
        return res.status(200).json({ status: false });
    }
};

exports.updateItem = async (req, res, next) => {
    try {
        let query = {};
        let query2 = {};
        const id = req.params.id;
        
        const {status,qid,tax,total}=req.body
        if(!!tax){
            query = {tax: tax }
        }
        if(!!tax){
            query = { tax: tax }
        }
        if(status=='cancel'){
            query = { status:0, canceledAt: new Date() }
            query2 = { status:12  }
        }
        if(status=='submit'){
            query = { status:1, submittedAt: new Date() }
            query2 = { status:5  }
        }
        if(status=='reject'){
            query = { status:2, rejectedAt: new Date() }
            query2 = { status:7  }
        }
        if(status=='accept'){
            query = { status:3, acceptedAt: new Date() }
            query2 = { status:6  }
        }
        const updater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0
        if (Object.keys(query).length > 0) {
            query = { ...query, updatedBy: updater }
            await req.db.PurchaseOrder.update(query, { where: { id } })
            await req.db.Qoutes.update(query2, { where: { id:qid } })
        }
        const where ={qid:req.body.qid}
        let data = await this.QoutePO(req, where)
        if(status =='accept'){
            notify(req, 'po','accept',data.qt.trade,[data.qt.createdBy],id)
        } else {
            notify(req, 'po',status,data.qt.trade,[data.qt.trade.createdBy],id)
        }
       
        return res.json({status:true, data});
    } catch (error) {
        console.log({error});
        return res.json({ status: false, error })
    }

};

exports.deleteItem = async (req, res, next) => {

    return await req.db.PurchaseOrder.update(
        { status: false },
        {
            where: { id: req.params.id },
        }
    ).then(async () => {
        return this.getItemById(req, res);
    })
        .catch(err => {
            res.status(200).send(err);
        })
};


