const { check, validationResult } = require('express-validator/check');
const sequelize = require('sequelize')
const { Op } = require('sequelize')
const moment = require('moment')
const util = require('./util')
const clients = require('../services/clients')
const notificationService = require('../services/notificationService')
const { sendMail } = require('./mailController');
const { sendSMS, fbNotification } = require('./notificationController');
exports.validate = (functionName) => {

    switch (functionName) {


        case 'new':
            return [
                check('description', 'Description required and must be at least 3 characters long').isLength({ min: 3 }),
                check('quantity', 'Quantity  is required').not().isEmpty().isLength({ min: 0, max: 10000000 }),
                check('closeDate', 'Close Date  is required').not().isEmpty(),


            ];
        case 'approveReject':
            return [
                check('status', 'Status is required ').isNumeric({ min: 0, max: 30 }),
            ];
        default:
            throw new Error('invalid user controller function name');
    }
};
exports.checkTrade = async (req = null, res = null) => {
    console.log('crons ');
    const db = await clients.getClientAllModels()

    if (db) {
        if (!req) {
            req = { db }
        }
        console.log('cron db found', moment());
        const rows = await db.Trade.findAll({
            where: {
                status: { [Op.in]: [2, 3] },
                closeDate: { [Op.lte]: moment() }
            },
            attributes: [
                'id', 'title', 'unitId', 'description', 'closeDate', 'broadcastDate', 'status', 'quantity', 'createdAt', 'updatedAt', 'createdBy', 'is_canceled', 'canceled_at', 'rejected_at', 'statusStr',

                [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'anyQt'],
                [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >1 )'), 'anyQtAccepted'],
                [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status =1 )'), 'toInformQt'],

            ],
            include: [
                {
                    model: db.Qoutes,
                    where: { status: 1 },
                    as: 'Qoutes',
                    required: false
                }
            ]
        })

        if (rows && rows.length > 0) {
            for (const t of rows) {
                let toSend = []
                const status = t.anyQtAccepted && t.anyQt > t.anyQtAccepted ? 15 : 99;
                t.status = status;
                t.save();
                toSend.push(t.createdBy)
                console.log({toSend});
                if (t.Qoutes && t.Qoutes.length > 0) {
                    for (const qt of t.Qoutes) {
                        this.notify(req, 'qoute', 'closed', t, [qt.createdBy], qt.id);
                        qt.status = 99;
                        qt.save()
                        toSend.push(qt.createdBy)
                    }
                }
                if (toSend && toSend.length > 0) {
                    this.notify(req, 'request', status == 99 ? 'closed' : 'expired', t, toSend, t.id);
                }
            }
        }
        if (res) {
            return res.json(rows)
        }


        
    }
}
const getAllRecords = async (req, where, limit = 10, offset = 0, orderBy) => {

    limit = parseInt(limit);
    offset = parseInt(offset)
    const q = {
        where,
        subQuery: false,
        attributes: [
            [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'total'],
            [sequelize.literal('(SELECT MAX(qoutes.price) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'maxPrice'],
            [sequelize.literal('(SELECT MIN(qoutes.price) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'minPrice'],
            [sequelize.literal('(SELECT SUM(qoutes.quantity) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status NOT IN (0,1,3,4,99) )'), 'acceptedQty'],
            [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status NOT IN (0,1,3,4,99) )'), 'Acceptedtotal'],
            'id', 'title', 'unitId', 'description', 'closeDate', 'broadcastDate', 'status', 'quantity', 'createdAt', 'updatedAt', 'is_rejected', 'is_canceled', 'canceled_at', 'rejected_at', 'statusStr',

        ],
        group: ['Trade.id'],
        order: orderBy,
        include: [
            {
                model: req.db.User,
                as: 'CreatedUser',
                attributes: ['id', 'first_name', 'last_name']
            },
            {
                model: req.db.User,
                as: 'UpdatedUser',
                attributes: ['id', 'first_name', 'last_name']
            },
            {
                model: req.db.Commodity,
                as: 'commodity',
                attributes: ['id', 'name', 'description']
            },
            {
                model: req.db.Unit,
                as: 'unit',
                attributes: ['id', 'name']
            },
            {
                required: false,
                model: req.db.Qoutes,
                as: 'Qoutes',
                where: { status: { [Op.gte]: 1 } },
                // attributes: ['id','min_price','max_price'],

            }

        ],

    };
    let count = await req.db.Trade.findAll(q);
    count = count && count.length ? count.length : 0;
    const data = await req.db.Trade.findAll({ ...q, limit, offset });
    return { count, data }
}
const getAllRecordsOfAUser = async (req, where, limit = 10, offset = 0, orderBy) => {
    limit = parseInt(limit);
    offset = parseInt(offset)
    const q = {
        where,
        subQuery: false,

        order: orderBy,
        attributes: [

            [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'total'],
            [sequelize.literal('(SELECT MAX(qoutes.price) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'maxPrice'],
            [sequelize.literal('(SELECT MIN(qoutes.price) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'minPrice'],
            [sequelize.literal('(SELECT SUM(qoutes.quantity) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status NOT IN (0,1,3,4,99) )'), 'acceptedQty'],
            [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status NOT IN (0,1,3,4,99) )'), 'Acceptedtotal'],
            'id', 'title', 'unitId', 'description', 'closeDate', 'broadcastDate', 'status', 'quantity', 'remaining', 'createdAt', 'updatedAt', 'is_rejected', 'is_canceled', 'canceled_at', 'rejected_at', 'statusStr',
        ],
        // group: ['Trade.id'],
        include: [
            {
                model: req.db.Commodity,
                as: 'commodity',
                required: true
            },
            {
                model: req.db.Unit,
                as: 'unit',
                required: true,
                attributes: ['name']
            },

        ]

    };
    let count = await req.db.Trade.findAll(q);
    count = count && count.length ? count.length : 0;
    let data = await req.db.Trade.findAll({ ...q, limit, offset });
    if (data && data.length > 0) {
        data = data.map(datum => {
            datum = datum.toJSON()
            return {
                ...datum,
                remaining: datum.quantity && datum.acceptedQty ? datum.quantity - parseFloat(datum.acceptedQty) : datum.quantity
            }
        })
    }
    return { count, data }
}
const getAllQoutesOfSeller = async (req, where, limit = 10, offset = 0, orderBy) => {
    limit = parseInt(limit);
    offset = parseInt(offset)
    const q = {
        where,
        subQuery: false,
        order: orderBy,
        include: [
            {
                required: true,
                model: req.db.Trade,
                as: 'trade',
                attributes: [
                    [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = trade.id AND qoutes.status >0 )'), 'total'],
                    [sequelize.literal('(SELECT MAX(qoutes.price) FROM qoutes WHERE qoutes.tradeId = trade.id AND qoutes.status >0 )'), 'maxPrice'],
                    [sequelize.literal('(SELECT MIN(qoutes.price) FROM qoutes WHERE qoutes.tradeId = trade.id AND qoutes.status >0 )'), 'minPrice'],
                    [sequelize.literal('(SELECT SUM(qoutes.quantity) FROM qoutes WHERE qoutes.tradeId = trade.id AND qoutes.status NOT IN (0,1,3,4,99) )'), 'acceptedQty'],
                    [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = trade.id AND qoutes.status NOT IN (0,1,3,4,99) )'), 'Acceptedtotal'],
                    'id', 'title', 'unitId', 'description', 'closeDate', 'broadcastDate', 'status', 'quantity', 'createdAt', 'updatedAt', 'is_rejected', 'is_canceled', 'canceled_at', 'rejected_at', 'statusStr',

                ],

                include: [
                    {
                        model: req.db.Commodity,
                        as: 'commodity',
                        attributes: ['name', 'id'],
                        required: true,
                    },
                    {
                        model: req.db.Unit,
                        as: 'unit',
                        attributes: ['name', 'id'],
                        required: true,
                    },

                ]
            }
        ]
    };

    let count = await req.db.Qoutes.findAll(q);

    count = count && count.length ? count.length : 0;
    let data = await req.db.Qoutes.findAll({ ...q, limit, offset });

    return { count, data }
}
exports.Overview = async (req) => {
    const q = {

        attributes: [
            'status', 'statusStr',
            [sequelize.fn('count', sequelize.col('status')), 'count'],
        ],
        where: {
            status: { [Op.in]: [0, 1, 2, 3, 14, 15, 99] }
        },
        group: ['Trade.status']
    };
    const results = await req.db.Trade.findAll(q);
    return results;
}
exports.Earning = async (req) => {
    const q = {
        attributes: [
            [sequelize.fn('sum', sequelize.col('Payment.amount')), 'amount'],
            [sequelize.fn('sum', sequelize.col('total')), 'total'],
            [sequelize.fn('sum', sequelize.col('tax')), 'tax'],
            [sequelize.fn('sum', sequelize.col('Payment.commision')), 'commision'],
        ],

        include: [{
            model: req.db.Transaction,
            as: 'transactions',
            required: true,
            attributes: [],
            where: { transaction_status: 'SUCCESS' }
        }]
    }
    let results = await req.db.Payment.findAll(q);
    results = results && results.length > 0 ? results[0] : undefined
    return results;
}
exports.getAllItems = async (req, res,) => {
    try {
        const { limit, offset } = req.query;
        const orderBy = [['updatedAt', 'DESC']]
        const data = await getAllRecords(req, {}, limit, offset, orderBy)
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};
exports.getAllItemsOfUser = async (req, res,) => {
    try {
        const { limit, offset } = req.query;
        const orderBy = [['updatedAt', 'DESC']]
        const user = await req.db.User.findByPk(req.params.id);
        if (!user) {
            return res.status(200).json({ status: false, data: [] });
        }
        let data = []
        if (user && user.userRoleId == '2') {
            data = await getAllRecords(req, { createdBy: req.params.id }, limit, offset, orderBy)
        } else {
            data = await getAllQoutesOfSeller(req, { createdBy: req.params.id }, limit, offset, orderBy)
        }

        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};
exports.getliveauctions = async (req, res,) => {
    try {
        const { limit, offset, lat, lng } = req.query;
        const orderBy = [['updatedAt', 'DESC']]
        const where = { status: { [Op.in]: [2, 3] } }
        const data = await getAllRecordsOfAUser(req, where, limit, offset, orderBy)
        return res.status(200).json({ status: true, data });


    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};
exports.getliveauctionsofBuyer = async (req, res,) => {
    try {
        const { limit, offset, lat, lng } = req.query;
        const orderBy = [['updatedAt', 'DESC']]
        const where = { status: { [Op.in]: [2, 3] }, createdBy: req.jwtPayload.id }
        const data = await getAllRecordsOfAUser(req, where, limit, offset, orderBy)
        return res.status(200).json({ status: true, data });


    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};
exports.getliveauctionsSingle = async (req, res,) => {
    try {
        const { id } = req.params
        let data = await req.db.Trade.findByPk(id, {
            attributes: [
                'id', 'description', 'title', 'closeDate', 'broadcastDate', 'status', 'quantity', 'createdAt', 'updatedAt', 'is_rejected', 'is_canceled', 'canceled_at', 'rejected_at', 'statusStr',

                [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'total'],
                [sequelize.literal('(SELECT MAX(qoutes.price) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'maxPrice'],
                [sequelize.literal('(SELECT MIN(qoutes.price) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'minPrice'],
                [sequelize.literal('(SELECT SUM(qoutes.quantity) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status NOT IN (0,1,3,4,99) )'), 'acceptedQty'],
                [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status NOT IN (0,1,3,4,99) )'), 'Acceptedtotal'],


            ],

            include: [
                {
                    model: req.db.User,
                    as: 'buyer',
                    attributes: ['id', 'first_name', 'last_name'],
                    required: true,
                    include: {
                        model: req.db.Address,
                        as: 'bAddress',
                        include: ['Country', 'State', 'City']
                    }
                },
                {
                    model: req.db.Unit,
                    as: 'unit',
                    attributes: ['name'],
                    required: true,
                },
                {
                    model: req.db.Commodity,
                    as: 'commodity',
                    attributes: ['id', 'name', 'description']
                },
                {
                    required: false,
                    model: req.db.Qoutes,
                    as: 'tq',
                    where: { status: 1 },
                    attributes: [],

                },
                {
                    required: false,
                    model: req.db.Qoutes,
                    as: 'Qoutes',
                    where: { createdBy: req.jwtPayload.id },
                    // attributes: ['id','min_price','max_price'],

                }

            ],


        })
        if (data) {
            data = data.toJSON();
            data.remaining = data.quantity && data.acceptedQty ? data.quantity - parseFloat(data.acceptedQty) : data.quantity
        }
        return res.status(200).json({ status: true, data });


    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};
exports.getMyRequest = async (req, res,) => {
    try {
        const { limit, offset } = req.query;
        const orderBy = [['updatedAt', 'DESC']]
        const where = { createdBy: req.jwtPayload.id, status: { [Op.in]: [0, 1, 6, 14, 15] } }
        const data = await getAllRecordsOfAUser(req, where, limit, offset, orderBy)
        return res.status(200).json({ status: true, data });


    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};
exports.getLiveRequest = async (req, res,) => {
    try {
        const { limit, offset } = req.query;
        const orderBy = [['updatedAt', 'DESC']]
        const where = { createdBy: req.jwtPayload.id, status: { [Op.in]: [2, 3] } }
        const data = await getAllRecordsOfAUser(req, where, limit, offset, orderBy)
        return res.status(200).json({ status: true, data });


    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};
exports.getMyAllTradeRequest = async (req, res,) => {
    try {
        const { limit, offset } = req.query;
        const orderBy = [['updatedAt', 'DESC']]
        const where = { createdBy: req.jwtPayload.id, }
        const data = await getAllRecordsOfAUser(req, where, limit, offset, orderBy)
        return res.status(200).json({ status: true, data });


    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};
exports.getAcceptedRequest = async (req, res,) => {
    try {
        const { limit, offset } = req.query;
        const orderBy = [['updatedAt', 'DESC']]
        const where = { createdBy: req.jwtPayload.id, status: { [Op.between]: [4, 13] } }
        const data = await getAllRecordsOfAUser(req, where, limit, offset, orderBy)
        return res.status(200).json({ status: true, data });


    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};
exports.search = async (req, res,) => {
    try {
        const { status, limit, offset, commodityId, createdBy, updatedBy, fromDate, toDate,sort } = req.body;
        let query = {};
        if (commodityId && commodityId.length > 0) {
            query = { commodityId: { [Op.in]: commodityId } };
        }
        if (status && status.length > 0) {
            query = { ...query, status: { [Op.in]: status } };
        }
        if (createdBy && createdBy.length > 0) {
            query = { ...query, createdBy: { [Op.in]: createdBy } };
        }
        if (updatedBy && updatedBy.length > 0) {
            query = { ...query, updatedBy: { [Op.in]: updatedBy } };
        }
        if (fromDate && toDate) {
            query = { ...query, createdAt: { [Op.between]: [fromDate, toDate] } };
        }
        let sorting;
        if(!!sort){
            sorting = sort
        }else{
            sorting = 'DESC'
        }
        const orderBy = [['createdAt', sorting]]
        const data = await getAllRecords(req, query, limit, offset, orderBy)
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
};


exports.getItemById = async (req, res) => {
    try {
        const data = await req.db.Trade.findOne({
            where: {
                id: req.params.id
            },
            attributes: [

                [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'total'],
                [sequelize.literal('(SELECT MAX(qoutes.price) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'maxPrice'],
                [sequelize.literal('(SELECT MIN(qoutes.price) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status >0 )'), 'minPrice'],
                [sequelize.literal('(SELECT SUM(qoutes.quantity) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status NOT IN (0,1,3,4,99) )'), 'acceptedQty'],
                [sequelize.literal('(SELECT COUNT(qoutes.id) FROM qoutes WHERE qoutes.tradeId = Trade.id AND qoutes.status NOT IN (0,1,3,4,99) )'), 'Acceptedtotal'],
                'id', 'title', 'unitId', 'description', 'closeDate', 'broadcastDate', 'status', 'quantity', 'remaining', 'createdAt', 'updatedAt', 'is_rejected', 'is_canceled', 'canceled_at', 'rejected_at', 'statusStr',
            ],
            include: [
                {
                    model: req.db.User,
                    as: 'buyer',
                    attributes: ['id', 'first_name', 'last_name', 'email', 'mobile'],
                    include: [
                        {
                            model: req.db.Address,
                            as: 'bAddress',
                            include: ['Country', 'State', 'City']
                        }
                    ]
                },
                {
                    model: req.db.User,
                    as: 'UpdatedUser',
                    attributes: ['id', 'first_name', 'last_name']
                },
                {
                    model: req.db.Commodity,
                    as: 'commodity',
                    attributes: ['id', 'name', 'description']
                }, {
                    model: req.db.Unit,
                    as: 'unit',
                },
                // {
                //     required: false,
                //     model: req.db.Qoutes,
                //     as: 'Qoutes',
                //     where: { status: 1 },
                //     // attributes: ['id','min_price','max_price'],

                // },


            ]

        });
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}
exports.getMySingleRequest = async (req, res) => {
    try {
        const data = await req.db.Trade.findOne({
            where: {
                id: req.params.id,
                createdBy: req.jwtPayload.id
            },
            attributes: [
                'id', 'title', 'description', 'closeDate', 'broadcastDate', 'status', 'statusStr', 'quantity', 'createdAt', 'updatedAt', 'is_rejected', 'is_canceled', 'canceled_at', 'rejected_at', 'statusStr',
                [sequelize.fn('max', sequelize.col('price')), 'maxPrice'],
                [sequelize.fn('min', sequelize.col('price')), 'minPrice'],
                [sequelize.fn('count', sequelize.col('Qoutes.id')), 'total'],
            ],
            include: [
                {
                    model: req.db.Unit,
                    as: 'unit',
                    attributes: ['id', 'name',]
                },
                {

                    model: req.db.User,
                    as: 'buyer',
                    attributes: ['id', 'first_name', 'last_name', 'email', 'mobile'],
                    include: [
                        {
                            model: req.db.Address,
                            as: 'bAddress',
                            include: ['Country', 'State', 'City']
                        }
                    ]
                },

                {
                    model: req.db.Commodity,
                    as: 'commodity',
                    attributes: ['id', 'name', 'description']
                },
                {
                    required: false,
                    model: req.db.Qoutes,
                    as: 'Qoutes',
                    where: { status: { [Op.gte]: 1 } },
                    include: [
                        {
                            model: req.db.User,
                            as: 'CreatedUser',
                            attributes: ['id', 'first_name', 'last_name'],
                            include: [
                                {
                                    model: req.db.Address,
                                    as: 'bAddress',
                                    include: ['Country', 'State', 'City']
                                },

                            ]
                        },

                    ]
                    // attributes: ['id','min_price','max_price'],

                },


            ]

        });
        const qoutes = await req.db.Qoutes.findAll({
            where: { status: { [Op.gte]: 1 }, tradeId: req.params.id },
            include: [
                {
                    model: req.db.User,
                    as: 'CreatedUser',
                    attributes: ['id', 'first_name', 'last_name'],
                    include: [
                        {
                            model: req.db.Address,
                            as: 'bAddress',
                            include: ['Country', 'State', 'City']
                        },

                    ]
                },

            ]
        })
        return res.status(200).json({ status: true, data, qoutes });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}
exports.getQuote = async (req, res) => {
    try {
        const data = await req.db.Qoutes.findOne({
            where: {
                id: req.params.id
            },

            include: [
                {
                    model: req.db.User,
                    as: 'CreatedUser',
                    attributes: ['id', 'first_name', 'last_name', 'email', 'mobile'],
                    include: [
                        {
                            model: req.db.Address,
                            as: 'bAddress',
                            include: ['Country', 'State', 'City']
                        }
                    ]
                },


                {
                    model: req.db.Trade,
                    as: 'trade',
                    include: [
                        {
                            model: req.db.Commodity,
                            as: 'commodity',
                            attributes: ['id', 'name', 'description']
                        }, {
                            model: req.db.Unit,
                            as: 'unit',
                            attributes: ['id', 'name',]
                        },
                        {
                            model: req.db.User,
                            as: 'CreatedUser',
                            attributes: ['id', 'first_name', 'last_name', 'email', 'mobile'],
                            include: [
                                {
                                    model: req.db.Address,
                                    as: 'bAddress',
                                    include: ['Country', 'State', 'City']
                                }
                            ]
                        },
                    ]
                    // as: 'commodity',

                },

            ]

        });
        console.log({ data });
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}

exports.closeRequest = async (req, res) => {
    console.log('closing trade');
    try {
        const data = await req.db.Trade.update({ status: 14, is_canceled: true, canceled_at: new Date() }, {
            where: {
                id: req.params.id,
                createdBy: req.jwtPayload.id
            }

        });
        let qts = await req.db.Qoutes.findAll({
            where: { tradeId: req.params.id },
            attributes: ['id', 'createdBy']
        });
        let toIds = qts.map(qt => qt.createdBy);
        qts = qts.map(qt => qt.id);
        if (qts && qts.length > 0) {
            await req.db.Qoutes.update({ status: 99 }, {
                where: { id: { [Op.in]: [qts] } }
            })
            await req.db.PurchaseOrder.update({ status: 99 }, {
                where: { qid: { [Op.in]: [qts] } }
            })
            await req.db.Transit.update({ status: 99 }, {
                where: { qid: { [Op.in]: [qts] } }
            })
            await req.db.Payment.update({ status: 99 }, {
                where: { qid: { [Op.in]: [qts] } }
            })
        }

        console.log({ toIds });
        toIds.push(req.jwtPayload.id)
        const item = await req.db.Trade.findByPk(req.params.id)
        this.notify(req, 'request', 'canceled', item, toIds)

        // return res.json(qts)
        // console.log({ data });
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}
exports.acceptQuote = async (req, res) => {
    try {
        const { id, qid } = req.params
        const trade = await req.db.Trade.findOne({
            where: {
                id,
                status: { [Op.in]: [2, 3] },
            },
            attributes: [
                'id', 'quantity', 'status','createdBy',
                [sequelize.fn('sum', sequelize.col('Qoutes.quantity')), 'sum'],

            ],
            include: [
                {
                    required: false,
                    model: req.db.Qoutes,
                    as: 'Qoutes',
                    where: { status: { [Op.in]: [2, 5, 6, 8, 9, 10, 11] } },

                }
            ]

        });
        // console.log(trade.id, trade.dataValues.sum);
        if (!trade || !trade.id) {
            return res.json({ status: false, msg: 'Trade not found' })
        }
        const thisQt = await req.db.Qoutes.findOne({
            where: { id: qid, status: 1 }
        })
        if (!thisQt) {
            return res.json({ status: false, msg: 'Quote not found' })
        }
        const sum = trade.dataValues.sum ? trade.dataValues.sum : 0;
        const left = parseFloat(trade.quantity) - parseFloat(sum);
        if (left < thisQt.quantity) {
            return res.json({ status: false, msg: 'Quote quantity more than total required quantity' })
        }
        // return res.json(trade)
        const data = await req.db.Qoutes.update({ status: 2, acceptedAt: new Date() }, {
            where: {
                id: qid,
                tradeId: id,
            }
        }
        );
        if (left == thisQt.quantity) {
            await req.db.Trade.update({ status: 98 }, {
                where: {
                    id,
                }
            })
            let qts = await req.db.Qoutes.findAll({
                where: {
                    status: 1,
                    tradeId: id
                }
            })
            const qtIds = qts && qts.length > 0 ? qts.map(item => item.id) : []
            let toSend = qts && qts.length > 0 ? qts.map(item => item.createdBy) : []
            if (qtIds && qtIds.length > 0) {
                await req.db.Qoutes.update({ status: 98 }, {
                    where: { id: { [Op.in]: qtIds } }
                })
                for (const item of qts) {
                    this.notify(req, 'qoute', 'closed', trade, [item.createdBy], item.id)
                }


            }
            toSend.push(trade.createdBy)
            if (toSend && toSend.length > 0) {
                this.notify(req, 'request', 'closed', trade, toSend, trade.id);
            }

        }
        this.notify(req, 'qoute', 'accepted', trade, [thisQt.createdBy], qid)
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}


exports.getHistory = async (req, res) => {
    try {
        const { entity, entityId } = req.params
        const data = await req.db.History.findAll({
            where: {
                entityId, entity, status: 1
            },
            order: [['updatedAt', 'DESC']],
            include: [
                {
                    model: req.db.User,
                    as: 'CreatedUser',
                    attributes: ['id', 'first_name', 'last_name'],
                    required: false,
                },
                {
                    model: req.db.User,
                    as: 'UpdatedUser',
                    attributes: ['id', 'first_name', 'last_name'],
                    required: false,
                }

            ]

        });
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}

exports.getItemQoutes = async (req, res) => {
    try {
        const data = await req.db.Qoutes.findAll({
            where: {
                tradeId: req.params.id,
                // status: 1
            },
            order: [
                ['createdAt', 'ASC'],
            ],
            include: [
                {
                    model: req.db.User,
                    as: 'CreatedUser',
                    attributes: ['id', 'first_name', 'last_name'],
                    include: [
                        {
                            model: req.db.Address,
                            as: 'bAddress',
                            include: ['Country', 'State', 'City']
                        },

                    ]
                },

            ]
        });
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}


exports.createNewItem = async (req, res,) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errors: errors.array() });
    }
    const creater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0
    const item = await req.db.Trade.create({
        ...req.body,
        status: 1,
        unitId: req.body.unit,
        createdBy: creater
    });
    if (item && item.id) {
        req.db.History.create({
            entity: 'trade',
            entityId: item.id,
            comment: 'New Trade request generated',
            newData: util.status.trade[1],
            createdBy: creater,

        })
        this.notify(req, 'request', 'created', item, [])
        return res.status(200).json({ status: true, data: item });
    } else {
        return res.status(200).json({ status: false });
    }
};
exports.approveReject = async (req, res) => {
    const updatedBy = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0;
    const { status } = req.body
    let query = {
        status,
        updatedBy,
        updatedAt: new Date()
    };
    if (status == 0) {
        query = { ...query, is_rejected: true, rejected_at: new Date() }
    }

    await req.db.Trade.update(query, {
        where: {
            id: req.params.id,
        }
    });

    await req.db.History.create({
        entity: 'trade',
        entityId: req.params.id,
        comment: req.body.comment,
        newData: util.status.trade[status],
        createdBy: updatedBy
    })
    const item = await req.db.Trade.findByPk(req.params.id)
    this.notify(req, 'request', status == 0 ? 'rejected' : 'approved', item, [item.createdBy])

    return this.getItemById(req, res)
}
exports.updateItem = async (req, res,) => {
    try {
        let query = {};
        const id = req.params.id;
        const { description, commodityId, quantity, closeDate, broadcastDate, status } = req.body;
        if (description) {
            query = { ...query, description };
        } if (commodityId) {
            query = { ...query, commodityId };
        } if (quantity) {
            query = { ...query, quantity };
        } if (closeDate) {
            query = { ...query, closeDate };
        } if (broadcastDate) {
            query = { ...query, broadcastDate };
        }
        if (status !== undefined) {
            query = { ...query, status };
        }
        const updater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0
        if (Object.keys(query).length > 0) {
            query = { ...query, updatedBy: updater }
            await req.db.Trade.update(query, { where: { id } })
        }
        return this.getItemById(req, res);
    } catch (error) {
        console.log({ error });
        return res.json({ status: false, error })
    }

};

exports.deleteItem = async (req, res,) => {

    return await req.db.Trade.update(
        { status: false },
        {
            where: { id: req.params.id },
        }
    ).then(async () => {
        return this.getItemById(req, res);
    })
        .catch(err => {
            res.status(200).send(err);
        })
};

exports.notify = async (req, entity, entityStage, item, to, entityId = null) => {
    console.log({ to });
    let toIds = [];
    let toEmails = []
    let toNumber = []
    let users;
    if (to && to.length > 0) {
        users = await req.db.User.findAll({ where: { id: { [Op.in]: to } }, include: ['fb'] })
        toEmails = users && users.length > 0 ? users.map(admin => admin.email) : []
        toIds = users && users.length > 0 ? users.map(admin => admin.id) : []
        toNumber = users && users.length > 0 ? users.map(admin => admin.mobile) : []

    } else {
        let adminIds = await req.db.User.findAll({ where: { status: 1, userRoleId: 1 } })
        toEmails = adminIds && adminIds.length > 0 ? adminIds.map(admin => admin.email) : []
        toIds = adminIds && adminIds.length > 0 ? adminIds.map(admin => admin.id) : []
        toNumber = adminIds && adminIds.length > 0 ? adminIds.map(admin => admin.mobile) : []
    }
    const notificationdata = {
        first_name: req && req.jwtPayload && req.jwtPayload.first_name ? req.jwtPayload.first_name : '',
        title: item && item.title ? item.title : '',
        toemail: toEmails.toString()
    }
    console.log({ notificationdata });
    // console.log({users});

    const from = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : '';
    entityId = entityId ? entityId : item ? item.id : '';
    notificationService.addNotification(req, toIds, from, entity, entityStage, entityId, notificationdata)
    sendMail(req, entity+'_'+entityStage, notificationdata);
    toNumber = toNumber.toString()
    // sendSMS(req, toNumber, entity,entityStage, notificationdata);
    if (users && users.length > 0) {
        fbNotification(req, users, entity, entityStage, notificationdata);
    }


}


