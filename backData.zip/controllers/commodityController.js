const { check, custom, validationResult } = require('express-validator/check');
const fileController = require('./filesController')
exports.validate = (functionName) => {

    switch (functionName) {


        case 'new':
            return [
                check('name', 'name is required and must be at least 3 characters long').isLength({ min: 3 }),
                check('max_price', 'Max price  is required').not().isEmpty().isLength({ min: 0, max: 10000000 }),
                check('min_price', 'Min price  is required').not().isEmpty().isLength({ min: 0, max: 10000000 }),
                check('nodal_price', 'Nodal price  is required').not().isEmpty().isLength({ min: 0, max: 10000000 }),
                // check('status', 'Status  is required').not().isEmpty(),
                // check('type', 'User Type  is required').not().isEmpty(),
                // check('attribute', 'Attribute is required').not().isEmpty(),
                // check('certification', 'Certification is required').not().isEmpty(),
                
            ];
            
        default:
            throw new Error('invalid user controller function name');
    }
};

exports.getAllCommodity = async (req, res, next) => {
    try {
       
        const data = await req.db.Commodity.findAll({
           include: [
                {
                    model : req.db.EntityFile,
                    required:false,
                    where:{
                        status:1,
                        fileable:'commodity'
                    },
                    include:{
                        model: req.db.File
                    }
                }
            ]
        });
        return res.status(200).json({status:true, data});
    } catch (error) {
        return res.status(500).send({status:false, error});
    }
};
exports.getUserCommodity = async (req, res, next) => {
    try {
        const userId = req.jwtPayload.id;
        let data = await req.db.EntityCommodity.findAll({
            where:{
                commodityTypeable:'user',
                commodityTypeableId: userId,
               
            },
            include: [
                {
                    model : req.db.Commodity,
                    required:true,
                    where:{
                        status:1,
                    },
                    include:
                        {
                            model : req.db.EntityFile,
                            required:false,
                            where:{
                                status:1,
                                fileable:'commodity'
                            },
                            include:{
                                model: req.db.File
                            }
                        }
                    
                }
            ]
        });
        if(data && data.length > 0){
            data =data.map(datum=>{
                let item;
                if(datum.Commodity){
                    item={
                        id:datum.Commodity.id,
                        name:datum.Commodity.name,
                        description:datum.Commodity.description,
                        max_price:datum.Commodity.max_price,
                        min_price:datum.Commodity.min_price,
                        nodal_price:datum.Commodity.nodal_price,
                        buyer_min_qty:datum.Commodity.buyer_min_qty,
                        seller_min_qty:datum.Commodity.seller_min_qty,
                        other:datum.Commodity.other,
                        // attributes:datum.Commodity.attributes,
                        // certifications:datum.Commodity.certifications,
                    } ;
                    item.img =datum.Commodity && datum.Commodity.EntityFile && datum.Commodity.EntityFile.File && datum.Commodity.EntityFile.File.id ? datum.Commodity.EntityFile.File.id : null;
                  
                   return item;
                }
            })

        }
        data = data && data.length > 0 ? data.map(d=>d):[];
        return res.status(200).json({status:true, data});
    } catch (error) {
        return res.status(500).send({status:false, error});
    }
};
exports.All = async (req, res, next) => {
    try {
        let data = await req.db.Commodity.findAll({
                   
                    where:{
                        status:1,
                    },
                    include:
                        {
                            model : req.db.EntityFile,
                            required:false,
                            where:{
                                status:1,
                                fileable:'commodity'
                            },
                            include:{
                                model: req.db.File
                            }
                        }
        });
        if(data && data.length > 0){
            data =data.map(datum=>{
                let item;
                if(datum){
                    item={
                        id:datum.id,
                        name:datum.name,
                        description:datum.description,
                        max_price:datum.max_price,
                        min_price:datum.min_price,
                        nodal_price:datum.nodal_price,
                        buyer_min_qty:datum.buyer_min_qty,
                        seller_min_qty:datum.seller_min_qty,
                        other:datum.other,
                        // attributes:datum.Commodity.attributes,
                        // certifications:datum.Commodity.certifications,
                    } ;
                    item.img =datum && datum.EntityFile && datum.EntityFile.File && datum.EntityFile.File.id ? datum.EntityFile.File.id : null;
                  
                   return item;
                }
            })

        }
        data = data && data.length > 0 ? data.map(d=>d):[];
        return res.status(200).json({status:true, data});
    } catch (error) {
        return res.status(500).send({status:false, error});
    }
};
exports.getItemById = async (req, res) => {
    try {
        const data = await req.db.Commodity.findOne({
            where: {
                id: req.params.id
            },
            include:[
                {
                    model : req.db.EntityFile,
                    required:false,
                    where:{
                        status:1,
                        fileable:'commodity'
                    },
                    include:{
                        model: req.db.File
                    }
                }
            ]
           
        });
        return res.status(200).json({status:true, data});
    } catch (error) {
        return res.status(500).send({status:false, error});
    }
}


exports.createNewItem = async (req, res, next) => {
    try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errors: errors.array() });
    }
    const creater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id: 0
    const item = await  req.db.Commodity.create({
        ...req.body,
        createdBy:creater
    });
    if(item && item.id){
        if(req.body.file){
            const file =req.body.file
             await fileController.addFile(req,file, creater, 'commodity', item.id)
        }
        return res.status(200).json({ status: true, data: item });
    } else {
        return res.status(200).json({ status: false }); 
    }
}
catch (err){
    console.log({err});
    return res.status(200).json({ errors: err && err.errors && err.errors[0] && err.errors[0].message ? err.errors[0].message : 'Oops something went wrong' ,status:false});
            
}
};
const deleteItemImage = async(req,)=>{
    const updatedBy = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id: 0;
    await req.db.EntityFile.update(
        {
            status:false,
            updatedBy
        },{
        where:{
            fileable:'commodity',
            fileableId: req.params.id,
        }
    })
}
exports.updateItem = async (req, res, next) => {
    let query = {};
    const id = req.params.id;
    const {name, description, min_price, max_price, nodal_price,status, attributes, certifications,buyer_min_qty,seller_min_qty} = req.body;
    if (name !== undefined) {
        query = { name }
    } if (description) {
        query = { ...query, description };
    } if (min_price) {
        query = { ...query, min_price};
     } if (max_price) {
        query = { ...query, max_price};
     } if (nodal_price) {
        query = { ...query, nodal_price};
     } if (status !== undefined) {
        query = { ...query, status};
     } if (attributes !== undefined) {
        query = { ...query, attributes};
     } if (certifications !== undefined) {
        query = { ...query, certifications};
     } if (buyer_min_qty !== undefined) {
        query = { ...query, buyer_min_qty};
     } if (seller_min_qty !== undefined) {
        query = { ...query, seller_min_qty};
     }
    const updater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id: 0
    if(Object.keys(query).length > 0){
        query ={...query, updatedBy:updater}
        await req.db.Commodity.update(query, { where: { id }})
    }
    if(req.body.file){
        await deleteItemImage(req)
        const file =req.body.file
        await fileController.addFile(req,file, updater, 'commodity', id)
    }
   
    return this.getItemById(req, res);
        
};

exports.deleteItem = async (req, res, next) => {

    return await req.db.Commodity.update(
        { status: false },
        {
            where: { id: req.params.id },
        }
    ).then(async () => {
        return this.getItemById(req, res);
    })
        .catch(err => {
            res.status(200).send(err);
        })
};


