const { check, custom, validationResult } = require('express-validator/check');
const fileController = require('./filesController')
const {notify} = require('./tradeController')
const sequelize = require('sequelize')
var _ = require('underscore-node');
const { Op } = require('sequelize')
exports.validate = (functionName) => {

    switch (functionName) {


        case 'new':
            return [
                // check('description', 'Description required and must be at least 3 characters long').isLength({ min: 3 }),
                check('price', 'Price  is required').not().isEmpty().isLength({ min: 1, max: 10000000 }),
                check('quantity', 'Quantity  is required').not().isEmpty().isLength({ min: 1, max: 10000000 }),
                check('tradeId', 'Trade id  is required').not().isEmpty(),


            ];

        default:
            throw new Error('invalid user controller function name');
    }
};

exports.getAllItems = async (req, res, next) => {
    try {

        const data = await req.db.Qoutes.findAll({
            include: [
                {
                    model: req.db.User,
                    as: 'CreatedUser',
                    attributes: ['id', 'first_name', 'last_name']
                },
                {
                    model: req.db.User,
                    as: 'UpdatedUser',
                    attributes: ['id', 'first_name', 'last_name']
                },
                {
                    model: req.db.Trade,
                    as: 'trade',
                    attributes: ['id', 'description']
                }

            ]
        });
        return res.status(200).json({ status: true, data });
    } catch (error) {
        return res.status(500).send({ status: false, error });
    }
};
const getAllRecordsOfAUser = async (req, where, limit = 10, offset = 0, orderBy, single=false) => {
    limit = parseInt(limit);
    offset = parseInt(offset)
    const q = {
        where,
        subQuery: false,
        order: orderBy,
        include: [
            {
                required: true,
                model: req.db.Trade,
                as: 'trade',
                attributes: ['id', 'title', 'status','closeDate','broadcastDate',
                    // [sequelize.fn('min', sequelize.col('trade.tq.price')), 'minPrice'],
                    // [sequelize.fn('count', sequelize.col('trade.tq.id')), 'total'],
                ],

                include: [
                    {
                        model: req.db.Commodity,
                        as: 'commodity',
                        attributes: ['name', 'id'],
                        required: true,
                    },
                    {
                        model: req.db.Unit,
                        as: 'unit',
                        attributes: ['name', 'id'],
                        required: true,
                    },
                    {
                        required: true,
                        model: req.db.Qoutes,
                        as: 'tq',
                        attributes: ['price'],
                        where: { status: {[Op.gte]:0}},
                    }
                ]
            }
        ]
    };
    if(single){
        return  await req.db.Qoutes.findOne(q);
    }
    let count = await req.db.Qoutes.findAll(q);
    if (count && count.length > 0) {
        count = count.filter(datum => datum.id)
    }
    count = count && count.length ? count.length : 0;
    let data = await req.db.Qoutes.findAll({ ...q, limit, offset });
    if (data && data.length > 0) {
        data = data.filter(datum => datum.id)
        data =data.map(item=>{
            item =item.toJSON()
            let min =0;
            let total =0
            if(item && item.trade && item.trade.tq){
               const tq =_.sortBy( item.trade.tq, 'price' );
               if(tq && tq[0]){
                min=tq[0].price
               }
               total =tq.length ? tq.length :0
    
            }
            delete item.trade.tq
            return {...item, minPrice:min, total};
           
        })
    }
    return { count, data }
}
const getAllRecordsOfAUserQoutes = async (req, where, limit = 10, offset = 0, orderBy, single=false) => {
    limit = parseInt(limit);
    offset = parseInt(offset)
    const q = {
        where,
        subQuery: false,
        order: orderBy,
        include: [
            {
                model:req.db.User,
                as:'seller',
                attributes:['full_name','first_name','last_name']
            },

            {
                required: true,
                model: req.db.Trade,
                as: 'trade',
                where:{
                    createdBy:req.jwtPayload.id, 
                   status:{ [Op.gt]:1}
                
                },
                
                attributes: ['id','quantity','title', 'status','statusStr', 'closeDate','broadcastDate',
                    // [sequelize.fn('min', sequelize.col('trade.tq.price')), 'minPrice'],
                    // [sequelize.fn('count', sequelize.col('trade.tq.id')), 'total'],
                ],

                include: [
                    {
                        model: req.db.Commodity,
                        as: 'commodity',
                        attributes: ['name', 'id'],
                        required: true,
                    },
                    {
                        model: req.db.Unit,
                        as: 'unit',
                        attributes: ['name', 'id'],
                        required: true,
                    },
                    {
                        required: false,
                        model: req.db.Qoutes,
                        as: 'tq',
                        attributes: ['quantity'],
                        where: { status: {[Op.notIn]:[0,1,3,99]}},
                    }
                ]
            }
        ]
    };
    if(single){
        return  await req.db.Qoutes.findOne(q);
    }
    let count = await req.db.Qoutes.findAll(q);
    if (count && count.length > 0) {
        count = count.filter(datum => datum.id)
    }
    count = count && count.length ? count.length : 0;
    let data = await req.db.Qoutes.findAll({ ...q, limit, offset });
    if (data && data.length > 0) {
        data = data.filter(datum => datum.id)
    }
    return { count, data }
}
exports.buyerAcceptedQoutes = async (req, res, next) => {
    try {

        const { limit, offset } = req.query;
        const orderBy = [['updatedAt', 'DESC']]
        const where = {
            //  status:{[Op.gt]:1},
            
        }
        const data = await getAllRecordsOfAUserQoutes(req, where, limit, offset, orderBy)
        return res.status(200).json({ status: true, data });
    } catch (error) {
        return res.status(500).send({ status: false, error });
    }
};
exports.getMyQoutes = async (req, res, next) => {
    try {

        const { limit, offset } = req.query;
        const orderBy = [['updatedAt', 'DESC']]
       
        const where = {
            //   status:{[Op.gt]:0},
            createdBy: req.jwtPayload.id,
        }
        console.log({where});
        const data = await getAllRecordsOfAUser(req, where, limit, offset, orderBy)
        return res.status(200).json({ status: true, data });
    } catch (error) {
        return res.status(500).send({ status: false, error });
    }
};
exports.getMyQuoteSingle = async (req, res, next) => {
    try {
        const orderBy = [['updatedAt', 'DESC']]
        const { limit, offset } = req.query;
        const { id } = req.params;
        const where = {
            id,
            createdBy: req.jwtPayload.id,
        }
        const data = await getAllRecordsOfAUser(req, where, limit, offset, orderBy,true)
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({error});
        return res.status(500).send({ status: false, error });
    }
};

exports.getItemById = async (req, res) => {
    try {
        const data = await req.db.Qoutes.findOne({
            where: {
                id: req.params.id
            },
            include: [
                {
                    model: req.db.User,
                    as: 'CreatedUser',
                    attributes: ['id', 'first_name', 'last_name']
                },
                {
                    model: req.db.User,
                    as: 'UpdatedUser',
                    attributes: ['id', 'first_name', 'last_name']
                },


            ]

        });
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}


exports.createNewItem = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errors: errors.array() });
    }
    const creater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0
    const { tradeId, quantity, price, description } = req.body;
    const trade = await req.db.Trade.findByPk(tradeId,{include:['commodity']});
    if (!trade) {
        return res.json({ status: false, msg: 'Invalid Trade ' })
    }
    if (trade && !trade.commodity) {
        return res.json({ status: false, msg: 'Invalid Trade ' })
    }
    if (trade.quantity < quantity) {
        return res.json({ status: false, msg: 'Quantity cannot more than Trade quantity' ,trade})
    }
    if (trade.commodity.seller_min_qty && trade.commodity.seller_min_qty  > quantity) {
        return res.json({ status: false, msg: `Quantity cannot less than Commodity  min (${trade.commodity.seller_min_qty}) quantity` })
    }
    // return res.json('ok')
    const hasQt = await req.db.Qoutes.findOne({
        where: {
            createdBy: creater, tradeId,
        }
    })
    if (hasQt) {

        if (hasQt.status == 1) {
            return res.json({ status: false, msg: 'You have already gave Qoute' })
        } else if (hasQt.status == 0) {
            return res.json({ status: false, msg: 'Cannot give Qoute (last Qoute rejected)' })
        }
        return res.json({ status: false, msg: 'Unable to process your request' })
    } else {
        await req.db.Qoutes.create(
            {
                price, quantity, updatedAt: null,
                createdBy: creater, tradeId, status: 1,
                description
            })
    }
    const item = await req.db.Qoutes.findOne({
        where: {
            createdBy: creater, tradeId, status: 1
        }
    })
    if (item && item.id) {
        req.params.id = item.id;
        notify(req, 'qoute','created',trade,[trade.createdBy],item.id)
        return this.getItemById(req, res);
    } else {
        return res.status(200).json({ status: false });
    }
};
const deleteItemImage = async (req,) => {
    const updatedBy = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0;
    await req.db.EntityFile.update(
        {
            status: false,
            updatedBy
        }, {
        where: {
            fileable: 'commodity',
            fileableId: req.params.id,
        }
    })
}
exports.updateItem = async (req, res, next) => {
    // try {
    let query = {};
    const id = req.params.id;
    const updater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0
    const item = await req.db.Qoutes.findOne({
        where: { createdBy: updater, id }
    })
    if (!item) {
        return res.json({ status: false, msg: 'Qoute not found' })
    }

    if (item && (item.status == 0 || item.status == 99) ) {
        return res.json({ status: false, msg: 'You cannot update rejected Qoute' })
    }
    const { description, quantity, price, status } = req.body;
    if (description) {
        query = { ...query, description };
    } if (price) {
        query = { ...query, price };
    } if (quantity) {
        query = { ...query, quantity };
    }
    const closing =false
    if (status !== undefined) {
        query = { ...query, status };
    }


    if (Object.keys(query).length > 0) {

        query = { ...query, updatedBy: updater, updatedAt: new Date() }

        await req.db.Qoutes.update(query, { where: { id, createdBy: updater } })
    }
    const trade = await req.db.Trade.findByPk(item.tradeId)
    notify(req, 'qoute','updated',trade, [trade.createdBy],id)
    return this.getItemById(req, res);
    // } catch (error) {
    //     console.log({error});
    //     return res.json({ status: false, error })
    // }

};


exports.deleteItem = async (req, res, next) => {

    return await req.db.Qoutes.update(
        { status: false },
        {
            where: { id: req.params.id },
        }
    ).then(async () => {
        return this.getItemById(req, res);
    })
        .catch(err => {
            res.status(200).send(err);
        })
};


