const { check, custom, validationResult } = require('express-validator/check');
const fileController = require('./filesController')
exports.validate = (functionName) => {

    switch (functionName) {


        case 'new':
            return [
                check('name', 'name is required and must be at least 3 characters long').isLength({ min: 3 }),
                check('subject', 'Subject is required and must be at least 3 characters long').isLength({ min: 3 }),
                check('body', 'Body is required ').not().isEmpty(),
               check('status', 'Status  is required').not().isEmpty(),
                
                
            ];
            
        default:
            throw new Error('invalid user controller function name');
    }
};

exports.getAllItems = async (req, res, next) => {
    try {
       
        const data = await req.db.EmailNotification.findAll();
        return res.status(200).json({status:true, data});
    } catch (error) {
        return res.status(500).send({status:false, error});
    }
};

exports.getItemById = async (req, res) => {
    try {
        const data = await req.db.EmailNotification.findOne({
            where: {
                id: req.params.id
            },
           
        });
        return res.status(200).json({status:true, data});
    } catch (error) {
        return res.status(500).send({status:false, error});
    }
}


exports.createNewItem = async (req, res, next) => {
    try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errors: errors.array() });
    }
    const creater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id: 0
    const item = await  req.db.EmailNotification.create({
        ...req.body,
        createdBy:creater
    });
    console.log('EmailNotification',item)

    if(item && item.id){
        req.params.id =item.id;
        return this.getItemById(req, res);
    } else {
        return res.status(200).json({ status: false }); 
    }
}
catch (err){
    console.log({err});
    return res.status(200).json({ errors: err && err.errors && err.errors[0] && err.errors[0].message ? err.errors[0].message : 'Oops something went wrong' ,status:false});
            
}
};
exports.updateItem = async (req, res, next) => {
    let query = {};
    const id = req.params.id;
    
    const {name, subject, body,email, status} = req.body;
    if (name !== undefined) {
        query = { name }
    } if (subject) {
        query = { ...query, subject };
    } if (body) {
        query = { ...query, body};
     } if (email) {
        query = { ...query, email};
     }  if (status !== undefined) {
        query = { ...query, status};
     }
    const updater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id: 0
    if(Object.keys(query).length > 0){
        query ={...query, updatedBy:updater}
        await req.db.EmailNotification.update(query, { where: { id }})
    }
    
   
    return this.getItemById(req, res);
        
};

exports.deleteItem = async (req, res, next) => {

    return await req.db.EmailNotification.update(
        { status: false },
        {
            where: { id: req.params.id },
        }
    ).then(async () => {
        return this.getItemById(req, res);
    })
        .catch(err => {
            res.status(200).send(err);
        })
};


