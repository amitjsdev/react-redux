const { User } = require('../models');
const passport = require('passport');
const userController = require('./userController')
const notificationController = require('./notificationController')
const notificationService = require('../services/notificationService')
const { sendMail } = require('./mailController');
const jwt = require('jsonwebtoken');
const sequelizeErrors = require('../lib/sequelizeErrors');
const config = require('../config/config');
const { check } = require('express-validator/check');
var bcrypt = require('bcrypt');
const moment =require('moment')

exports.validate = (method) => {
    switch (method) {
        case 'login':
            return [
                check('email', 'email is required').not().isEmpty(),
                check('password', 'password is required').not().isEmpty()
            ];
        case 'registerVerify':
            return [
                check('mobileOtp', 'Mobile OTP is required').not().isEmpty(),
                check('mailOtp', 'Email OTP is required').not().isEmpty()
            ];
        case 'loginMobile':
            return [
                check('mobile', 'Phone number is required').not().isEmpty(),
            ];
        case 'loginMobileOTP':
            return [
                check('mobile', 'Phone number is required').not().isEmpty(),
                check('otp', 'OTP  is required').not().isEmpty(),
            ];

        case 'passwordGenerate':
            return [
                check('password', 'Password is required and must have minimum 6 characters ').not().isEmpty().isLength({ min: 6 }),
                check('token', 'Token is invalid').not().isEmpty()
            ];
        case 'forgotPassword':
            return [
                check('email', 'Email is required').not().isEmpty(),
            ];
        default:
            return [];
    }
};

/* users will be added by the Admin(s) for each sri client*/

exports.login = async (req, res, next) => {

    if (req._validationErrors && req._validationErrors.length > 0) {
        return res.status(400).send(req._validationErrors);
    }
    passport.authenticate('local', (err, user, message) => {
        if (err || !user) {
            return res.status(400).json({
                message,
                user: user
            });
        }
        req.login(user, async (err) => {
            if (err) {
                res.send(err);
            }
            req.session.cookie.maxAge = config.sessionLengthInMinutes * 60 * 1000;
            delete user.password;
            const token = jwt.sign(user, config.jwtSecret);

            return res.json({ ...user, token });
        });
    })(req, res);
};
exports.loginMobile = async (req, res, next) => {

    if (req._validationErrors && req._validationErrors.length > 0) {
        return res.status(400).send(req._validationErrors);
    }
    const { mobile } = req.body;
    let hasUser = await req.db.User.findOne({
        where: {
            mobile
        }
    })
    if (!hasUser) {
        return res.json({ status: false, data: 'Invalid credentials' })
    }
    if (hasUser && hasUser.status == -1) {
        return res.json({ status: false, data: 'Email and Mobile not verified', statusCode: -1, id: hasUser.id })
    }
    else if (hasUser && hasUser.status == 0) {
        return res.json({ status: false, data: 'Your Account has been terminated', statusCode: 0 })
    }
    else if (hasUser && hasUser.status == 2) {
        return res.json({ status: false, data: 'Your Account has been rejected', statusCode: 2 })
    }
    else if (hasUser && hasUser.status == 3) {
        return res.json({ status: false, data: 'Your Account has been not approved by Administrator', statusCode: 3 })
    } else if (hasUser && hasUser.status == 1) {
        const otp = Math.floor(1000 + Math.random() * 9000);
        await req.db.User.update({ otp, otp_sent_at: new Date() }, { where: { id: hasUser.id } })
        const isSent = await notificationController.sendSMS(req, hasUser.mobile, 'user','otp', {otp});
        // const otp_expire_in = await notificationController.getConfig(req, 'otp_expire_in')
        // const mailData = {
        //     first_name: hasUser.first_name,
        //     otp,
        //     otp_expire_in,
        //     email: hasUser.email,
        // }
        // sendMail(req, 'login_otp', mailData);

        if (isSent && isSent.status) {
            return res.json({ status: true, data: 'Please Check Email/SMS', statusCode: 1, isSent })
        } else {
            return res.json({ status: false, data: 'Please Check Email/SMS', statusCode: 1, isSent })
        }


    } else {
        return res.json({ status: false, data: 'Unable to login ,Please contact Administrator', statusCode: 4 })
    }




};

exports.ResendOTP = async (req, res, next) => {

    if (req._validationErrors && req._validationErrors.length > 0) {
        return res.status(400).send(req._validationErrors);
    }
    const { mobile, email, isRegister } = req.body;
    let hasUser = await req.db.User.findOne({
        where: {
            mobile
        }
    })
    if (!hasUser) {
        return res.json({ status: false, data: 'Invalid credentials' })
    }

    else if (hasUser && hasUser.status == 0) {
        return res.json({ status: false, data: 'Your Account has been terminated', statusCode: 0 })
    }
    else if (hasUser && hasUser.status == 2) {
        return res.json({ status: false, data: 'Your Account has been rejected', statusCode: 2 })
    }
    else if (hasUser && hasUser.status == 3) {
        return res.json({ status: false, data: 'Your Account has been not approved by Administrator', statusCode: 3 })
    }
    else if (hasUser) {


        const otp_expire_in = await notificationController.getConfig(req, 'otp_expire_in')
        const now = moment();
        const compareWith = moment(hasUser.otp_sent_at).add(otp_expire_in, 'minutes');
        console.log({ now, compareWith });
        let otp = hasUser.otp;
        let mailotp = hasUser.mailOtp;
        if (otp_expire_in) {
            if (now.isAfter(compareWith)) {
                otp = Math.floor(1000 + Math.random() * 9000);
                mailotp = Math.floor(1000 + Math.random() * 9000);
            }
        }
        await req.db.User.update({
            otp,
            otp_sent_at: new Date(),
            mailOtp: mailotp
        }, { where: { id: hasUser.id } })
        if (isRegister) {
            await notificationController.sendSMS(req, hasUser.mobile, 'user','verify_otp', {otp});

            const mailData = {
                first_name: hasUser.first_name,
                otp: mailotp,
                otp_expire_in,
                email: hasUser.email,
            }
            sendMail(req, 'account_verify_for_user', mailData);
        } else {
            await notificationController.sendSMS(req, hasUser.mobile, 'user','otp', {otp});

        }
        return res.json({ status: true, data: 'Please Check Email/SMS', statusCode: 1, })





    };
}
exports.otpVerify = async (req, res, next) => {

    if (req._validationErrors && req._validationErrors.length > 0) {
        return res.status(400).send(req._validationErrors);
    }
    let { mobile, otp } = req.body;
    // console.log({mobile, otp});
    mobile = mobile.toString().trim().replace(/ /g, '')
    otp = otp.toString().trim().replace(/ /g, '')
    // console.log({mobile, otp});
    let hasUser = await req.db.User.findOne({
        where: {
            mobile,
            otp
        }
    })
    // console.log({hasUser});
    if (!hasUser) {
        return res.json({ status: false, data: 'Invalid OTP' })
    }
    if (hasUser && !hasUser.otp_sent_at) {
        return res.json({ status: false, data: 'OTP Expired' })
    }

    hasUser = await req.db.User.findOne({
        where: {
            mobile,
            otp
        },
        raw: true,

    })
    const otp_expire_in = await notificationController.getConfig(req, 'otp_expire_in')
    console.log({ otp_expire_in });
    const now = moment();
    const compareWith = moment(hasUser.otp_sent_at).add(otp_expire_in, 'minutes');
    console.log({ now, compareWith });
    if (otp_expire_in) {

        if (now.isAfter(compareWith)) {
            return res.json({ status: false, data: 'OTP Expired' })
        }
    }
    delete hasUser.password;
    const token = jwt.sign(hasUser, config.jwtSecret);
    const otp2 = Math.floor(1000 + Math.random() * 9000);
    req.db.User.update({ otp: otp2 }, { where: { id: hasUser.id } })
    req.jwtPayload = {
        id: hasUser.id
    };
    const data = await userController.MeData(req)

    return res.json({ status: true, data, token });


};
exports.registerVerify = async (req, res, next) => {

    if (req._validationErrors && req._validationErrors.length > 0) {
        return res.status(400).send(req._validationErrors);
    }
    const { mobileOtp, mailOtp, id } = req.body;
    let hasUser = await req.db.User.findOne({
        where: {
            id,
            otp: mobileOtp,
            mailOtp
        },
        include:['UserRole']
    })
    if (!hasUser) {
        return res.json({ status: false, data: 'Invalid OTP' })
    }

   
    const otp2 = Math.floor(1000 + Math.random() * 9000);
    await req.db.User.update({ otp: otp2, status: 3 }, { where: { id: hasUser.id } })
  
    let adminIds = await req.db.User.findAll({where:{status:1, userRoleId:1}})
    let adminEmails =adminIds && adminIds.length >0 ? adminIds.map(admin=>admin.email):[]
    adminIds =adminIds && adminIds.length >0 ? adminIds.map(admin=>admin.id):[]
    const notificationdata ={
        first_name:hasUser.first_name,
        userType: hasUser && hasUser.UserRole && hasUser.UserRole.role ? hasUser.UserRole.role:'' ,
        email:hasUser.email,
        toemail:adminEmails.toString()
    }
    const to =adminIds;
    const from =hasUser.id;
    const entityId=1;
    const entityStage='signup';
    const entity ='user'
    const ck =await notificationService.addNotification(req,to, from, entity, entityStage, entityId,notificationdata)
    sendMail(req, 'account_verify_for_admin',notificationdata);
    return res.json({ status: true, data: 'Account verified successfully' });


};