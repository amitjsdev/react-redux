const { check, custom, validationResult } = require('express-validator/check');
const {notify} = require('./tradeController')
const { Op } = require('sequelize')
exports.validate = (functionName) => {

    switch (functionName) {


        case 'new':
            return [

                check('qid', 'Qoute id  is required').not().isEmpty(),
            ];

        default:
            throw new Error('invalid user controller function name');
    }
};
const include =(req)=>{
    return [
        {
            model: req.db.TransitHistory,
            // as: 'history',
        },
        {
            model: req.db.User,
            as: 'seller',
            attributes: ['id', 'first_name', 'last_name', 'full_name'],
            include:[
                {
                    model:req.db.Address,
                    as:'bAddress',
                    include:['Country','State','City']

                }
                
            ]
        },
        {
            model: req.db.User,
            as: 'buyer',
            attributes: ['id', 'first_name', 'last_name', 'full_name'],
            include:[
                {
                    model:req.db.Address,
                    as:'bAddress',
                    include:['Country','State','City']

                }
                
            ]
        },
        {
            model: req.db.Qoutes,
            as: 'qt',
            attributes: ['quantity','price'],
            include: [
                {
                    model: req.db.Trade,
                    as: 'trade',
                    attributes: ['title', 'createdBy'],
                    include: {
                        model: req.db.Commodity,
                        as: 'commodity',
                        attributes: ['name']
                    }
                },
                {
                    model: req.db.PurchaseOrder,
                    as: 'po',
                    attributes:['seller_id','buyer_id','id'],
                    
                }, {
                    model: req.db.Payment,
                    as: 'Payment',
                    attributes:['id','status','statusStr'],
                    
                }
            ]
        },

    ]
}

const getRecord = async (req, where) => {
    return await req.db.Transit.findOne({
        where,
        include: include(req)
    });

}
exports.getQouteTransit = async (req, res, next) => {
    try {
    const { id } = req.params;
    const hasPO = await req.db.PurchaseOrder.findOne({where:{qid:id}})
    if (!hasPO) {
        return res.json({ status: false, msg: 'Purchase Order not found' })
    }
    const where = { qid: id }
    const data = await getRecord(req, where)

    return res.status(200).json({ status: true, data });
    } catch (error) {
        return res.status(500).send({ status: false, error });
    }
};
exports.getTradeTransit = async (req, res, next) => {
    try {
        let qid = await req.db.Qoutes.findAll({
            where:{tradeId:req.params.id},
            attributes:['id']
        })
        qid = qid && qid.length > 0 ? qid.map(q=>q.id): null;
        if(!qid){
            return res.status(200).json({ status: true, data:[] });
           
        }
        const where ={qid:{[Op.in]:qid}}
        let data = await req.db.Transit.findAll({
            where,
            include: include(req)
        });
        return res.status(200).json({ status: true, data });
    } catch (error) {
        return res.status(500).send({ status: false, error });
    }
};

exports.getItemById = async (req, res) => {
    try {
        const {id}=req.params
        const where = { id }
        const data = await getRecord(req, where)
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}


exports.createNewItem = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errors: errors.array() });
    }
    const { qid } = req.body;
    const hasPO = await req.db.PurchaseOrder.findOne({
        where:{qid}
    })
    if (!hasPO) {
        return res.json({ status: false, msg: 'Purchase Order not found' })
    }
   
    const creater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0;

    const item = await req.db.Transit.create({
        qid,
        initiated: new Date(),
        createdBy: creater,
        updatedBy: creater,
        seller_id:hasPO.seller_id,
        buyer_id:hasPO.buyer_id,

    });
    await req.db.Qoutes.update({status:8},{where:{id:qid}})

    if (item && item.id) {
        const where = { qid }
        const data = await getRecord(req, where)
        notify(req, 'transit','initiated',{}, [hasPO.createdBy],item.id)
        return res.status(200).json({ status: true, data });
    } else {
        return res.status(200).json({ status: false });
    }
};

exports.updateItem = async (req, res, next) => {
    try {
        let query = {};
        const id = req.params.id;
        const {transit_status} =req.body;
        let  status =transit_status ? parseInt(transit_status):0
        const arr = [
            'initiated', 'expected',
            'vehical',
            'tracking_number',  'transit_status',
        ]
        arr.map(key => {
            if (key && req.body[key]) {
                query = { ...query, [key]: req.body[key] };
            }
        })
        if(req.body.transit_status != undefined){
            query = { ...query,transit_status: req.body.transit_status };
        }
        let qtUpdate =false
        let qtStatus =status ? status+30 :8;
        if(req.body.transit_status =='4'){
            qtUpdate =true
           
            query = { ...query,transit_status: req.body.transit_status, delivery_date: new Date() };
            
        }
        const updater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0

        if (Object.keys(query).length > 0) {
            query = { ...query, updatedBy: updater }
            await req.db.Transit.update(query, { where: { id } })
            
        }
        const record =await req.db.Transit.findByPk(id);
        if(record){
            await req.db.TransitHistory.create({
                transitId:id,
                tracking_number:record.tracking_number,
                vehical:record.vehical,
                expected:record.expected,
                status:record.transit_status,
                comment:req.body.comment,
                createdBy:updater
            })
            await req.db.Qoutes.update({status:qtStatus},{where:{id:record.qid}})
            if(req.body.transit_status != undefined){
            notify(req, 'transit','delivered',{}, [record.seller_id,record.buyer_id],id)
            }
        }   
        return this.getItemById(req, res);
    } catch (error) {
        console.log({ error });
        return res.json({ status: false, error })
    }

};

exports.deleteItem = async (req, res, next) => {

    return await req.db.PurchaseOrder.update(
        { status: false },
        {
            where: { id: req.params.id },
        }
    ).then(async () => {
        return this.getItemById(req, res);
    })
        .catch(err => {
            res.status(200).send(err);
        })
};


