const fs =require('fs');
const config = require('../config/config');
const path = require('path');
exports.addFile =async(req, file, userId, entityType, entityId)=>{
  console.log('adding file', file.name);
  const savedFile =await saveBase64AsFile(file, userId);
  console.log({savedFile});
  if(savedFile && savedFile.status){
    const fileRecord = await req.db.File.create({
          title:file.name,
          status:1,
          createdBy:userId,
          updatedBy:userId,
          fileName:savedFile.name
      })
      if(fileRecord && fileRecord.id ){
        await req.db.EntityFile.create({
          fileId:fileRecord.id,
          fileableId:entityId,
          fileable:entityType,
          createdBy:userId,
          updatedBy:userId,
          status:1
        })
      }
      return {status:true, file: fileRecord}

    }
  return savedFile;
}
const saveBase64AsFile = async(file, userId)=>{

  let fileContents = file.data.split('base64').pop();
  fileContents = Buffer.from(fileContents, 'base64');
  const name =`${config.upload_dir}${userId}-${(new Date()).getTime()}-${file.name}`;
  try {
   fs.writeFileSync(name, fileContents, (err) => {
    if (err) {
      return {status: false, err: err.message}
    } else {
      return {status: true, name}
    }
    
  })
  return {status:true, name}
  } catch (err){
    return {status:false, err:err.message}
  }
}
exports.getFile= async(req,res,next)=>{
  const id =req.params.id;
  const file = await req.db.File.findOne({
    where:{
      id, status:1
    }
  })
  if(!file ){
    return res.status(404).send();
  }
  const  options = {
    root: path.join(__dirname+'/../')
  }; 
    res.sendFile(file.fileName, options, function (err) {
        if (err) {
           res.status(404).send();
        } else {
            console.log('Sent:', file.fileName);
        }
    });

}