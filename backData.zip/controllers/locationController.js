
const util = require('./util')
exports.countries = async (req, res, next) => {

    try {
        const data = await req.db.Country.findAll({
            attributes: ['id', 'sortname', 'name', 'phonecode']
        });
        return res.status(200).json(data);
    } catch (error) {
        return res.status(500).send(error);
    }
};
exports.getState = async (req, res, next) => {
    const id = req.params.id
    try {
        const data = await req.db.State.findAll({
            where: { country_id: id },
            attributes: ['id', 'name', 'country_id']
        });
        return res.status(200).json(data);
    } catch (error) {
        console.log();
        return res.status(500).send(error);
    }
};

exports.getCity = async (req, res, next) => {
    const id = req.params.id
    try {
        const data = await req.db.City.findAll({
            where: { state_id: id },
            attributes: ['id', 'name', 'state_id']
        });
        return res.status(200).json(data);
    } catch (error) {
        return res.status(500).send(error);
    }
};
exports.getRoles = async (req, res, next) => {
    try {
        let data = await req.db.UserRole.findAll();
        data =data.filter(item=>item.role !='admin')
        return res.status(200).json(data);
    } catch (error) {
        return res.status(500).send(error);
    }
};

exports.getEntityType = async (req, res, next) => {
    try {
        let data =Object.values(util.status.entity).map((k,v)=>{return {value:v, label:k}});
        // data =data.filter(item=>item.role !='admin')
        return res.status(200).json(data);
    } catch (error) {
        return res.status(500).send(error);
    }
};



