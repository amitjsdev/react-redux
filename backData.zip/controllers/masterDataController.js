const tradeController = require('./tradeController')
const usersController = require('./userController')
const util = require('./util')
const getConfiguration = async (req, key, isBoolean=false) => {
    let data = await req.db.Configuration.findOne({
        where: { configurationName: key },
        attributes: ['value']
    });

    return data && data.value ? JSON.parse(data.value) : isBoolean ? false: [];
}
exports.getMasterData = async (req, res, next) => {

    try {
        let roles;
        let commodities;
        let trade;
        let users
        roles = await req.db.UserRole.findAll({where:{status:1}});
        commodities = await req.db.Commodity.findAll({where:{status:1}});
        trade = await tradeController.Overview(req);
        users = await usersController.Overview(req);
        earning = await tradeController.Earning(req);
        const masterData = {
            status:util.status,
            trade,
            trading:[{status:1,count:3},{status:0,count:3}],
            users,
            earning,
            roles,
            commodities,
            // notification,
            // task,
        };
        return res.status(200).json(masterData);
    } catch (error) {
        console.log(error);
        return res.status(500).send(error);
    }
};

exports.tradestatus = async (req, res, next) => {

    try {
       
        return res.status(200).json(util.status);
    } catch (error) {
        console.log(error);
        return res.status(500).send(error);
    }
};
exports.transitStatus = async (req, res, next) => {

    try {
       
        return res.status(200).json(util.status.ts);
    } catch (error) {
        console.log(error);
        return res.status(500).send(error);
    }
};

exports.getTaxes = async (req, res, next) => {

    try {
        const data =await req.db.Tax.findAll()
        return res.status(200).json(data);
    } catch (error) {
        console.log(error);
        return res.status(500).send(error);
    }
};
exports.Unites = async (req, res, next) => {

    try {
        const data =await req.db.Unit.findAll()
        return res.status(200).json(data);
    } catch (error) {
        console.log(error);
        return res.status(500).send(error);
    }
};


exports.postUserSocket = async (req, res, next) => {
    const socketId = req.body.socketId;
    const userId = req.body.userId;
    const id = req.user.id;
    const postUserSocket = await req.db.UserSocket.create(
        {

            userId: userId,
            socketId: socketId,
            createdBy: id,
            updatedBy: id
        }
    )
    return res.status(200).json(postUserSocket);
};




