const { check, custom, validationResult } = require('express-validator/check');
const { Op } = require('sequelize')
exports.validate = (functionName) => {
    switch (functionName) {
        case 'new':
            return [
                check('holder_name', 'Account holder name  is required').not().isEmpty(),
                check('account_number', 'Account number   is required').not().isEmpty(),
                check('bank', 'Bank name  is required').not().isEmpty(),
                check('ifsc', 'IFSC  is required').not().isEmpty(),
                
            ];

        default:
            throw new Error('invalid user controller function name');
    }
};

exports.getAllItems = async (req, res, next) => {
    try {

        const data = await req.db.Banks.findOne({
            where:{user_id:req.jwtPayload.id, status:1}});
        return res.status(200).json({ status: true, data });
    } catch (error) {
        return res.status(500).send({ status: false, error });
    }
};

exports.getItemById = async (req, res) => {
    try {
        const data = await req.db.Banks.findOne({
            where: {
                id: req.params.id,
                user_id:req.jwtPayload.id
            }});
        return res.status(200).json({ status: true, data });
    } catch (error) {
        console.log({ error });
        return res.status(500).send({ status: false, error });
    }
}


exports.createNewItem = async (req, res, next) => {
    // try{
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(200).json({ errors: errors.array() });
    }
    
    const creater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0
    const hasBank = await req.db.Banks.findOne({where:{user_id:creater,status:1}});
    if(hasBank && hasBank.id){
        req.params.id =hasBank.id;
        return this.updateItem(req, res,next)
    }
        await req.db.Banks.create(
            {
                ...req.body,
                createdBy: creater,
                updatedBy: creater,
                 status: 1,
                user_id:creater
            })
   
        return this.getAllItems(req, res);
    // } catch {
    //     return res.status(200).json({ status: false });
    // }
};
exports.updateItem = async (req, res, next) => {
    // try {
    let query = {};
    const id = req.params.id;
    const updater = req && req.jwtPayload && req.jwtPayload.id ? req.jwtPayload.id : 0
    const item = await req.db.Banks.findOne({
        where: { createdBy: updater, id }
    })
    if (!item) {
        return res.json({ status: false, msg: 'Bank Detail not found' })
    }
    const {holder_name, account_number, ifsc, bank,swift, status } = req.body;
    if (holder_name) {
        query = { ...query, holder_name };
    } if (account_number) {
        query = { ...query, account_number };
    } if (ifsc) {
        query = { ...query, ifsc };
    
    } if (bank) {
        query = { ...query, bank };
    }
    if (status !== undefined) {
        query = { ...query, status };
    }


    if (Object.keys(query).length > 0) {

        query = { ...query, updatedBy: updater, updatedAt: new Date() }

        await req.db.Banks.update(query, { where: { id, createdBy: updater } })
    }
    return this.getItemById(req, res);
    // } catch (error) {
    //     console.log({error});
    //     return res.json({ status: false, error })
    // }

};


exports.deleteItem = async (req, res, next) => {

    return await req.db.Banks.update(
        { status: false },
        {
            where: { id: req.params.id, createdBy:req.jwtPayload.id },
        }
    ).then(async () => {
        return this.getItemById(req, res);
    })
        .catch(err => {
            res.status(200).send(err);
        })
};


