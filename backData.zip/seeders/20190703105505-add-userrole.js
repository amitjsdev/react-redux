'use strict';
const moment = require('moment');
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('user_roles', [
      { 
        id: 1,
      role: 'admin',
      status: 1,
      createdBy: 1,
      updatedBy: 1,
      createdAt: moment()
          .utc()
          .toDate(),
      updatedAt: moment()
          .utc()
          .toDate()    
    },
      { 
        id: 2,
      role: 'buyer',
      status: 1,
      createdBy: 1,
      updatedBy: 1,
      createdAt: moment()
          .utc()
          .toDate(),
      updatedAt: moment()
          .utc()
          .toDate()    
    },
      { 
        id: 3,
      role: 'seller',
      status: 1,
      createdBy: 1,
      updatedBy: 1,
      createdAt: moment()
          .utc()
          .toDate(),
      updatedAt: moment()
          .utc()
          .toDate()    
    },
    
   
  ], {});
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('users', null, {});
  }
};
