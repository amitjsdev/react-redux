'use strict';
const moment = require('moment');
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('users', [
      {
      userName: 'admin',
      first_name: 'Admin',
      last_name: 'dev',
      email: 'admin@vh.com',
      password: '$2b$10$0p9oCufNuvpqgn0UxZLifeJoASd1yh1nybVqfUBKr/GOijlktP84.',
      mobile: '',
      userRoleId: 1,
      status: 1,
      createdAt: moment()
          .utc()
          .toDate(),
      updatedAt: moment()
          .utc()
          .toDate()    
    },
    
   
  ], {});
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('users', null, {});
  }
};
