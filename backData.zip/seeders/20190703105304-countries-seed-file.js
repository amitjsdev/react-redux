'use strict';
const moment = require('moment');
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('commodity', [
      {
      name: 'Bajra',
      description: 'Black indian chana',
      nodal_price: 2,
      min_price: 2,
      max_price: 2,
      other: '',
      type: 'Perishable',
      status: 1,
      createdBy: 1,
      updatedBy: 1,
      createdAt: moment()
          .utc()
          .toDate(),
      updatedAt: moment()
          .utc()
          .toDate()    
    },
      {
      name: 'Chana',
      description: 'indian chana brown',
      nodal_price: 2,
      min_price: 2,
      max_price: 2,
      other: '',
      type: 'Perishable',
      status: 1,
      createdBy: 1,
      updatedBy: 1,
      createdAt: moment()
          .utc()
          .toDate(),
      updatedAt: moment()
          .utc()
          .toDate()    
    },  {
      name: 'Baley',
      description: 'indian Baley brown',
      nodal_price: 2,
      min_price: 2,
      max_price: 2,
      other: '',
      type: 'Perishable',
      status: 1,
      createdBy: 1,
      updatedBy: 1,
      createdAt: moment()
          .utc()
          .toDate(),
      updatedAt: moment()
          .utc()
          .toDate()    
    }, 
     {
      name: 'Wheat',
      description: 'indian Wheat brown',
      nodal_price: 2,
      min_price: 2,
      max_price: 2,
      other: '',
      type: 'Perishable',
      status: 1,
      createdBy: 1,
      updatedBy: 1,
      createdAt: moment()
          .utc()
          .toDate(),
      updatedAt: moment()
          .utc()
          .toDate()    
    },
   
  ], {});
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('countries', null, {});
  }
};
