'use strict';
const util = require('../controllers/util')

module.exports = (sequelize, DataTypes) => {
  const Payment = sequelize.define('Payment', {
    mode: DataTypes.STRING,
    amount: DataTypes.FLOAT,
    commision: DataTypes.FLOAT,
    tax: DataTypes.FLOAT,
    total: DataTypes.FLOAT,
    qid: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    sellerId: DataTypes.INTEGER,
    buyerId: DataTypes.INTEGER,
    statusStr: {
      type: DataTypes.VIRTUAL,
      get() {
        return util && util.status && util.status.payment && util.status.payment[this.status] ? util.status.payment[this.status] :''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    },payu: {
      type: DataTypes.VIRTUAL,
      get() {
        return this.transactions && this.transactions[0] ? this.transactions[0]:''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    }

  }, {
    
    tableName: 'payment'
  }
  );
  Payment.associate = function (models) {
    
    Payment.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    Payment.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
    Payment.belongsTo(models.User,{foreignKey: 'sellerId',as: 'seller'})
    Payment.belongsTo(models.User,{foreignKey: 'buyerId',as: 'buyer'})
    Payment.belongsTo(models.Qoutes,{foreignKey: 'qid',as: 'qt'})
    Payment.hasMany(models.Transaction,{foreignKey: 'paymentId',as: 'transactions'})
    Payment.hasMany(models.Transaction,{foreignKey: 'paymentId',as: 'success'})
  };

  return Payment;
};
