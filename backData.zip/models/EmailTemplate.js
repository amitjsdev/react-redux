'use strict';
module.exports = (sequelize, DataTypes) => {
  const EmailTemplate = sequelize.define('EmailTemplate', {
    name: DataTypes.STRING,
    subject: DataTypes.STRING,
    email: DataTypes.STRING,
    body: DataTypes.TEXT,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
  }, {
      tableName: 'email_template'
    });
  EmailTemplate.associate = function (models) {
    EmailTemplate.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    EmailTemplate.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
  };
  return EmailTemplate;
};