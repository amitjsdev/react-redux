'use strict';
module.exports = (sequelize, DataTypes) => {
  const Country = sequelize.define('Country', {
    sortname: DataTypes.STRING,
    name: DataTypes.STRING,
    phonecode: DataTypes.STRING,
  }, {
    tableName: 'countries', timestamps: false
  });
  Country.associate = function(models) {
    // Country.belongsToMany(models.ClassificationSystem, {
    //   through: models.CountryClassificationSystem,
    //   as: 'classificationSystems'
    // });
    // Country.belongsTo(models.Address);
  };
  return Country;
};
