'use strict';
module.exports = (sequelize, DataTypes) => {
  const Identity = sequelize.define('Identity', {
    title: DataTypes.STRING,
    number: DataTypes.STRING,
    description: DataTypes.STRING,
    userId: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    updatedAt:DataTypes.DATE,
  }, {
      tableName: 'identity'
    });
  Identity.associate = function (models) {
    Identity.hasOne(models.EntityFile, {
      foreignKey: 'fileableId',
      // where:{}
    });
    Identity.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    Identity.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
  };
  return Identity;
};