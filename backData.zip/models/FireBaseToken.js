'use strict';
module.exports = (sequelize, DataTypes) => {
  const FireBaseToken = sequelize.define('FireBaseToken', {
    userId: DataTypes.INTEGER,
    token: DataTypes.STRING,
    mobile: DataTypes.STRING,
  }, {
    tableName: 'firebase_token', 
  });
  FireBaseToken.associate = function(models) {
   
    FireBaseToken.belongsTo(models.User, {foreignKey: 'userId',as: 'fb'});
  };
  return FireBaseToken;
};
