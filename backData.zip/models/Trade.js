'use strict';
const util = require('../controllers/util')
module.exports = (sequelize, DataTypes) => {
  const Trade = sequelize.define('Trade', {
    description: DataTypes.STRING,
    title: DataTypes.STRING,
    quantity: DataTypes.FLOAT,
    commodityId: DataTypes.INTEGER,
    unitId: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
    broadcastDate: DataTypes.DATE,
    closeDate: DataTypes.DATE,
    updatedAt: DataTypes.DATE,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    rejected_at: DataTypes.DATE,
    canceled_at: DataTypes.DATE,
    is_rejected: DataTypes.BOOLEAN,
    is_canceled: DataTypes.BOOLEAN,

    statusStr: {
      type: DataTypes.VIRTUAL,
      get() {
        return util && util.status && util.status.trade && util.status.trade[this.status] ? util.status.trade[this.status] :''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    },
    remaining: {
      type: DataTypes.VIRTUAL,
      get() {
        
        return this.quantity && this.acceptedQty   ? this.quantity - parseFloat(this.acceptedQty) : this.quantity;
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    }

  }, {
    
    tableName: 'trade'
  }
  );
  Trade.associate = function (models) {
    Trade.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    Trade.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
    Trade.belongsTo(models.User,{foreignKey: 'createdBy',as: 'buyer'})
    Trade.belongsTo(models.Commodity,{foreignKey: 'commodityId',as: 'commodity'})
    // Trade.hasOne(models.Qoutes, {
    //   foreignKey: 'tradeID',
    //   constraints: false,
    //   as:'qoute',
    //   scope: {
    //     qoutes_status: 'Accepted',
    //     status:1
    //   }
    // });
    Trade.hasMany(models.Qoutes, {
      foreignKey: 'tradeId',
      as:'Qoutes',
    });
     Trade.hasMany(models.Qoutes, {
      foreignKey: 'tradeId',
      as:'tq',
    });  
    Trade.belongsTo(models.Unit,{foreignKey: 'unitId',as: 'unit'});
    Trade.hasMany(models.History, {
      foreignKey: 'entityId',
      constraints: false,
      as:'history',
      scope: {
        entity: 'trade',
        status:1
      }
    });
    // Trade.hasMany(models.Payment)
  
  };

  return Trade;
};
