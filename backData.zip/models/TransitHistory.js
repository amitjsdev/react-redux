'use strict';
const util = require('../controllers/util')
module.exports = (sequelize, DataTypes) => {
  const TransitHistory = sequelize.define('TransitHistory', {
    tracking_number: DataTypes.STRING,
    vehical: DataTypes.STRING,
    transitId: DataTypes.INTEGER,
    comment: DataTypes.STRING,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    expected: DataTypes.DATE,
    delivery_date: DataTypes.DATE,
    statusStr: {
      type: DataTypes.VIRTUAL,
      get() {
        return util && util.status && util.status.ts && util.status.ts[this.status] ? util.status.ts[this.status] :''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    }

  }, {
    
    tableName: 'transit_history'
  }
  );
  TransitHistory.associate = function (models) {
    
    TransitHistory.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    // TransitHistory.belongsTo(models.Transit,{foreignKey: 'transit_id',as: 'history'})
  };

  return TransitHistory;
};
