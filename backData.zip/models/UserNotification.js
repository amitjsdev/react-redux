'use strict';
module.exports = (sequelize, DataTypes) => {
  const UserNotification = sequelize.define('UserNotification', {
    fromUserId: DataTypes.INTEGER,
    toUserId: DataTypes.INTEGER,
    entityId: DataTypes.STRING,
    notificationId: DataTypes.INTEGER,
    isRead:DataTypes.INTEGER,
    status: DataTypes.INTEGER,
    // owner: DataTypes.INTEGER,
    // entityRecordId: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    // country: DataTypes.STRING,
    // title: DataTypes.TEXT
  }, {
    tableName: 'user_notifications'
  });
  UserNotification.associate = function(models) {
    // associations can be defined here
    UserNotification.belongsTo(models.Notification);
    UserNotification.belongsTo(models.User, {
      foreignKey: 'fromUserId',
      as: 'Assignor'
    });
    UserNotification.belongsTo(models.User, {
      foreignKey: 'toUserId',
      as: 'Assignee'
    })
  };
  return UserNotification;
};