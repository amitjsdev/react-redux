'use strict';
module.exports = (sequelize, DataTypes) => {
  const Settings = sequelize.define('Settings', {
    title: DataTypes.STRING,
    description: DataTypes.STRING,
    data: DataTypes.JSON,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
  }, {
      tableName: 'settings'
    });
  Settings.associate = function (models) {
    Settings.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    Settings.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
  };
  return Settings;
};