'use strict';
const util = require('../controllers/util')
module.exports = (sequelize, DataTypes) => {
  const Qoutes = sequelize.define('Qoutes', {
    description: DataTypes.STRING,
    acceptedAt: DataTypes.DATE,
    price: DataTypes.FLOAT,
    tradeId: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    quantity: DataTypes.INTEGER,
    statusStr: {
      type: DataTypes.VIRTUAL,
      get() {
        return util && util.status && util.status.qt && util.status.qt[this.status] ? util.status.qt[this.status] :''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    }
  }, {
    
    tableName: 'qoutes'
  }
  );
  Qoutes.associate = function (models) {
    
    Qoutes.belongsTo(models.User,{foreignKey: 'createdBy',as: 'seller'})
    Qoutes.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    Qoutes.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
    Qoutes.belongsTo(models.Trade,{foreignKey: 'tradeId',as: 'trade'})
    Qoutes.hasOne(models.PurchaseOrder,{foreignKey: 'qid',as: 'po'})
    Qoutes.hasOne(models.Payment,{foreignKey: 'qid',as: 'Payment'})
   
  };

  return Qoutes;
};
