'use strict';
module.exports = (sequelize, DataTypes) => {
  const State = sequelize.define('State', {
    name: DataTypes.STRING,
    country_id: DataTypes.STRING,
  }, {
    tableName: 'states', timestamps: false
  });
  State.associate = function(models) {
    // State.belongsToMany(models.ClassificationSystem, {
    //   through: models.StateClassificationSystem,
    //   as: 'classificationSystems'
    // });
    // State.belongsTo(models.Address);
  };
  return State;
};
