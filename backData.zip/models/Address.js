'use strict';


module.exports = (sequelize, DataTypes) => {
  const Address = sequelize.define('Address', {
    address1: DataTypes.STRING,
    address2: DataTypes.STRING,
    state: DataTypes.STRING,
    city: DataTypes.STRING,
    country: DataTypes.STRING,
    zip: DataTypes.STRING,
    district: DataTypes.STRING,
    lat: DataTypes.STRING,
    lng: DataTypes.STRING,
    type: DataTypes.STRING,
    status: DataTypes.INTEGER,
    userId: DataTypes.INTEGER,
    countryName: {
      type: DataTypes.VIRTUAL,
      get() {
        return this.Country && this.Country.name ? this.Country.name :''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    },
    stateName: {
      type: DataTypes.VIRTUAL,
      get() {
        return this.State && this.State.name ? this.State.name :''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    },
    cityName: {
      type: DataTypes.VIRTUAL,
      get() {
        return this.City && this.City.name ? this.City.name :''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    }

  }, {
    tableName: 'address'
  }
  );
  Address.associate = function (models) {
    Address.belongsTo(models.User);
    Address.belongsTo(models.Country,{foreignKey: 'country',as: 'Country'})
    Address.belongsTo(models.State,{foreignKey: 'state',as: 'State'})
    Address.belongsTo(models.City,{foreignKey: 'city',as: 'City'})
    
  };

  return Address;
};
