'use strict';
module.exports = (sequelize, DataTypes) => {
  const EntityIdentity = sequelize.define('EntityIdentity', {
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    commodityTypeable: DataTypes.STRING,
    commodityTypeableId: DataTypes.INTEGER,
    commodityId:DataTypes.INTEGER,
  }, {
    tableName: 'entity_identity'
  });
  EntityIdentity.associate = function(models) {
    
    EntityIdentity.belongsTo(models.Identity);
  };
  return EntityIdentity;
};