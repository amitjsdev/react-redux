'use strict';
module.exports = (sequelize, DataTypes) => {
  const File = sequelize.define('File', {
    title: DataTypes.STRING,
    fileName: DataTypes.STRING,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    updatedAt:DataTypes.DATE,
  }, {
      tableName: 'files'
    });
  File.associate = function (models) {
    File.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    File.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
  };
  return File;
};