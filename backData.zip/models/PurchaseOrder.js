'use strict';
const util = require('../controllers/util')

module.exports = (sequelize, DataTypes) => {
  const PurchaseOrder = sequelize.define('PurchaseOrder', {
    buyer_comment: DataTypes.TEXT,
    seller_comment: DataTypes.TEXT,
    seller_response: DataTypes.STRING,
    seller_response_date: DataTypes.DATE,
    acceptedAt: DataTypes.DATE,
    rejectedAt: DataTypes.DATE,
    submittedAt: DataTypes.DATE,
    canceledAt: DataTypes.DATE,
    qid: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
    seller_id: DataTypes.INTEGER,
    buyer_id: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    tax: DataTypes.STRING,
    total: DataTypes.FLOAT,
    statusStr: {
      type: DataTypes.VIRTUAL,
      get() {
        return util && util.status && util.status.po && util.status.po[this.status] ? util.status.po[this.status] :''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    }

  }, {
    
    tableName: 'purchase_order'
  }
  );
  PurchaseOrder.associate = function (models) {
    
    PurchaseOrder.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    PurchaseOrder.belongsTo(models.User,{foreignKey: 'buyer_id',as: 'buyer'})
    PurchaseOrder.belongsTo(models.User,{foreignKey: 'seller_id',as: 'seller'})
    PurchaseOrder.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
    PurchaseOrder.belongsTo(models.Qoutes,{foreignKey: 'qid',as: 'qt'})
   
    PurchaseOrder.hasOne(models.EntityFile, {
      foreignKey: 'fileableId',
      constraints: false,
      scope: {
        fileable: 'po'
      }
    });
  };

  return PurchaseOrder;
};
