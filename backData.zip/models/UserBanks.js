'use strict';


module.exports = (sequelize, DataTypes) => {
  const UserBank = sequelize.define('UserBank', {
    name: DataTypes.STRING,
    number: DataTypes.STRING,
    bank: DataTypes.STRING,
    ifsc: DataTypes.STRING,
    bank_address: DataTypes.STRING,
    bank_city: DataTypes.STRING,
    bank_zip: DataTypes.STRING,
    bank_asso: DataTypes.STRING,
    swift_code: DataTypes.STRING,
    status: DataTypes.INTEGER,
    userId: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedAt: DataTypes.INTEGER,

  }, {
    tableName: 'users_banks'
  }
  );
  UserBank.associate = function (models) {
    UserBank.belongsTo(models.User);
    
  };

  return UserBank;
};
