'use strict';

module.exports = (sequelize, DataTypes) => {
  const Otp = sequelize.define('Otp', {
    data: DataTypes.JSON,
    userId: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
  }, {
    
    tableName: 'otp'
  }
  );
  Otp.associate = function (models) {
    
   
    Otp.belongsTo(models.User)
  };

  return Otp;
};
