'use strict';
module.exports = (sequelize, DataTypes) => {
  const Notification = sequelize.define('Notification', {
    content: DataTypes.TEXT,
    entity: DataTypes.STRING,
    entityStage: DataTypes.STRING,
    subject: DataTypes.STRING
  }, {
    tableName: 'notifications'
  });
  Notification.associate = function(models) {
    // associations can be defined here
    Notification.hasMany(models.UserNotification,{
      foreginKey:'notificationId'
    })
  };
  return Notification;
};