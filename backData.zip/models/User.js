'use strict';
var bcrypt = require('bcrypt');
const config = require('../config/config');
const util = require('../controllers/util')
module.exports = (sequelize, DataTypes) => {
  //$2b$10$0p9oCufNuvpqgn0UxZLifeJoASd1yh1nybVqfUBKr/GOijlktP84.
  const User = sequelize.define('User', {
    userName: DataTypes.STRING,
    first_name: DataTypes.STRING,
    last_name: DataTypes.STRING,
    email: DataTypes.STRING,
    comment: DataTypes.TEXT,
    // pan: DataTypes.STRING,
    // address: DataTypes.STRING,
    // state: DataTypes.STRING,
    // city: DataTypes.STRING,
    // country: DataTypes.STRING,
    // zip: DataTypes.STRING,
    mobile: DataTypes.INTEGER,
    otp: DataTypes.INTEGER,
    mailOtp: DataTypes.INTEGER,
    dob: DataTypes.DATE,
    password: DataTypes.STRING,
    status: DataTypes.INTEGER,
    userRoleId: DataTypes.INTEGER,
    notification: DataTypes.INTEGER,
    entity: DataTypes.INTEGER,
    task: DataTypes.INTEGER,
    otp_sent_at: DataTypes.DATE,
    last_activity_time: DataTypes.STRING,
    // loggedOutTime: DataTypes.DATE,
    full_name: {
      type: DataTypes.VIRTUAL,
      get() {
        return `${this.first_name} ${this.last_name}`
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    },
    statusStr: {
      type: DataTypes.VIRTUAL,
      get() {
        return util && util.status && util.status.user && util.status.user[this.status] ? util.status.user[this.status] : ''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    },
    entityStr: {
      type: DataTypes.VIRTUAL,
      get() {
        return util && util.status && util.status.entity && util.status.entity[this.entity] ? util.status.entity[this.entity] : ''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    }


  }, {
    hooks: {
      beforeCreate: user => {
        const salt = bcrypt.genSaltSync();
        user.password = bcrypt.hashSync(user.password, salt);
      }
    },
    tableName: 'users'
  }
  );
  User.associate = function (models) {
    User.belongsTo(models.UserRole);
    User.hasOne(models.Banks, {
      foreignKey: 'user_id'
    });
    User.hasMany(models.UserSocket, {
      foreignKey: 'userId'
    });
    User.hasMany(models.Address, {
      foreignKey: 'userId'
    });
    User.hasOne(models.Address, {
      foreignKey: 'userId',
      constraints: false,
      as: 'bAddress',
      scope: {
        type: 'bussiness'
      }
    });
    User.hasOne(models.Identity, {
      foreignKey: 'userId',
      constraints: false,
      as: 'aadhar',
      scope: {
        title: 'aadhar'
      }
    });
    User.hasOne(models.Identity, {
      foreignKey: 'userId',
      constraints: false,
      as: 'pan',
      scope: {
        title: 'pan'
      }
    });
    User.hasOne(models.Identity, {
      foreignKey: 'userId',
      constraints: false,
      as: 'gstin',
      scope: {
        title: 'gstin'
      }
    }); User.hasOne(models.Identity, {
      foreignKey: 'userId',
      constraints: false,
      as: 'export',
      scope: {
        title: 'export'
      }
    }); User.hasOne(models.Identity, {
      foreignKey: 'userId',
      constraints: false,
      as: 'import',
      scope: {
        title: 'import'
      }
    });
    User.hasOne(models.Address, {
      foreignKey: 'userId',
      constraints: false,
      as: 'residential',
      scope: {
        type: 'residential'
      }
    });
    User.hasMany(models.History, {
      foreignKey: 'entityId',
      constraints: false,
      as: 'history',
      scope: {
        entity: 'user'
      }
    });
    User.hasMany(models.UserBank, {
      foreignKey: 'userId'
    });
    User.hasMany(models.FireBaseToken, {
      foreignKey: 'userId',
      as:'fb'
    });
    User.hasMany(models.Identity, {
      foreignKey: 'userId'
    });
    User.hasMany(models.EntityCommodity, {
      foreignKey: 'commodityTypeableId'
    });

  };
  User.prototype.validPassword = function (password) {
    if (config.usePasswordEncryption === 'true') {
      return bcrypt.compareSync(password, this.password);
    }
    else {
      return password === this.password;
    }
  };

  return User;
};
