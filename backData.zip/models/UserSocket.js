'use strict';

module.exports = (sequelize, DataTypes) => {
  const UserSocket = sequelize.define('UserSocket', {
    userId: DataTypes.INTEGER,
    socketId: DataTypes.STRING,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER
  }, {
    tableName: 'user_sockets'
  });
  UserSocket.associate = function(models) {
      UserSocket.belongsTo(models.User);
  };


  return UserSocket;
};
