'use strict';

module.exports = (sequelize, DataTypes) => {
  const Transaction = sequelize.define('Transaction', {
    mode: DataTypes.STRING,
    amount: DataTypes.FLOAT,
    meta: DataTypes.JSON,
    transaction_status: DataTypes.STRING,
    tId: DataTypes.STRING,
    qId: DataTypes.INTEGER,
    paymentId: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,

  }, {
    
    tableName: 'transactions'
  }
  );
  Transaction.associate = function (models) {
    
    Transaction.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    Transaction.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
    Transaction.belongsTo(models.Payment,{as:'payment'})
  };

  return Transaction;
};
