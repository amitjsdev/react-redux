'use strict';
module.exports = (sequelize, DataTypes) => {
  const EmailNotification = sequelize.define('EmailNotification', {
    name: DataTypes.STRING,
    subject: DataTypes.STRING,
    email: DataTypes.STRING,
    body: DataTypes.TEXT,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
  }, {
      tableName: 'email_notification'
    });
  EmailNotification.associate = function (models) {
    EmailNotification.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    EmailNotification.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
  };
  return EmailNotification;
};