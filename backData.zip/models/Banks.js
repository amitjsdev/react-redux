'use strict';
module.exports = (sequelize, DataTypes) => {
  const Banks = sequelize.define('Banks', {
    user_id: DataTypes.INTEGER,
    holder_name: DataTypes.STRING,
    account_number: DataTypes.STRING,
    bank: DataTypes.STRING,
    ifsc: DataTypes.STRING,
    swift: DataTypes.STRING,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
  }, {
    tableName: 'banks', 
  });
  Banks.associate = function(models) {
   
    Banks.belongsTo(models.User, {foreignKey: 'user_id',as: 'userbank'});
  };
  return Banks;
};
