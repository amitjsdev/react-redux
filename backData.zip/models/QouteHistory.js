'use strict';

module.exports = (sequelize, DataTypes) => {
  const QoutesHistory = sequelize.define('QoutesHistory', {
    description: DataTypes.STRING,
    price: DataTypes.FLOAT,
    qouteId: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
    oldData: DataTypes.TEXT,
    newData: DataTypes.TEXT,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,

  }, {
    
    tableName: 'qoutes_history'
  }
  );
  QoutesHistory.associate = function (models) {
    
  
  };

  return QoutesHistory;
};
