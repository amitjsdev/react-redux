'use strict';
module.exports = (sequelize, DataTypes) => {
  const City = sequelize.define('City', {
    name: DataTypes.STRING,
    state_id: DataTypes.STRING,
  }, {
    tableName: 'cities', timestamps: false
  });
  City.associate = function(models) {
    // City.belongsToMany(models.ClassificationSystem, {
    //   through: models.CityClassificationSystem,
    //   as: 'classificationSystems'
    // });
    // City.belongsTo(models.Address);
  };
  return City;
};
