'use strict';
const util = require('../controllers/util')
module.exports = (sequelize, DataTypes) => {
  const Transit = sequelize.define('Transit', {
    tracking_number: DataTypes.STRING,
    vehical: DataTypes.STRING,
    qid: DataTypes.INTEGER,
    seller_id: DataTypes.INTEGER,
    buyer_id: DataTypes.INTEGER,
    transit_status: DataTypes.STRING,
    comment: DataTypes.STRING,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    expected: DataTypes.DATE,
    initiated: DataTypes.DATE,
    delivery_date: DataTypes.DATE,
    statusStr: {
      type: DataTypes.VIRTUAL,
      get() {
        return util && util.status && util.status.ts && util.status.ts[this.transit_status] ? util.status.ts[this.transit_status] :''
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    }

  }, {
    
    tableName: 'transit'
  }
  );
  Transit.associate = function (models) {
    
    Transit.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    Transit.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
    Transit.belongsTo(models.User,{foreignKey: 'seller_id',as: 'seller'})
    Transit.belongsTo(models.User,{foreignKey: 'buyer_id',as: 'buyer'})
    Transit.belongsTo(models.Qoutes,{foreignKey: 'qid',as: 'qt'})
    Transit.hasMany(models.TransitHistory)
  };

  return Transit;
};
