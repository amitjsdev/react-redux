'use strict';
module.exports = (sequelize, DataTypes) => {
  const SmsNotification = sequelize.define('SmsNotification', {
    content: DataTypes.TEXT,
    entity: DataTypes.STRING,
    entityStage: DataTypes.STRING,
    subject: DataTypes.STRING
  }, {
    tableName: 'sms_notifications'
  });
  SmsNotification.associate = function(models) {
    // associations can be defined here
    SmsNotification.hasMany(models.UserNotification,{
      foreginKey:'notificationId'
    })
  };
  return SmsNotification;
};