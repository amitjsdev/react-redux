'use strict';

module.exports = (sequelize, DataTypes) => {
  const Unit = sequelize.define('Unit', {
    name: DataTypes.STRING,
    minimum: DataTypes.INTEGER,
    minimum_required: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
  }, {
    
    tableName: 'units'
  }
  );
  Unit.associate = function (models) {
  };

  return Unit;
};
