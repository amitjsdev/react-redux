'use strict';
module.exports = (sequelize, DataTypes) => {
  const EntityCommodity = sequelize.define('EntityCommodity', {
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    commodityTypeable: DataTypes.STRING,
    commodityTypeableId: DataTypes.INTEGER,
    commodityId:DataTypes.INTEGER,
  }, {
    tableName: 'entity_commodity'
  });
  EntityCommodity.associate = function(models) {
    // EntityCommodity.hasMany(models.Commodity, {
    //   foreignKey: 'commodityTypeableId',
    //   // where:{}
    // });
    EntityCommodity.belongsTo(models.Commodity);
  };
  return EntityCommodity;
};