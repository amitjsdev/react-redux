'use strict';
module.exports = (sequelize, DataTypes) => {
  const Configuration = sequelize.define('Configuration', {
    configurationName: DataTypes.STRING,
    value: DataTypes.STRING(65000),
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER
  }, {
    tableName: 'configurations'
  });
  Configuration.associate = function(models) {
    // associations can be defined here
  };
  return Configuration;
};
