'use strict';

module.exports = (sequelize, DataTypes) => {
  const History = sequelize.define('History', {
    comment: DataTypes.STRING,
    entity: DataTypes.STRING,
    entityId: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
    oldData: DataTypes.TEXT,
    newData: DataTypes.TEXT,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,

  }, {
    
    tableName: 'history'
  }
  );
  History.associate = function (models) {
    History.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    History.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
  
  };

  return History;
};
