'use strict';
module.exports = (sequelize, DataTypes) => {
  const EntityFile = sequelize.define('EntityFile', {
    fileable: DataTypes.STRING,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
    fileableId: DataTypes.INTEGER,
    fileId:DataTypes.INTEGER,
  }, {
    tableName:'entity_files'
  });
  EntityFile.associate = function(models) {
    // EntityFile.hasOne(models.File, {
    //   foreignKey: 'fileId',
    //   // where:{}
    // });
    EntityFile.belongsTo(models.File);
  };
  return EntityFile;
};