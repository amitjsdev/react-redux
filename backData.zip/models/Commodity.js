'use strict';
module.exports = (sequelize, DataTypes) => {
  const Commodity = sequelize.define('Commodity', {
    name: DataTypes.STRING,
    description: DataTypes.STRING,
    other: DataTypes.STRING,
    max_price: DataTypes.FLOAT,
    min_price: DataTypes.FLOAT,
    nodal_price: DataTypes.FLOAT,
    buyer_min_qty: DataTypes.FLOAT,
    seller_min_qty: DataTypes.FLOAT,
    attributes: DataTypes.JSON,
    certifications: DataTypes.JSON,
    type: DataTypes.STRING,
    status: DataTypes.INTEGER,
    createdBy: DataTypes.INTEGER,
    updatedBy: DataTypes.INTEGER,
    updatedAt:DataTypes.DATE,
    parsedAttributes: {
      type: DataTypes.VIRTUAL,
      get() {
        try {
          return this.attributes ? JSON.parse(this.attributes): null

        }catch (e){
          return null
        }
       
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    },
    parsedCertifications: {
      type: DataTypes.VIRTUAL,
      get() {
        try {
          return this.certifications ? JSON.parse(this.certifications): null

        }catch (e){
          return null
        }
       
      },
      set(value) {
        throw new Error('Do not try to set the `statusStr` value!');
      }
    },
  }, {
      tableName: 'commodity'
    });
  Commodity.associate = function (models) {
    Commodity.belongsTo(models.User,{foreignKey: 'createdBy',as: 'CreatedUser'})
    Commodity.belongsTo(models.User,{foreignKey: 'updatedBy',as: 'UpdatedUser'})
    Commodity.hasOne(models.EntityFile, {
      foreignKey: 'fileableId'
    });
  };
  return Commodity;
};