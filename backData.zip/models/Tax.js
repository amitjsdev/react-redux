'use strict';

module.exports = (sequelize, DataTypes) => {
  const Tax = sequelize.define('Tax', {
    name: DataTypes.STRING,
    value: DataTypes.INTEGER,
    status: DataTypes.INTEGER,
  }, {
    
    tableName: 'tax'
  }
  );
  Tax.associate = function (models) {
  };

  return Tax;
};
