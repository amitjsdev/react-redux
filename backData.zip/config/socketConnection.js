var socket = require('socket.io');
var io = socket(server);
var http = require('http');
var app = require('../app');
var server = http.createServer(app);

var ioConn = io.on('connection', (socket) => {
   Controller.fetchNotification(socket);
  
  });
  module.exports.default = ioConn;

  