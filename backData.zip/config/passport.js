const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const passportJWT = require("passport-jwt");
const JWTStrategy = passportJWT.Strategy;
const ExtractJWT = passportJWT.ExtractJwt;
const config = require('../config/config');
const moment = require('moment');
const { getConfiguration,lastActivityTime } = require('../services/helpers');
passport.use(new LocalStrategy({
    usernameField: 'email',
    passReqToCallback: true
},
    async (req, email, password, cb) => { 
       
        try {
            req.db.User.findOne({
                where: {
                    email
                }
            }).then(async (user) => {
                
               
                if (!user) {
                    return cb(null, false, { message: 'Invalid Credentials' });
                } else if (!user.validPassword(password)) {
                    return cb(null, false, { message: 'Invalid Credentials' });
                }
                else if(!user.dataValues.status){
                    return cb(null, false, { message: 'User has been deactivated. Please contact Administrator.' });
                } 
                else {
                    lastActivityTime(req, user);
                    const role = await req.db.UserRole.findOne({ where: { id: user.userRoleId } });
                    user.role = role.role;
                    const data =user.dataValues;
                    data.role = role.role;
                    return cb(null, data, { message: 'Logged In Successfully' });
                }
            });
        } catch (error) {
            return cb(error);
        }
    }
));
passport.deserializeUser(async function (req, id, done) {

    const user = await req.db.User.findOne({ where: { id } });
    // put the actual role name on the user object
    const role = await req.db.UserRole.findOne({ where: { id: user.userRoleId } });
    user.role = role.role;
    console.log({role});
    done(null, user);
});

passport.serializeUser(function (user, done) {
    done(null, user.id);
});
passport.use(new JWTStrategy({
    // jwtFromRequest: ExtractJWT.fromAuthHeaderAsBearerToken(),
    jwtFromRequest: ExtractJWT.fromExtractors([ExtractJWT.fromUrlQueryParameter("st"),  ExtractJWT.fromAuthHeaderAsBearerToken()]),
    secretOrKey: config.jwtSecret,
    passReqToCallback: true
},
    async function (req, jwtPayload, cb) {
        req.jwtPayload=jwtPayload;
        // set box sdk for the client 
        try {
            const user = await req.db.User.findOne({ where: { id: jwtPayload.id } });
            // put the actual role name on the user object
            const role = await req.db.UserRole.findOne({ where: { id: user.userRoleId } });
            //console.log({role});
            if (user) {
                // const loginUrl =await getConfiguration(req, 'clientUrl');;
                // if(user.last_activity_time){
                //     const last  = moment().utc().diff(moment(user.last_activity_time), 'minutes');
                //     if(last >30){                       
                //         return cb({ message: 'session has been expired',session:false,loginUrl });
                        
                //     }
                // }
                user.role =role;
                lastActivityTime(req, user);
                return cb(null, user);
            }

            cb(new Error('Invalid user'));
        } catch (error) {
            console.log(error);
            return cb(error);
        }
    }
));

module.exports = passport;
