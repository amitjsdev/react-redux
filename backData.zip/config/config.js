const dotenv = require('../lib/dotenv');

//Make this global to use all over the application
var CONFIG = {} ;
CONFIG.username = dotenv.parsed.DB_USERNAME;
CONFIG.password = dotenv.parsed.DB_PASSWORD;
CONFIG.database = dotenv.parsed.DB_DATABASE;
CONFIG.port = dotenv.parsed.PORT;
CONFIG.url = dotenv.parsed.URL;
CONFIG.smtpHost = dotenv.parsed.smtpHost;
CONFIG.smtpPort = dotenv.parsed.smtpPort;
CONFIG.smtpUser = dotenv.parsed.smtpUser;
CONFIG.smtpPassword = dotenv.parsed.smtpPassword;
CONFIG.smtpFromEmail = dotenv.parsed.smtpFromEmail;
CONFIG.adminEmail = dotenv.parsed.adminEmail;
CONFIG.smtpFromName = dotenv.parsed.smtpFromName;
CONFIG.url = dotenv.parsed.URL;
CONFIG.jwtSecret = dotenv.parsed.JWT_SECRET;
CONFIG.sessionSecret = dotenv.parsed.SESSION_SECRET;
CONFIG.sessionLengthInMinutes = dotenv.parsed.SESSION_LENGTH_IN_MINUTES;
CONFIG.usePasswordEncryption = dotenv.parsed.USE_PASSWORD_ENCRYPTION;
CONFIG.databaseType = dotenv.parsed.DB_TYPE;
CONFIG.upload_dir = dotenv.parsed.upload_dir;
CONFIG.payu_url = dotenv.parsed.payu_url;
CONFIG.surl = dotenv.parsed.surl;
CONFIG.furl = dotenv.parsed.furl;

module.exports = CONFIG;
