const dotenv = require('../lib/dotenv');
module.exports = {
  'local': {
    username: dotenv.parsed.DB_USERNAME,
    password: dotenv.parsed.DB_PASSWORD,
    database: dotenv.parsed.DB_DATABASE,
    host: dotenv.parsed.DB_HOST,
    port: dotenv.parsed.DB_PORT,
    dialect: 'mysql',
    migrationStorageTableName: 'sequelize_meta'
  },
  'development': {
    username: dotenv.parsed.DB_USERNAME,
    password: dotenv.parsed.DB_PASSWORD,
    database: dotenv.parsed.DB_DATABASE,
    host: dotenv.parsed.DB_HOST,
    port: dotenv.parsed.DB_PORT,
    dialect: 'mysql',
    migrationStorageTableName: 'sequelize_meta'
  },
  'test': {
    username: dotenv.parsed.DB_USERNAME,
    password: dotenv.parsed.DB_PASSWORD,
    database: dotenv.parsed.DB_DATABASE,
    host: dotenv.parsed.DB_HOST,
    port: dotenv.parsed.DB_PORT,
    dialect: 'mysql',
    migrationStorageTableName: 'sequelize_meta'
  },
  'production': {
    username: dotenv.parsed.DB_USERNAME,
    password: dotenv.parsed.DB_PASSWORD,
    database: dotenv.parsed.DB_DATABASE,
    host: dotenv.parsed.DB_HOST,
    port: dotenv.parsed.DB_PORT,
    dialect: 'mysql',
    migrationStorageTableName: 'sequelize_meta'
  },
  'database1': {
    username: dotenv.parsed.DB_USERNAME,
    password: dotenv.parsed.DB_PASSWORD,
    database: dotenv.parsed.DATABASE1,
    host: dotenv.parsed.DB_HOST,
    port: dotenv.parsed.DB_PORT,
    dialect: 'mysql',
    migrationStorageTableName: 'sequelize_meta',
    insecureAuth: true
  },

};
