# value Harvest

API Code Base
to Run 
npm run dev
run migration
npx sequelize-cli db:migrate

## Prerequisite 
Install Node version v11.13.0<br>

In the project directory, you can run:

### `npm run dev` or 
### `yarn dev`

### `npx sequelize-cli db:migrate`
Runs the app in the development mode.<br>
in [http://localhost:8003](http://localhost:8000).