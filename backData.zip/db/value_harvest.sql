-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2021 at 02:07 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `value_harvest`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `lat` varchar(255) DEFAULT NULL,
  `lng` varchar(255) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1 COMMENT '1=>active,0=>deactive',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `type`, `address1`, `address2`, `city`, `district`, `state`, `country`, `zip`, `lat`, `lng`, `userId`, `status`, `createdAt`, `updatedAt`, `createdBy`, `updatedBy`) VALUES
(4, 'residential', 'address', NULL, 'aph', 'SGNR', 'RJ', 'In', '335701', '', '', 20, 1, '2021-03-17 09:06:02', '2021-03-17 09:06:02', NULL, NULL),
(5, 'residential', 'address', NULL, 'aph', 'SGNR', 'RJ', 'In', '335701', '', '', 23, 1, '2021-03-18 10:18:21', '2021-03-18 10:18:21', NULL, NULL),
(6, 'bussiness', NULL, NULL, 'aph', 'SGNR', 'RJ', 'In', '335701', '', '', 23, 1, '2021-03-18 10:18:21', '2021-03-18 10:18:21', NULL, NULL),
(7, 'residential', 'address', NULL, 'aph', 'SGNR', 'RJ', 'In', '335701', '', '', 25, 1, '2021-03-18 10:23:54', '2021-03-18 10:23:54', NULL, NULL),
(8, 'bussiness', NULL, NULL, 'aph', 'SGNR', 'RJ', 'In', '335701', '', '', 25, 1, '2021-03-18 10:23:54', '2021-03-18 10:23:54', NULL, NULL),
(9, 'residential', 'address', NULL, 'aph', 'SGNR', 'RJ', 'In', '335701', '', '', 27, 1, '2021-03-18 10:26:11', '2021-03-18 10:26:11', NULL, NULL),
(10, 'bussiness', NULL, NULL, 'aph', 'SGNR', 'RJ', 'In', '335701', '', '', 27, 1, '2021-03-18 10:26:11', '2021-03-18 10:26:11', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `commodity`
--

CREATE TABLE `commodity` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `other` varchar(255) DEFAULT NULL,
  `max_price` float DEFAULT NULL,
  `min_price` float DEFAULT NULL,
  `nodal_price` float DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT 1 COMMENT '1=>active,0=>deactive',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `commodity`
--

INSERT INTO `commodity` (`id`, `name`, `description`, `other`, `max_price`, `min_price`, `nodal_price`, `type`, `status`, `createdAt`, `updatedAt`, `createdBy`, `updatedBy`) VALUES
(1, 'Bajra', 'Black indian chana', '', 2, 2, 2, 'Perishable', 1, '2021-03-17 08:40:35', '2021-03-17 08:40:35', 1, 1),
(2, 'Chana', 'indian chana brown', '', 2, 2, 2, 'Perishable', 1, '2021-03-17 08:40:35', '2021-03-17 08:40:35', 1, 1),
(3, 'Baley', 'indian Baley brown', '', 2, 2, 2, 'Perishable', 1, '2021-03-17 08:40:35', '2021-03-17 08:40:35', 1, 1),
(4, 'Wheat', 'indian Wheat brown', '', 2, 2, 2, 'Perishable', 1, '2021-03-17 08:40:35', '2021-03-17 08:40:35', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `configurations`
--

CREATE TABLE `configurations` (
  `id` int(11) NOT NULL,
  `configurationName` varchar(255) DEFAULT NULL,
  `value` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `countryName` varchar(255) DEFAULT NULL,
  `countryCode` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `entity_commodity`
--

CREATE TABLE `entity_commodity` (
  `id` int(11) NOT NULL,
  `commodityTypeable` varchar(255) DEFAULT NULL,
  `commodityId` int(11) DEFAULT NULL,
  `commodityTypeableId` int(11) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `entity_commodity`
--

INSERT INTO `entity_commodity` (`id`, `commodityTypeable`, `commodityId`, `commodityTypeableId`, `createdBy`, `updatedBy`, `createdAt`, `updatedAt`) VALUES
(22, 'user', 1, 1, NULL, NULL, '2021-03-17 11:09:29', '2021-03-17 11:09:29'),
(23, 'user', 2, 1, NULL, NULL, '2021-03-17 11:09:29', '2021-03-17 11:09:29'),
(24, 'user', 3, 1, NULL, NULL, '2021-03-17 11:09:29', '2021-03-17 11:09:29'),
(25, 'user', 1, 23, NULL, NULL, '2021-03-18 10:18:21', '2021-03-18 10:18:21'),
(26, 'user', 2, 23, NULL, NULL, '2021-03-18 10:18:21', '2021-03-18 10:18:21'),
(27, 'user', 3, 23, NULL, NULL, '2021-03-18 10:18:21', '2021-03-18 10:18:21'),
(28, 'user', 1, 25, NULL, NULL, '2021-03-18 10:23:54', '2021-03-18 10:23:54'),
(29, 'user', 2, 25, NULL, NULL, '2021-03-18 10:23:54', '2021-03-18 10:23:54'),
(30, 'user', 3, 25, NULL, NULL, '2021-03-18 10:23:54', '2021-03-18 10:23:54'),
(31, 'user', 1, 27, NULL, NULL, '2021-03-18 10:26:11', '2021-03-18 10:26:11'),
(32, 'user', 2, 27, NULL, NULL, '2021-03-18 10:26:11', '2021-03-18 10:26:11'),
(33, 'user', 3, 27, NULL, NULL, '2021-03-18 10:26:11', '2021-03-18 10:26:11');

-- --------------------------------------------------------

--
-- Table structure for table `entity_files`
--

CREATE TABLE `entity_files` (
  `id` int(11) NOT NULL,
  `fileable` varchar(255) DEFAULT NULL,
  `fileableId` int(11) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `fileId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `entity_files`
--

INSERT INTO `entity_files` (`id`, `fileable`, `fileableId`, `createdBy`, `updatedBy`, `status`, `createdAt`, `updatedAt`, `fileId`) VALUES
(1, 'aadhar', 1, 1, 1, 1, '2021-03-18 10:03:16', '2021-03-18 10:03:16', 1),
(2, 'identity', 2, 23, 23, 1, '2021-03-18 10:18:21', '2021-03-18 10:18:21', 2),
(3, 'identity', 3, 23, 23, 1, '2021-03-18 10:18:21', '2021-03-18 10:18:21', 3),
(4, 'identity', 4, 23, 23, 1, '2021-03-18 10:18:21', '2021-03-18 10:18:21', 4),
(5, 'identity', 8, 27, 27, 1, '2021-03-18 10:26:11', '2021-03-18 10:26:11', 5),
(6, 'identity', 9, 27, 27, 1, '2021-03-18 10:26:11', '2021-03-18 10:26:11', 6),
(7, 'identity', 10, 27, 27, 1, '2021-03-18 10:26:11', '2021-03-18 10:26:11', 7);

-- --------------------------------------------------------

--
-- Table structure for table `entity_identity`
--

CREATE TABLE `entity_identity` (
  `id` int(11) NOT NULL,
  `identityTypeable` varchar(255) DEFAULT NULL,
  `identityId` int(11) DEFAULT NULL,
  `identityTypeableId` int(11) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `fileName` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT 1 COMMENT '0=>Deactive, 1=> Active',
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `title`, `fileName`, `status`, `createdBy`, `updatedBy`, `createdAt`, `updatedAt`) VALUES
(1, '43769-861x484.jpg', 'uploads/1-1616061796068-43769-861x484.jpg', 1, 1, 1, '2021-03-18 10:03:16', '2021-03-18 10:03:16'),
(2, '43769-861x484.jpg', 'uploads/23-1616062701745-43769-861x484.jpg', 1, 23, 23, '2021-03-18 10:18:21', '2021-03-18 10:18:21'),
(3, '43769-861x484.jpg', 'uploads/23-1616062701748-43769-861x484.jpg', 1, 23, 23, '2021-03-18 10:18:21', '2021-03-18 10:18:21'),
(4, '43769-861x484.jpg', 'uploads/23-1616062701753-43769-861x484.jpg', 1, 23, 23, '2021-03-18 10:18:21', '2021-03-18 10:18:21'),
(5, '43769-861x484.jpg', 'uploads/27-1616063171270-43769-861x484.jpg', 1, 27, 27, '2021-03-18 10:26:11', '2021-03-18 10:26:11'),
(6, '43769-861x484.jpg', 'uploads/27-1616063171271-43769-861x484.jpg', 1, 27, 27, '2021-03-18 10:26:11', '2021-03-18 10:26:11'),
(7, '43769-861x484.jpg', 'uploads/27-1616063171279-43769-861x484.jpg', 1, 27, 27, '2021-03-18 10:26:11', '2021-03-18 10:26:11');

-- --------------------------------------------------------

--
-- Table structure for table `identity`
--

CREATE TABLE `identity` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT 1 COMMENT '0=>Deactive, 1=> Active',
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `identity`
--

INSERT INTO `identity` (`id`, `title`, `number`, `description`, `status`, `createdBy`, `updatedBy`, `createdAt`, `updatedAt`, `userId`) VALUES
(1, 'aadhar', '123456789012', NULL, 1, NULL, NULL, '2021-03-17 12:07:17', '2021-03-17 12:07:17', 1),
(2, 'aadhar', '123456789012', NULL, 1, NULL, NULL, '2021-03-18 10:18:21', '2021-03-18 10:18:21', 23),
(3, 'gstin', '123456789012', NULL, 1, NULL, NULL, '2021-03-18 10:18:21', '2021-03-18 10:18:21', 23),
(4, 'pan', '1234567890', NULL, 1, NULL, NULL, '2021-03-18 10:18:21', '2021-03-18 10:18:21', 23),
(5, 'aadhar', '123456789012', NULL, 1, NULL, NULL, '2021-03-18 10:23:54', '2021-03-18 10:23:54', 25),
(6, 'pan', '1234567890', NULL, 1, NULL, NULL, '2021-03-18 10:23:54', '2021-03-18 10:23:54', 25),
(7, 'gstin', '123456789012', NULL, 1, NULL, NULL, '2021-03-18 10:23:54', '2021-03-18 10:23:54', 25),
(8, 'aadhar', '123456789012', NULL, 1, NULL, NULL, '2021-03-18 10:26:11', '2021-03-18 10:26:11', 27),
(9, 'pan', '1234567890', NULL, 1, NULL, NULL, '2021-03-18 10:26:11', '2021-03-18 10:26:11', 27),
(10, 'gstin', '123456789012', NULL, 1, NULL, NULL, '2021-03-18 10:26:11', '2021-03-18 10:26:11', 27);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `entity` varchar(255) DEFAULT NULL,
  `entityStage` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sequelize_meta`
--

CREATE TABLE `sequelize_meta` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sequelize_meta`
--

INSERT INTO `sequelize_meta` (`name`) VALUES
('20190704053614-create-user-roles.js'),
('20190704053903-create-users.js'),
('20190704072904-create-countries.js'),
('20190704074116-create-configurations.js'),
('20190705094202-create-files.js'),
('20190709054606-create-entity-files.js'),
('20190709054632-add-foreign_key_to_entity_files_table.js'),
('20190912061827-create-notification.js'),
('20190912062315-create-user-notification.js'),
('20190924101431-create_table_user_sockets.js'),
('20200227114121-add_last_activity_time.js'),
('20200308031419-add_notification_task_count_in_user_table.js'),
('20200308033033-add_task_count_in_user_table.js'),
('20210317050053-commodity.js'),
('20210317050054-entitycommodity.js'),
('20210317050836-address.js'),
('20210317064809-identity.js'),
('20210317065041-entityidentity.js'),
('20210317111538-add-userid-in-identity-table.js');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile` bigint(20) DEFAULT NULL,
  `otp` bigint(20) DEFAULT NULL,
  `dob` datetime DEFAULT NULL,
  `userRoleId` int(11) DEFAULT 1,
  `status` int(11) DEFAULT 1 COMMENT '1=>approved,0=>deactive,2=>rejected,3=>pending',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `last_activity_time` datetime DEFAULT NULL,
  `notification` int(11) DEFAULT 0,
  `task` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `userName`, `first_name`, `last_name`, `email`, `password`, `mobile`, `otp`, `dob`, `userRoleId`, `status`, `createdAt`, `updatedAt`, `last_activity_time`, `notification`, `task`) VALUES
(1, 'admin', 'Admin', 'dev', 'admin@vh.com', '$2b$10$0p9oCufNuvpqgn0UxZLifeJoASd1yh1nybVqfUBKr/GOijlktP84.', 0, NULL, NULL, 1, 1, '2021-03-17 08:40:42', '2021-03-17 08:40:42', NULL, 0, 0),
(20, 'userName', 'first_name', 'last_name', 'email1@mail.com', '$2b$10$ba4beib3kFfFv4biDDoH0uwZCoYPKLNQwe3e1RQire.MZzC95b3pS', 9988974274, NULL, '1991-11-11 18:30:00', 2, 3, '2021-03-17 09:06:02', '2021-03-17 09:06:02', NULL, 0, 0),
(23, 'userName', 'first_name', 'last_name', 'email2@mail.com', '$2b$10$ZS/amP/u09rHvxapBbZIyOS6N0e/1dNFDCiHwfhhsINx5NfyO54Va', 9988974275, NULL, '1991-11-11 18:30:00', 3, 3, '2021-03-18 10:18:21', '2021-03-18 10:18:21', NULL, 0, 0),
(25, 'userName', 'first_name', 'last_name', 'email3@mail.com', '$2b$10$l5arzXFRjAhGrOIU.fOO1.Uifj0mxtrFs2eOeFcUFK.bn8oXnPQRe', 9988974276, NULL, '1991-11-11 18:30:00', 3, 3, '2021-03-18 10:23:53', '2021-03-18 10:23:53', NULL, 0, 0),
(27, 'userName', 'first_name', 'last_name', 'email4@mail.com', '$2b$10$TUdnyAFcCNaL0CWXEJDEV./oT3LM3yok7OAblHPfbvfo6NwPLXcw6', 9988974277, NULL, '1991-11-11 18:30:00', 3, 3, '2021-03-18 10:26:11', '2021-03-18 10:26:11', NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `id` int(11) NOT NULL,
  `fromUserId` int(11) DEFAULT NULL,
  `toUserId` int(11) DEFAULT NULL,
  `entityId` varchar(255) DEFAULT NULL,
  `notificationId` int(11) DEFAULT NULL,
  `isRead` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `id` int(11) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `role`, `status`, `createdAt`, `updatedAt`, `createdBy`, `updatedBy`) VALUES
(1, 'admin', 1, '2021-03-17 08:41:49', '2021-03-17 08:41:49', 1, 1),
(2, 'buyer', 1, '2021-03-17 08:41:49', '2021-03-17 08:41:49', 1, 1),
(3, 'seller', 1, '2021-03-17 08:41:49', '2021-03-17 08:41:49', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_sockets`
--

CREATE TABLE `user_sockets` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `socketId` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `commodity`
--
ALTER TABLE `commodity`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `configurations`
--
ALTER TABLE `configurations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entity_commodity`
--
ALTER TABLE `entity_commodity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commodityId` (`commodityId`);

--
-- Indexes for table `entity_files`
--
ALTER TABLE `entity_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entity_files_fileId_foreign_idx` (`fileId`);

--
-- Indexes for table `entity_identity`
--
ALTER TABLE `entity_identity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `identityId` (`identityId`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `identity`
--
ALTER TABLE `identity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `identity_userId_foreign_idx` (`userId`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sequelize_meta`
--
ALTER TABLE `sequelize_meta`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sockets`
--
ALTER TABLE `user_sockets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `commodity`
--
ALTER TABLE `commodity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `configurations`
--
ALTER TABLE `configurations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `entity_commodity`
--
ALTER TABLE `entity_commodity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `entity_files`
--
ALTER TABLE `entity_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `entity_identity`
--
ALTER TABLE `entity_identity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `identity`
--
ALTER TABLE `identity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_sockets`
--
ALTER TABLE `user_sockets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);

--
-- Constraints for table `entity_commodity`
--
ALTER TABLE `entity_commodity`
  ADD CONSTRAINT `entity_commodity_ibfk_1` FOREIGN KEY (`commodityId`) REFERENCES `commodity` (`id`);

--
-- Constraints for table `entity_files`
--
ALTER TABLE `entity_files`
  ADD CONSTRAINT `entity_files_fileId_foreign_idx` FOREIGN KEY (`fileId`) REFERENCES `files` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `entity_identity`
--
ALTER TABLE `entity_identity`
  ADD CONSTRAINT `entity_identity_ibfk_1` FOREIGN KEY (`identityId`) REFERENCES `identity` (`id`);

--
-- Constraints for table `identity`
--
ALTER TABLE `identity`
  ADD CONSTRAINT `identity_userId_foreign_idx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
