const iState = {
  name: '',
  webTest : ['test', 'test2']

}

/*
const iState = {
  name: 'testVal',
  webTest : ['test', 'test2']

}

 const reducer = (state = iState, action) => {
	
	if(action.type == "changeName"){
		return {
			...state,
		 name: action.payload
		}
		
	}
	return state;
} 

export default reducer */
const changeName = 'changeName';
const user_data = 'user_data';
 const reducer = (state = iState, action) => {
	 if(action.type === "changeName"){
		 return {
			 ...state,
			 name:action.payload
		 }
		 
	 }
	  else if(action.type === "user_data"){
		 	 return {
			 ...state,
			 name:action.payload
		 }
	 } 
	
return state;
}

export default reducer