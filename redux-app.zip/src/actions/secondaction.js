export const secondactions = () =>{
//console.log(id);
	return(dispatch) => {
		
		fetch('https://jsonplaceholder.typicode.com/users/1')
		.then(res => res.json())
		.then(res2=>{
			dispatch({type:'user_data',payload: res2 })
		})
	
	
	} 

}