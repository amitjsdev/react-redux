export const anotherData = () =>{

	return(dispatch) => {
		console.log(dispatch);
		fetch('https://jsonplaceholder.typicode.com/users')
		.then(res => res.json())
		.then(res2=>{
			dispatch({type:'changeName',payload: res2 })
		})
	
	
	} 

}