import React,{Component} from 'react';

import {
  BrowserRouter as Router,
  Redirect,
  Switch,
  Route,
} from 'react-router-dom';

import App from '../components/App';
import AppChild from '../components/AppChild';

class Routers extends Component{
	
	render() {
		return (
		 <Router>
		 <div>
		 <Switch>
			<Route exact path="/" component={App}/>
			<Route exact path='/child/:id' component={AppChild}/>
			</Switch>
		 </div>
		 </Router>
		)
	}
	
}
export default Routers;