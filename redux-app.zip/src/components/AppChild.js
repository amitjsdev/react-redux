import React, { useState } from 'react';
import './App.css';
import {connect} from 'react-redux';
import {secondactions} from '../actions/secondaction';
function AppChild(props) {
	const id = props.location.state;
	var userlist = [];
	var userlist = props.myname ? props.myname : [];	
	console.log(props.myname.length);
	console.log(props.myname);
	
  return (
    <div className="App">
      <h1>display App Child</h1>
	  <button onClick={()=>{props.use_data()}}>Click</button>
	  	  <ul>
		  <li> {userlist.name} </li>
	  </ul>
    </div>
  );
}

const mapStateToProps = (state) => {
	return {
		myname: state.name
	}
}

const mipDispatchToProps = (dispatch) => {
	return {
		use_data:() => {dispatch(secondactions())}
	}
}



export default connect(mapStateToProps,mipDispatchToProps)(AppChild);
