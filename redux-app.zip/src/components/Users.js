import React, { useState,useEffect } from 'react';

const Users = (props) => {
	const [hasError, setErrors] = useState(false);
	const [users,setUsers] = useState({});
	//console.log(props.location.state)
	var id = props.location.state;
	
	
	useEffect(()=>{
		console.log(props.location.state)
	   fetch('https://jsonplaceholder.typicode.com/users/'+props.location.state)
			.then(res => res.json())
			.then(res => setUsers({ users: res }))
			.catch(() => setErrors({ hasErrors: true }))

	  },[id]);

  
 
	//const resData = return
	return(
		
	<div>
	{JSON.stringify(users)}
	
	</div>
	
	);
}
export default Users;