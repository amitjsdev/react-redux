import React from 'react';
import './App.css';
import {connect} from 'react-redux';
import {anotherData} from '../actions/myaction';
/* import {
  BrowserRouter as Router,
  Redirect,
  Switch,
  Route,
  Link,
  withRouter,
} from 'react-router-dom'; */
import { useHistory } from "react-router-dom"; 
function App(props) {
	const history = useHistory();
	//console.log(props.myname.length);
	//console.log(props.myname);
	//console.log(props.myname);
	var userlist = props.myname.length > 0 ? props.myname : [];	
	//console.log(userlist);
	const handleDataClick = (e) => {
		console.log(e.id);
		history.push({
			pathname:'/child/'+e.id,
			state: e.id
		});
	}
  return (
    <div className="App">
      <h1>display first list</h1>
	  <button onClick={()=>{props.changeName()}}>Click</button>
	  	  <ul>
	  { 
	  
	  userlist.map((user,i)=>{
		  return (<li onClick={e => handleDataClick(user)} key={i}> {user.name} </li>)
		  
	  })
	  }
	  </ul>
	  
    </div>
  );
}

const mapStateToProps = (state) =>{
  return {
	  myname: state.name
  }
}

 const mapDispatchToProps = (dispatch) => {
		return {
			changeName: ()=> {dispatch(anotherData())}
		}
}

export default connect(mapStateToProps,mapDispatchToProps)(App);
