import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { BrowserRouter as Router, Redirect, Route, Switch } from "react-router-dom";
import './App.less';
import './assets/css/bootstrap.min.css';
import './assets/css/style.css';
import  AuthenticatedApp  from './components/AuthenticatedApp/AuthenticatedApp';
import Login from './components/pages/auth/Login';
import { history } from './config/helper';
import axios from 'axios'
import { connect } from 'react-redux'
import { getMasterData } from './components/AuthenticatedApp/store/Actions'
import { LoginData } from './components/AuthenticatedApp/store/redux/auth/Actions'

class App extends React.Component {
  componentDidMount() {
    let token = localStorage.getItem('vhtoken');
    if (token) {
      const data = localStorage.getItem('userDetail');
      this.props.LoginData(JSON.parse(data))
    }
    axios.interceptors.request.use(
      req => {
        if (token) {
          return { ...req, headers: { Authorization: `Bearer ${token}`, withCredentials: true } };
        }
        return req;
      }
    );
    this.props.getMasterData()

  };
  render() {
    const {authenticated} =this.props
    return (
      <Router history={history}>
        <Switch>
          {
            authenticated ? <AuthenticatedApp path="/" /> :
              <Route path="/" component={Login} />
          }



          {/* <Route path="/item-list" component={ItemList} /> */}
          <Redirect from="*" to="/" />
        </Switch>
      </Router>
    )
  }
}
const mapStateToProps = state => ({
  authenticated: state.auth.authenticated
});

const mapDispatchToProps = dispatch => ({
  getMasterData: () => dispatch(getMasterData()),
  LoginData: (payload) => dispatch(LoginData(payload)),
});
 
    export default connect(
        mapStateToProps,
        mapDispatchToProps
    )(App);
  
