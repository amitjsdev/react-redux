import React, { useEffect, useState } from 'react';
import DashboardLayout from "../../Layout/DashboardLayout";
import { useDispatch, useSelector } from 'react-redux';
import { getUserList } from '../../AuthenticatedApp/store/redux/users/Actions';
import moment from 'moment';
import { Link, useLocation } from 'react-router-dom';
import { message, Select } from 'antd';
import { Table, Space, DatePicker } from 'antd';
import 'antd/dist/antd.css';
const { RangePicker } = DatePicker;
const { Option } = Select;
const UserManagement = () => {
    let searchRole =localStorage.getItem('searchRole')
    searchRole =searchRole ? JSON.parse(searchRole): []
    let searchStatus =localStorage.getItem('searchStatus')
    searchStatus =searchStatus ? JSON.parse(searchStatus): []
    let searchDate =localStorage.getItem('searchDate')
    searchDate =searchDate ? JSON.parse(searchDate): [null,null]
    const [range, setRange] = useState(searchDate)
    const [selectedStatus, selectStatus] = useState(searchStatus)
    const [selectedRole, selectRole] = useState(searchRole)

    const dispatch = useDispatch();

    function reset() {
        selectRole([]);
        selectStatus([])
        setRange([null, null])
        localStorage.setItem('searchRole',JSON.stringify([]))
        localStorage.setItem('searchStatus',JSON.stringify([]))
        localStorage.setItem('searchDate',JSON.stringify([null,null]))
        dispatch(getUserList({
            roles: [],
            status: [],
        }));
    }
   let roles = useSelector(state => state.app.data.roles);
    roles = roles && roles.length > 0 ? roles.filter(a => a.role != 'admin') : []
    const doSearchHandler = (e) => {
        e.preventDefault()
        doSearch(0)
    }
    const doSearch = () => {

        let searchParams = {
            status: selectedStatus, roles: selectedRole,
            limit: 100000000, offset: 0
        }
        if (range && range[0] && range[1]) {
            searchParams = { ...searchParams, fromDate: range[0], toDate: range[1] }
        }
       
        localStorage.setItem('searchRole',JSON.stringify(selectedRole))
        localStorage.setItem('searchStatus',JSON.stringify(selectedStatus))
        localStorage.setItem('searchDate',JSON.stringify(range))
        dispatch(getUserList(searchParams));
    }
    const columns = [
        {
            title: 'ID',
            dataIndex: 'id',
            key: 'id',
            render: text => <a>{text}</a>,
        },
        {
            title: 'User Type',
            dataIndex: ['UserRole', 'role'],
            key: 'userName',
            render: text => <a>{text}</a>,
        },
        {
            title: 'First Name',
            dataIndex: 'first_name',
            key: 'first_name',
        },
        {
            title: 'Last Name',
            dataIndex: 'last_name',
            key: 'last',
        },
        {
            title: 'Mobile Number',
            dataIndex: 'mobile',
            key: 'mobile',
        },
        {
            title: 'City',
            dataIndex: ['bAddress', 'cityName'],
            key: 'cityName',
            render: (item) => {
                return item ? item : 'N/A';
            }
        },
        {
            title: 'Country',
            dataIndex: ['bAddress', 'countryName'],
            key: 'countryName',
            render: (item) => {
                return item ? item : 'N/A';
            }
        },
        {
            title: 'Created Date',
            dataIndex: 'createdAt',
            key: 'createdAt',
            render: (item) => {
                return moment(item).format(
                    "MMM DD, YYYY h:mm:ss"
                )

            }
        },

        {
            title: 'Status',
            key: 'statusStr',
            dataIndex: 'statusStr',
            render: (statusStr) =>

            (
                <>
                    <span className={`${statusStr.toLowerCase()} status`}  >{statusStr}</span>

                </>
            ),
        },
        {
            title: 'Action',
            key: 'action',
            dataIndex:'id',
            render: (id) =>

            (
                <ul class="list">
                    
                    <li><Link to={`/view-user-management/${id}`} title="View" ><i class="fa fa-eye"></i></Link></li>
                </ul>
            ),
        },
    ];

    useEffect(()=>{
        doSearch()
    },[])
    
    let users = useSelector(state => state.user && state.user.userlist ? state.user.userlist.data : null);
    users = users && users.rows ? users.rows :[]
    return (
        <DashboardLayout>
            <div>
                <div className="page-inner">
                    <div className="container-fluid">
                        <form name="form" >
                            <div className="row">
                                <div className="col-lg-12 card pt-3 pb-3 mb-3">
                                    <div className="font-weight-bold pb-2">Search By:</div>
                                    <div className="form-row">
                                        <div class="col-md-4 mb-3">
                                            <label className="col-md-12" for="validationDefault01">From Date - To Date</label>
                                            <Space direction="vertical" size={12}>
                                                <RangePicker format="DD/MM/YYYY"
                                                    value={range}
                                                    placeholder={['From Date', 'To Date']}
                                                    onChange={setRange}
                                                />
                                            </Space>
                                        </div>


                                        <div className="col-md-4 mb-3">
                                            <label for="validationDefaultUsername">User Type</label>
                                            <div class="input-group">
                                                <Select
                                                    mode="multiple"
                                                    allowClear
                                                    style={{ width: '100%' }}
                                                    placeholder="Please select"
                                                    value={selectedRole}
                                                    onChange={selectRole}

                                                >

                                                    {roles && roles.length > 0 ? roles.map(c =>
                                                        <option key={c.id} value={c.id}>{c.role}</option>
                                                    ) : null}
                                                </Select>

                                            </div>

                                        </div>
                                        <div className="col-md-4 mb-3">
                                            <label for="validationDefaultUsername">Status</label>
                                            <div class="input-group">
                                                <Select
                                                    mode="multiple"
                                                    allowClear
                                                    style={{ width: '100%' }}
                                                    placeholder="Please select"
                                                    value={selectedStatus}
                                                    onChange={selectStatus}

                                                >
                                                    <option value={1}>Approved</option>
                                                    <option value={2}>Rejected</option>

                                                </Select>
                                            </div>
                                        </div>
                                        <div className="col-md-4 mb-3">
                                            <button className="btn btn-green btn-top mr-3" onClick={doSearchHandler}>Search</button>
                                            <button className="btn btn-green btn-top" type="reset" onClick={reset}>Clear</button>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </form>
                    </div>
                    <div className="container-fluid pl-0 pr-0">
                        <div className="row">
                            <div className="col-lg-12">
                                <div className="card pb-0 mb-0">
                                    <div className="card-body pb-2">
                                        <div className="table-responsive">
                                            <Table
                                                className="table"
                                                columns={columns}
                                                pagination={{ pageSize: 5 }}
                                                dataSource={users}
                                            />


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </DashboardLayout >

    )
}

export default UserManagement

