import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import DashboardLayout from "../../Layout/DashboardLayout";
import DataTable from '../../common/DataTable';
import { Tabs, Pagination } from 'antd';
import { Spin, Space } from 'antd';
import { useDispatch, useSelector } from 'react-redux';
import { getUserDetail, getUserTrades } from '../../AuthenticatedApp/store/redux/users/Actions';
import { Link, useHistory } from "react-router-dom";
import moment from 'moment';
import { API_BASE_URL_LIVE } from "../../../config/constants";
import Image from '../../common/Image'
const { TabPane } = Tabs;


const ViewUserManagement = () => {


    const history = useHistory();
    const [offset, setOffSet] = useState(0);
    const [limit, setLimit] = useState(10)
    const [currentPage, setCurrentPage] = useState(1)
    const usersDetails = useSelector(state => state.user.data);
    const usersTrades = useSelector(state => state.user.dataTrades);
    let value = usersTrades?.data.count / 10;
    // let countVal;
    // if(value > 1){
    //     countVal = 1;
    // }else{
    //   let newVal =  value.split('.')
    //     countVal = newVal[1]
    // }
    const params = useParams();
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(getUserDetail(params));
        dispatch(getUserTrades(params, { offset: 0, limit: 10 }));
    }, []);

    //go back function
    const PreviousPage = (e) => {
        let from_date = localStorage.getItem('from_date');
        let to_date = localStorage.getItem('to_date');
        let roles = localStorage.getItem('roles');
        let status = localStorage.getItem('status');
        if (from_date == '' && to_date == '' && roles === '' && status == '') {
            history.push({
                pathname: `/user-management`
            });
        } else {
            history.push({
                pathname: `/user-management`,
                search: `detailPage=${e}`
            });
        }
    }


    const onChangePagination = (page) => {
        setOffSet((page - 1) * 10)
        setCurrentPage(page)
        let currentVal = (page - 1) * 10;
        const payload = ({ offset: currentVal, limit });
        dispatch(getUserTrades(params, payload));
    };

    const getUpdatedQuote = () => {
        setCurrentPage(1)
        dispatch(getUserTrades(params, { offset: 0, limit: 10 }));
    }

    const theadApproveHistory = ["ID", "Modified By", "Current Status", "Comments", "Modified Date"];

    const thead = ["Trade Request ID", "Commodity", "Title", "Qty", "Create Date", "Total No. of Quotes", "Low Quote Value", "High Quote Value", "Broadcast Date", "Status", "Action"];
    return (
        <div>
            <DashboardLayout>
                <div className="page-inner pt-2">
                    <div className="container-fluid pl-0 pr-0">
                        <div className="detail-panel" style={{ overflow: 'hidden' }}>
                            <div className="row card-gutter ml-0 mr-0">

                                <div className="headTitle pt-3"><h2 className="screenName">User Management Details</h2></div>
                                <div className="backBtnDiv"><button onClick={() => { PreviousPage(usersDetails?.id) }} className="backBtn">Go Back</button></div>

                                <ul className="actionList">
                                    <li><h3 className="h3">ID: <span>{usersDetails?.id}</span></h3></li>
                                    {/* <li><a href="javascript:void(0);" title="Edit"><i className="fa fa-edit" ></i>Edit</a></li>
                                    <li><a href="javascript:void(0);" title="Save"><i className="fa fa-save" ></i>Save</a></li> */}
                                    <li className="last">Created Date: <br />
                                        <span className="titleName">{moment(usersDetails?.createdAt).format("MMM DD,YYYY h:mm:ss")}</span>
                                    </li>
                                </ul>
                            </div>
                            <div className="card-gutter ml-0 mr-0">
                                {usersDetails && !!usersDetails?.UserRole &&
                                    <div className="col-lg-12">

                                        <Tabs defaultActiveKey="1" className="tab-content">
                                            <TabPane tab="User Detail" key="1" className="nav nav-tabs">
                                                <div className="tab-content">
                                                    <div role="tabpanel" className="tab-pane active" id="tab1">
                                                        <form>
                                                            <fieldset className="scheduler-border">
                                                                <legend className="scheduler-border">Personal Information</legend>
                                                                <div className="form-row">
                                                                    <div className="col-md-3 mb-2">
                                                                        <label>First Name</label>
                                                                        <input type="text" value={usersDetails?.first_name} className="form-control" placeholder="Deepak" disabled />
                                                                    </div>
                                                                    <div className="col-md-3 mb-2">
                                                                        <label>Last Name</label>
                                                                        <input type="text" value={usersDetails?.last_name} className="form-control" placeholder="Singn" disabled />
                                                                    </div>
                                                                    <div className="col-md-3 mb-2">
                                                                        <label>Email ID</label>
                                                                        <div className="input-group">
                                                                            <input value={usersDetails?.email} type="text" className="form-control" placeholder="value_harvest@gmail.com" disabled />
                                                                        </div>
                                                                    </div>
                                                                    <div className="col-md-3 mb-2">
                                                                        <label>Mobile Number</label>
                                                                        <div className="input-group">
                                                                            <input value={usersDetails?.mobile} type="text" className="form-control" id="validationDefault01" placeholder="98754862" disabled />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </fieldset>
                                                            <fieldset className="scheduler-border">
                                                                <legend className="scheduler-border">Address Information</legend>
                                                                <div className="address-one">
                                                                    <div className="form-row">
                                                                        <div className="col-md-3 mb-2 mt-2">
                                                                            <label>Type of entity</label>
                                                                        </div>
                                                                        <div className="col-md-3 mb-2">
                                                                            <div className="input-group">
                                                                                <select className="form-control form-select" disabled>
                                                                                    <option selected>{usersDetails?.entityStr}</option>
                                                                                    {/* <option>Proprietor</option>
                                                                                <option>Company</option> */}
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div className="col-md-3 mb-2 mt-2 text-sm-center">
                                                                            <label>User Type</label>
                                                                        </div>
                                                                        <div className="col-md-3 mb-2">
                                                                            <div className="input-group">
                                                                                <select className="form-control form-select" disabled>
                                                                                    <option selected>{usersDetails?.UserRole?.role}</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                {usersDetails && usersDetails?.Addresses.length > 0 && usersDetails?.Addresses.map((item) => {
                                                                    if (item?.type == 'bussiness' || item?.type == 'residential') {
                                                                        return (

                                                                            <>
                                                                                <fieldset className="scheduler-border">
                                                                                    <legend className="scheduler-border">{item?.type == 'bussiness' ? 'Business Address' : 'Residential Address'}</legend>
                                                                                    <div className="address-container">

                                                                                        <div className="form-row">
                                                                                            <div className="col-md-4 mb-2">
                                                                                                <label>Address 1</label>
                                                                                                <input value={item?.address1} type="text" className="form-control" placeholder="N.No-246" disabled />
                                                                                            </div>
                                                                                            <div className="col-md-4 mb-2">
                                                                                                <label>Address 2</label>
                                                                                                <div className="input-group">
                                                                                                    <input value={item?.address2} type="text" className="form-control" placeholder="Nodia, Uttar Pradesh" disabled />
                                                                                                </div>
                                                                                            </div>
                                                                                            <div className="col-md-4 mb-2">
                                                                                                <label>City</label>
                                                                                                <div className="input-group">
                                                                                                    <input value={item?.cityName} type="text" className="form-control" placeholder="Nodia" disabled />

                                                                                                </div>
                                                                                            </div>
                                                                                            <div className="col-md-4 mb-2">
                                                                                                <label>State</label>
                                                                                                <div className="input-group">
                                                                                                    <select className="form-control form-select" disabled>
                                                                                                        <option selected>{item?.stateName}</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div className="col-md-4 mb-2">
                                                                                                <label >Zip Code</label>
                                                                                                <input type="text" value={item?.zip} className="form-control" placeholder="110065" disabled />
                                                                                            </div>
                                                                                            <div className="col-md-4 mb-2">
                                                                                                <label>Country</label>
                                                                                                <div className="input-group">
                                                                                                    <select className="form-control form-select" disabled>
                                                                                                        <option selected>{item?.countryName}</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </fieldset>
                                                                            </>
                                                                        );
                                                                    }
                                                                })
                                                                }


                                                            </fieldset>


                                                            <fieldset className="scheduler-border">
                                                                <legend className="scheduler-border">Identity Information</legend>
                                                                <div className="form-row">
                                                                    {usersDetails && usersDetails?.Identities.length > 0 && usersDetails?.Identities.map((item) => {
                                                                        return (
                                                                            <>
                                                                                {(item.title === 'pan') &&
                                                                                    <div className="col-md-3 mb-2">
                                                                                        <label>PAN Number</label>
                                                                                        <input value={item?.number} type="text" className="form-control" placeholder="ABCDE3210F" disabled />
                                                                                    </div>
                                                                                }
                                                                                {(item.title === 'aadhar') &&
                                                                                    <div className="col-md-3 mb-2">
                                                                                        <label>Aadhar Card Number</label>
                                                                                        <input value={item?.number} type="text" className="form-control" placeholder="2514 3214 6542" disabled />
                                                                                    </div>
                                                                                }
                                                                                {(item.title === 'gstin') &&
                                                                                    <div className="col-md-3 mb-2">
                                                                                        <label>GSTIN</label>
                                                                                        <div className="input-group">
                                                                                            <input value={item?.number} type="text" className="form-control" placeholder="AGH564875487457" disabled />
                                                                                        </div>
                                                                                    </div>
                                                                                }

                                                                                {(item.title === 'export') &&
                                                                                    <div className="col-md-3 mb-2">
                                                                                        <label>Export Code</label>
                                                                                        <div className="input-group">
                                                                                            <input value={item?.number} type="text" className="form-control" placeholder="564852" disabled />
                                                                                        </div>
                                                                                    </div>
                                                                                }

                                                                                {(item.title === 'import') &&
                                                                                    <div className="col-md-3 mb-2">
                                                                                        <label>Import Code</label>
                                                                                        <div className="input-group">
                                                                                            <input value={item?.number} type="text" className="form-control" placeholder="501245" disabled />
                                                                                        </div>
                                                                                    </div>
                                                                                }
                                                                            </>
                                                                        );
                                                                    })
                                                                    }
                                                                </div>
                                                                <div className="form-row-">
                                                                    <fieldset className="scheduler-border">
                                                                        <legend className="scheduler-border">KYC Documents [Attachements]</legend>
                                                                        <div className="address-container">
                                                                            <div className="form-row">
                                                                                {usersDetails && usersDetails?.Identities.length > 0 && usersDetails?.Identities.map((item) => {
                                                                                    if (!!item?.EntityFile) {
                                                                                        return (
                                                                                            <div className="col-md-4 mb-2">
                                                                                                <div className="row">
                                                                                                    <label>{item?.title.toUpperCase()}</label>

                                                                                                </div>
                                                                                                <div className="row">
                                                                                                    <label>{item?.number}</label>

                                                                                                </div>
                                                                                                <div className="row">
                                                                                                    <Image data={item && item.EntityFile ? item.EntityFile : null} height={100} width={100} />

                                                                                                </div>
                                                                                            </div>
                                                                                        );
                                                                                    }
                                                                                })
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    </fieldset>
                                                                </div>
                                                            </fieldset>


                                                            {usersDetails && usersDetails?.Addresses.length > 0 && usersDetails?.Addresses.map((item) => {
                                                                if (item?.type == 'geo') {
                                                                    return (

                                                                        <>
                                                                            <fieldset className="scheduler-border">
                                                                                <legend className="scheduler-border">Geo Location</legend>
                                                                                <div className="form-row">
                                                                                    <div className="col-md-3 mb-2">
                                                                                        <label >Latitude</label>
                                                                                        <input value={item?.lat} type="text" className="form-control" placeholder="45°N" disabled />
                                                                                    </div>
                                                                                    <div className="col-md-3 mb-2">
                                                                                        <label >Longitude</label>
                                                                                        <input value={item?.lng} type="text" className="form-control" placeholder="0°" disabled />
                                                                                    </div>
                                                                                    <div className="col-md-6 mb-2">
                                                                                        <label>Geo Location Address</label>
                                                                                        <div className="input-group">
                                                                                            <input value={item?.address1} type="text" className="form-control" placeholder="Geo location Address" disabled />
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </fieldset>
                                                                        </>
                                                                    );
                                                                }
                                                            })
                                                            }
                                                            <fieldset className="scheduler-border">
                                                                <legend className="scheduler-border">Commodity Details</legend>
                                                                <div className="form-row">
                                                                    {usersDetails && usersDetails?.EntityCommodities.length > 0 && usersDetails?.EntityCommodities.map((item) => {
                                                                        return (

                                                                            <div className="attach comunityData">
                                                                                {item?.Commodity?.name}

                                                                            </div>

                                                                        );
                                                                    })
                                                                    }
                                                                </div>
                                                            </fieldset>
                                                        </form>


                                                        <div className="container pl-0 pr-0">
                                                            <h2 className="display-h2 heading-bg">Approver History</h2>
                                                            <div className="dataTable-panel">
                                                                <div className="row ml-0 mr-0">
                                                                    <div className="table-responsive">

                                                                        {
                                                                            <DataTable
                                                                                thead={theadApproveHistory}>
                                                                                {
                                                                                    usersDetails && usersDetails?.history.length > 0 ?
                                                                                        usersDetails && usersDetails?.history.length > 0 && usersDetails?.history.map((item, i) => (
                                                                                            <tr key={i}>
                                                                                                <td>{item?.id}</td>
                                                                                                <td>{`${item?.CreatedUser?.first_name} ${item?.CreatedUser?.last_name}`}</td>
                                                                                                <td><span className={`status ${item?.newData.toLowerCase()}`}>{item?.newData}</span></td>
                                                                                                <td>{item?.comment}</td>

                                                                                                <td>{moment(item?.updatedAt).format("MMM DD,YYYY h:mm:ss")}</td>
                                                                                            </tr>
                                                                                        ))
                                                                                        :
                                                                                        <tr class="ant-table-placeholder"><td colspan="5" class="ant-table-cell"><div class="ant-empty ant-empty-normal"><div class="ant-empty-image"><svg class="ant-empty-img-simple" width="64" height="41" viewBox="0 0 64 41" xmlns="http://www.w3.org/2000/svg"><g transform="translate(0 1)" fill="none" fill-rule="evenodd"><ellipse class="ant-empty-img-simple-ellipse" cx="32" cy="33" rx="32" ry="7"></ellipse><g class="ant-empty-img-simple-g" fill-rule="nonzero"><path d="M55 12.76L44.854 1.258C44.367.474 43.656 0 42.907 0H21.093c-.749 0-1.46.474-1.947 1.257L9 12.761V22h46v-9.24z"></path><path d="M41.613 15.931c0-1.605.994-2.93 2.227-2.931H55v18.137C55 33.26 53.68 35 52.05 35h-40.1C10.32 35 9 33.259 9 31.137V13h11.16c1.233 0 2.227 1.323 2.227 2.928v.022c0 1.605 1.005 2.901 2.237 2.901h14.752c1.232 0 2.237-1.308 2.237-2.913v-.007z" class="ant-empty-img-simple-path"></path></g></g></svg></div><div class="ant-empty-description">No Data</div></div></td></tr>

                                                                                }
                                                                            </DataTable>


                                                                        }

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </TabPane>

                                            <TabPane tab="User Bank Detail" key="2">
                                                <div role="tabpanel" className="tab-pane" id="tab2">
                                                    <form style={{ padding: '0.8rem 1rem' }}>
                                                        <fieldset className="scheduler-border">
                                                            <legend className="scheduler-border">Bank Detail</legend>
                                                            <div className="address-container">
                                                                <div className="form-row">
                                                                    {(usersDetails && !!usersDetails?.Bank && Object.values(usersDetails?.Bank).length > 0) &&
                                                                        <>
                                                                            <div className="col-md-4 mb-2">
                                                                                <label>Account Holder Name</label>
                                                                                {/* {item?.name} */}
                                                                                <input value={usersDetails?.Bank?.holder_name} type="text" className="form-control" placeholder="Value Harvest" disabled />
                                                                            </div>
                                                                            <div className="col-md-4 mb-2">
                                                                                <label>Acount Number</label>
                                                                                <div className="input-group">
                                                                                    <input value={usersDetails?.Bank?.account_number} type="text" className="form-control" placeholder="000000001254" disabled />
                                                                                </div>
                                                                            </div>
                                                                            <div className="col-md-4 mb-2">
                                                                                <label>Bank Name</label>
                                                                                <div className="input-group">
                                                                                    <div className="input-group">
                                                                                        <input value={usersDetails?.Bank.bank} type="text" className="form-control" placeholder="HDFC Bank" disabled />
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div className="col-md-4 mb-2">
                                                                                <label>IFSC Code</label>
                                                                                <div className="input-group">
                                                                                    <input value={usersDetails?.Bank.ifsc} type="text" className="form-control" placeholder="ABC00002" disabled />
                                                                                </div>
                                                                            </div>

                                                                            {/* <div className="col-md-4 mb-2">
                                                                                    <label>Bank Address</label>
                                                                                    <div className="input-group">
                                                                                        <input value={usersDetails?.Bank?.bank_address} type="text" className="form-control" placeholder="Noida, Uttar Pradesh" disabled />
                                                                                    </div>
                                                                                </div> */}
                                                                            {/* <div className="col-md-4 mb-2">
                                                                                    <label >PAN Number</label>
                                                                                    <input value={usersDetails?.Bank?.bank_address} type="text" className="form-control" placeholder="BN110065" disabled />
                                                                                </div> */}
                                                                            {/* <div className="col-md-4 mb-2">
                                                                                    <label>Bank City</label>
                                                                                    <div className="input-group">
                                                                                        <input value={usersDetails?.Bank?.bank_city} type="text" className="form-control" placeholder="Noida" disabled />
                                                                                    </div>
                                                                                </div>
                                                                                <div className="col-md-4 mb-2">
                                                                                    <label>Bank Pincode/Zip Code</label>
                                                                                    <div className="input-group">
                                                                                        <input value={usersDetails?.Bank?.bank_zip} type="text" className="form-control" placeholder="110058" disabled />
                                                                                    </div>
                                                                                </div>
                                                                                <div className="col-md-4 mb-2">
                                                                                    <label>Bank Association</label>
                                                                                    <div className="input-group">
                                                                                        <input value={usersDetails?.Bank?.bank_asso} type="text" className="form-control" placeholder="----" disabled />
                                                                                    </div>
                                                                                </div> */}
                                                                            <div className="col-md-4 mb-2">
                                                                                <label>Swift Code</label>
                                                                                <div className="input-group">
                                                                                    <input value={usersDetails?.Bank?.swift} type="text" className="form-control" placeholder="101010" disabled />
                                                                                </div>
                                                                            </div>
                                                                        </>
                                                                    }
                                                                </div>
                                                            </div>
                                                        </fieldset>
                                                    </form>
                                                </div>
                                            </TabPane>

                                            <TabPane tab="User Trade Detail" key="3">
                                                <div role="tabpanel" className="tab-pane" id="tab3">
                                                    <div className="container-fluid pl-0 pr-0">
                                                        <div className="row">
                                                            <div className="col-lg-12">
                                                                <div className="card pb-0 mb-0">
                                                                    <div className="card-body pb-2 pt-0">
                                                                        <div className="mb-3 pt-3"><a onClick={getUpdatedQuote} href="javascript:void(0);" className="refreshBtn"><i className="fa fa-undo pr-2" aria-hidden="true"></i></a>
                                                                            <span className="infoText">Request you to press the refress button to see the updated quote values</span></div>
                                                                        <div className="table-responsive">
                                                                            <DataTable
                                                                                thead={thead}>
                                                                                {usersTrades && usersTrades?.data.data.length > 0 ?


                                                                                    usersTrades && usersTrades?.data?.data.length > 0 && usersTrades?.data?.data.map((item, i) => (
                                                                                        <tr key={i}>
                                                                                            <td>{item?.id}</td>
                                                                                            <td>{item?.commodity?.description}</td>
                                                                                            <td>{item?.commodity?.name}</td>
                                                                                            <td>{item?.quantity} {item?.unit?.name}</td>
                                                                                            <td>{moment(item?.createdAt).format("MMM DD,YYYY h:mm:ss")}</td>
                                                                                            <td>{item?.total}</td>
                                                                                            <td>{item?.minPrice}</td>
                                                                                            <td>{item?.maxPrice}</td>
                                                                                            <td>{moment(item?.broadcastDate).format("MMM DD,YYYY h:mm:ss")}</td>
                                                                                            <td>{item?.statusStr}</td>
                                                                                            <td>


                                                                                                <div class="tooltip-box">
                                                                                                    <ul class="list">

                                                                                                        <li><Link title="View" to={`/trades/${item.id}`}><i class="fa fa-eye"></i></Link></li>
                                                                                                    </ul>
                                                                                                </div>

                                                                                            </td>
                                                                                        </tr>

                                                                                    ))

                                                                                    :
                                                                                    <tr class="ant-table-placeholder"><td colspan="11" class="ant-table-cell"><div class="ant-empty ant-empty-normal"><div class="ant-empty-image"><svg class="ant-empty-img-simple" width="64" height="41" viewBox="0 0 64 41" xmlns="http://www.w3.org/2000/svg"><g transform="translate(0 1)" fill="none" fill-rule="evenodd"><ellipse class="ant-empty-img-simple-ellipse" cx="32" cy="33" rx="32" ry="7"></ellipse><g class="ant-empty-img-simple-g" fill-rule="nonzero"><path d="M55 12.76L44.854 1.258C44.367.474 43.656 0 42.907 0H21.093c-.749 0-1.46.474-1.947 1.257L9 12.761V22h46v-9.24z"></path><path d="M41.613 15.931c0-1.605.994-2.93 2.227-2.931H55v18.137C55 33.26 53.68 35 52.05 35h-40.1C10.32 35 9 33.259 9 31.137V13h11.16c1.233 0 2.227 1.323 2.227 2.928v.022c0 1.605 1.005 2.901 2.237 2.901h14.752c1.232 0 2.237-1.308 2.237-2.913v-.007z" class="ant-empty-img-simple-path"></path></g></g></svg></div><div class="ant-empty-description">No Data</div></div></td></tr>
                                                                                }
                                                                            </DataTable>


                                                                            {usersTrades && usersTrades?.data.data.length > 0 &&
                                                                                <Pagination defaultCurrent={1} current={currentPage} onChange={onChangePagination} total={usersTrades?.data.count} />
                                                                            }
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </TabPane>
                                        </Tabs>
                                    </div>
                                }
                            </div>
                        </div>
                    </div>
                </div>


            </DashboardLayout>
        </div >
    )
}



export default ViewUserManagement

