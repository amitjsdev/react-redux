import React, { useEffect, useState } from 'react';
import { message, Tabs } from 'antd';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import DashboardGraph from '../common/DashboardGraph';
import NewUserRequest from '../common/NewUserRequest';
import NewUserTradeRequest from '../common/NewUserTradeRequest';
import DashboardLayout from "./../Layout/DashboardLayout";
import { API_BASE_URL_LIVE } from '../../config/constants';
import axios from 'axios';
import TradingOverViewGraph from '../common/TradingOverViewGraph';
import DashboardTrades from './tradeManagement/DashboardTrades';
const { TabPane } = Tabs;


const Dashboard = () => {
    const [graph, setGraph] = useState(0);
    useEffect(() => {
        localStorage.removeItem("editRequest");
        const requestOptions = {
            method: 'GET',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        };
        return axios
            .get(`${API_BASE_URL_LIVE}master-data`, requestOptions)
            .then(response => {
                if (response.data) {
                    setGraph(response.data)
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
            });
    }, []);
    return (
        <DashboardLayout>
            {/* <ChartSummary /> */}
            <div class="page-inner">
                {/* <div class="container-fluid pl-0 pr-0">
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <div class="card box-shadow">
                                <div class="card-body">
                                    <h5 class="graph-title">New User Overview</h5>
                                    <div class="pie-charts">
                                         <div class="pieID--micro-skills pie-chart--wrapper">
                                            <div class="pie-chart">
                                                <div class="pie-chart__pie"></div>
                                                <div class="project--number">
                                                    <div class="pro-num">100</div>
                                                    <div class="pro-name">Users</div>
                                                </div>
                                                <ul class="pie-chart__legend">
                                                    <li><em>Inprocess</em><span>40</span></li>
                                                    <li><em>Completed</em><span>35</span></li>
                                                    <li><em>Pending</em><span>25</span></li>
                                                </ul>
                                            </div>
                                        </div> 
                                        <pieChart></pieChart>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <div class="card box-shadow">
                                <div class="card-body">
                                    <h5 class="graph-title">New Trading</h5>
                                    <div class="pie-charts">
                                        <div class="pieID--categories pie-chart--wrapper">
                                            <div class="pie-chart">
                                                <div class="pie-chart__pie"></div>
                                                <div class="project--number">
                                                    <div class="pro-num">12</div>
                                                    <div class="pro-name">Tradings</div>
                                                </div>
                                                <ul class="pie-chart__legend">
                                                    <li><em>Inprocess</em><span>3</span></li>
                                                    <li><em>Completed</em><span>6</span></li>
                                                    <li><em>Pending</em><span>3</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <div class="card box-shadow">
                                <div class="card-body">
                                    <h5 class="graph-title">Bids Overview</h5>
                                    <div class="pie-charts">
                                        <div class="pieID--operations pie-chart--wrapper">
                                            <div class="pie-chart">
                                                <div class="pie-chart__pie"></div>
                                                <div class="project--number proj-left">
                                                    <div class="pro-num">30</div>
                                                    <div class="pro-name">Bids</div>
                                                </div>
                                                <ul class="pie-chart__legend">
                                                    <li><em>Inprocess</em><span>5</span></li>
                                                    <li><em>Completed</em><span>10</span></li>
                                                    <li><em>Pending</em><span>15</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> */}
                <div className="row">
                    <div className="col-md-6">
                        <div class="card pt-6">
                            <h5 class="graph-title">User Overview</h5>
                            <DashboardGraph data={graph} type="users" color={['green','purple','yellow']}/>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div class="card pt-6">
                            <h5 class="graph-title">Trading Request Overview</h5>
                            <DashboardGraph data={graph} type="trade" color={['orange', 'navy', 'black']}/>
                        </div>
                    </div>
                    {/* <div className="col-md-4">
                        <div class="card pt-4">
                            <h5 class="graph-title">Trading Overview</h5>
                            <TradingOverViewGraph data={graph && graph.earning ? graph.earning:undefined} color={['blue','green','red']}/>
                        </div>
                    </div> */}
                </div>
                <div class="container-fluid pl-0 pr-0 card">
                    <div class="row">
                        <div class="col-lg-12 position-relative">
                            <Tabs defaultActiveKey="1">
                                <TabPane tab="New User Request" key="1" class="nav nav-tabs">
                                    {/* <Link to="/new-user-request?activeKey=1" onClick={e => localStorage.setItem('editRequest',1)} className="viewAll font-weight-bold">View All</Link> */}
                                    <NewUserRequest />
                                </TabPane>
                                <TabPane tab="New Trading Request" key="2">
                                {/* <Link to="/new-user-request?activeKey=2" onClick={e => localStorage.setItem('editRequest',1)} className="viewAll font-weight-bold">View All</Link> */}

                                    <DashboardTrades />
                                </TabPane>
                            </Tabs>
                        </div>
                    </div>
                </div>
            </div >
        </DashboardLayout >
    )
}

export default Dashboard

