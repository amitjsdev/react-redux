import { yupResolver } from '@hookform/resolvers';
import moment from 'moment';
import React, { useEffect, useState } from 'react';
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from 'react-redux';
import { useParams,useHistory } from 'react-router-dom';
import * as Yup from 'yup';
import { getUserTradeDetail, rejectTradeRequest, acceptTradeRequest } from '../../AuthenticatedApp/store/redux/trades/Actions';
import DashboardLayout from "../../Layout/DashboardLayout";

const UserTradeDetails = () => {
    const DateFormat=(date)=>{
        date = moment(date);
        if(date.isValid()){
            return date.format('MMM DD,YYYY hh:mm:ssA').toString()
        }
        return ''
    }
    const history = useHistory();
    const params = useParams();
    const [visible, setVisible] = useState('none');
    const [userId, setUserId] = useState(false);
    const [editable, setEditable] = useState(true);
    const [type, setType] = useState(true);
    const [comment,setComment] = useState();



    const dispatch = useDispatch();
    const usersDetails = useSelector(state => state && state.trades && state.trades.data && state.trades.data.data ? state.trades.data.data : null);

    if (!usersDetails) {
        dispatch(getUserTradeDetail(params));
    }

    useEffect(() => {
        dispatch(getUserTradeDetail(params));
    }, []);

    const handleAccept = (id) => {
        setType('accept');
        setUserId(id);
        setVisible(visible == 'none' ? 'block' : 'none');
    }

    const handlereject = (id) => {
        setType('reject')
        setUserId(id);
        setVisible(visible == 'none' ? 'block' : 'none');
    }

    const handleEdit = () => {
        setVisible('none');
        setEditable(false);
    }

    // form validation rules 
    const validationSchema = Yup.object().shape({
        comments: Yup.string()
            .required('Comment is required'),

    });

    // functions to build form returned by useForm() hook
    const { register, handleSubmit, reset, errors } = useForm({
        resolver: yupResolver(validationSchema)
    });

    function onSubmit(data) {
        //console.log('typetype',type)
        if (type == 'reject') {
            dispatch(rejectTradeRequest(userId,comment,history));
        } else {
            dispatch(acceptTradeRequest(userId,comment,history));
        }
        setVisible('none');
        reset();
    }
    return (
        <DashboardLayout>

            <div class="page-inner pt-2">
                <div class="container-fluid pl-0 pr-0">
                    <div class="detail-panel" style={{ overflow: 'hidden' }}>
                        <div class="row card-gutter ml-0 mr-0">
                            <div class="pt-3"><h2 class="screenName">Trade Request Details</h2></div>
                            <ul class="actionList">
                                <li><h3 class="h3">ID: <span>{usersDetails ? usersDetails.id : 0}</span></h3></li>
                                <li onClick={() => {
                                    handleAccept(usersDetails.id, 'accept')
                                }}><a class="comment_box" title="Approve"><i class="fa fa-check-circle-o approve" aria-hidden="true" ></i>Approve</a></li>
                                <li  onClick={() => {
                                    handlereject(usersDetails.id, 'reject')
                                }}><a class="comment_reject" title="Reject">
                                    <i class="fa fa-times-circle-o reject" aria-hidden="true"></i>Reject</a></li>
                                {/* <li><a title="Edit"><i class="fa fa-edit" onClick={() => {
                                    handleEdit(usersDetails.id)
                                }}></i>Edit</a></li> */}
                                <li class="last">Created Date: <br /><span class="titleName">{usersDetails ? DateFormat(usersDetails.createdAt):''}</span></li>

                            </ul>
                            <div id="comment_box" class="comment-box" style={{ display: visible }}>
                                <form onSubmit={handleSubmit(onSubmit)} onReset={reset}>
                                    <div class="form-row">
                                        <div class="col-md-10 mb-2">
                                            <label>Comments</label>
                                            <textarea type="text" name="comments" onChange={(e)=>{
                                                setComment(e.target.value)
                                            }}ref={register} className={`form-control ${errors.comments ? 'is-invalid' : ''}`} rows="1" placeholder="Your comment here..."></textarea>
                                            <div className="invalid-feedback">{errors.comments?.message}</div>
                                        </div>
                                        <div class="col-md-2 mb-2">
                                            <button class="btn btn-green btn-top w-100" type="submit">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div id="comment_reject" class="comment-box">
                                <div class="form-row">
                                    <div class="col-md-10 mb-2">
                                        <label>Comments</label>
                                        <textarea type="text" class="form-control" rows="1" placeholder="Your comment here..."></textarea>
                                    </div>
                                    <div class="col-md-2 mb-2">
                                        <button class="btn btn-green btn-top w-100" type="submit">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-gutter ml-0 mr-0">
                            <div class="col-lg-12">
                                <form style={{ padding: '0.8rem 1rem' }}>
                                    <fieldset class="scheduler-border">
                                        <legend class="scheduler-border">Request Detail</legend>
                                        <div class="form-row">
                                            <div class="col-md-3 mb-2">
                                                <label>Commodity Item</label>
                                                <input type="text" class="form-control" placeholder="Chana" value={usersDetails && usersDetails.commodity ? usersDetails.commodity.name : 0} disabled={editable} />
                                            </div>
                                            <div class="col-md-3 mb-2">
                                                <label>Item QTY</label>
                                                <input type="text" class="form-control" placeholder="" value={`${usersDetails?.quantity} ${usersDetails?.unit?.name}`} disabled={editable} />
                                            </div>
                                            <div class="col-md-3 mb-2">
                                                <label>Title</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="" disabled={editable} value={usersDetails?.title} />
                                                </div>
                                            </div>
                                            <div class="col-md-3 mb-2">
                                                <label>Description</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Indian Black Chana" disabled={editable} value={usersDetails && usersDetails.commodity ? usersDetails.commodity.description : ''} />
                                                </div>
                                            </div>
                                            <div class="col-md-3 mb-2">
                                                <label>Expected Live Date</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="" value={usersDetails ? DateFormat(usersDetails.broadcastDate) :'NA'} disabled={editable} />
                                                </div>
                                            </div>
                                            <div class="col-md-3 mb-2">
                                                <label>Expected Close Date</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="" value={usersDetails ? DateFormat(usersDetails.closeDate): 'NA'} disabled={editable} />
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                    <fieldset class="scheduler-border">
                                        <legend class="scheduler-border">Buyer Information</legend>
                                        <fieldset class="scheduler-border">
                                            <div class="form-row pt-3">
                                                <div class="col-md-3 mb-2">
                                                    <label>First Name</label>
                                                    <input type="text" class="form-control" placeholder="Deepak" value={usersDetails && usersDetails.CreatedUser ? usersDetails.CreatedUser.first_name : ''} disabled={editable} />
                                                </div>
                                                <div class="col-md-3 mb-2">
                                                    <label>Last Name</label>
                                                    <input type="text" class="form-control" placeholder="Singn" value={usersDetails && usersDetails.CreatedUser ? usersDetails.CreatedUser.last_name : ''} disabled={editable} />
                                                </div>
                                                <div class="col-md-3 mb-2">
                                                    <label>Email ID</label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" value={usersDetails && usersDetails.CreatedUser ? usersDetails.CreatedUser.email : ''} placeholder="value_harvest@gmail.com" disabled={editable} />
                                                    </div>
                                                </div>
                                                <div class="col-md-3 mb-2">
                                                    <label>Mobile Number</label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" id="validationDefault01" placeholder="98754862" value={usersDetails && usersDetails.CreatedUser ? usersDetails.CreatedUser.mobile : ''} disabled={editable} />
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset class="scheduler-border">
                                            <legend class="scheduler-border">Business Address</legend>
                                            <div class="address-container">
                                                <div class="form-row">
                                                    <div class="col-md-4 mb-2">
                                                        <label>Address 1</label>
                                                        <input type="text" class="form-control" placeholder="N.No-246" disabled={editable} />
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label>Address 2</label>
                                                        <div class="input-group">
                                                            <input type="text" class="form-control" placeholder="Nodia, Uttar Pradesh" disabled={editable} />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label>District</label>
                                                        <div class="input-group">
                                                            <select class="form-control form-select" disabled={editable}>
                                                                <option selected>North-West</option>
                                                                <option>North-West</option>
                                                                <option>East</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label>State</label>
                                                        <div class="input-group">
                                                            <select class="form-control form-select" disabled={editable}>
                                                                <option selected>Uttar Pradesh</option>
                                                                <option>Haryana</option>
                                                                <option>Punjab</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label >Zip Code</label>
                                                        <input type="text" class="form-control" placeholder="110065" disabled={editable} />
                                                    </div>
                                                    <div class="col-md-4 mb-2">
                                                        <label>Country</label>
                                                        <div class="input-group">
                                                            <select class="form-control form-select" disabled={editable} >
                                                                <option selected>India</option>
                                                                <option>India</option>
                                                                <option>United Kingdom</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                    </fieldset>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </DashboardLayout>
    )
}

export default UserTradeDetails
