import { Tabs } from 'antd';
import React from 'react';
import { Link } from "react-router-dom";
import NewUserRequest from '../../common/NewUserRequest';
import NewUserTradeRequest from '../../common/NewUserTradeRequest';
import DashboardLayout from "../../Layout/DashboardLayout";
const { TabPane } = Tabs;

const NewTradingRequest = () => {
    return (
        <>
            <DashboardLayout>
                <div class="page-inner">
                    <div class="container-fluid pl-0 pr-0 card">
                        <div class="row">
                            <div class="col-lg-12">
                                <Tabs defaultActiveKey="2">
                                    <TabPane tab="New User Request" key="1">
                                        <NewUserRequest />
                                    </TabPane>

                                    <TabPane tab="New Trading Request" key="2">
                                        <NewUserTradeRequest />
                                    </TabPane>
                                </Tabs>
                            </div>
                        </div>
                    </div>
                </div>
            </DashboardLayout>

        </>
    )
}


export default NewTradingRequest

