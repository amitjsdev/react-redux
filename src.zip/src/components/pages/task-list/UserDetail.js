import React, { useRef, useEffect, useState, useInput } from "react";
import { yupResolver } from "@hookform/resolvers";
import DashboardLayout from "../../Layout/DashboardLayout";
import { useParams, Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getUserDetail } from "../../AuthenticatedApp/store/redux/users/Actions";
import { useForm } from "react-hook-form";
import useTableSearch from "../../../hooks/useTableSearch";
import { useHistory } from "react-router-dom";
import { Input, Space, Spin, Table, Tabs, Form, message } from "antd";
import {
  acceptRequest,
  rejectRequest,
  updateUser,
} from "../../AuthenticatedApp/store/redux/users/Actions";
import * as Yup from "yup";
import axios from "axios";

import { useFormik, Formik } from "formik";
import { API_BASE_URL_LIVE } from "../../../config/constants";
import moment from "moment";
import { getItemPriceList } from "../../AuthenticatedApp/store/redux/itemPrice/Actions";
import UserPersonalInfo from "../../common/UserPersonalInfo";
import UserAddressInfo from "../../common/UserAddressInfo";

import UserIdentityInfo from "../../common/UserIdentityInfo";
import UserGeoLocation from "../../common/UserGeoLocation";
import UserCommodityDetails from "../../common/UserCommodityDetails";
const { TabPane } = Tabs;

const UserDetail = () => {
  const params = useParams();
  const history = useHistory();
  const isAddMode = !params.id;
  const [visible, setVisible] = useState("none");
  const [userId, setUserId] = useState(false);
  const [pageMode, SetPageMode] = useState("read");
  const [historystatus, setHistory] = useState([1, 2, 3]);

  const [comment, setComment] = useState();

  const [status, setStatus] = useState();
  const [userValue, setUserValue] = useState();
  const [type, setType] = useState(true);
  const [tempCommidity, setTempCommidity] = useState([]);
  let tradeList = useSelector((state) =>
    state.trades && state.trades.usertradelist
      ? state.trades.usertradelist
      : null
  );
  let trade = tradeList && tradeList.data ? tradeList.data : [];
  const { search, filterTable } = useTableSearch(trade);
  const dispatch = useDispatch();

  const validate = (values) => {
    const errors = {};
    if (!values.first_name) {
      errors.first_name = "This field is required";
    } else if (values.first_name.length > 15) {
      errors.first_name = "Must be 15 characters or less";
    }

    if (!values.last_name) {
      errors.last_name = "This field is required";
    } else if (values.last_name.length > 20) {
      errors.last_name = "Must be 20 characters or less";
    }

    if (!values.pan.number) {
      errors.pan = "This field is required";
    } else if (values.pan.number.length != 10) {
      errors.pan = "Must be 10 characters";
    }
    if (!values.aadhar) {
      errors.aadhar = "This field is required";
    } else if (values.aadhar.number.length != 12) {
      errors.aadhar = "Must be 12 characters";
    }

    if (!values.gstin) {
      errors.gstin = "This field is required";
    } else if (values.gstin.number.length != 15) {
      errors.gstin = "Must be 15 characters";
    }

    if (!values.mobile) {
      errors.last_name = "This field is required";
    } else if (values.mobile.length > 10) {
      errors.mobile = "Must be 10 characters or less";
    }

    if (!values.email) {
      errors.email = "This field is required";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)
    ) {
      errors.email = "Invalid email address";
    }

    if (!values.bussiness.zip) {
      errors.zip = "This field is required";
    } else if (
      !/^(0*[1-9][0-9]*(\.[0-9]*)?|0*\.[0-9]*[1-9][0-9]*)$/.test(
        values.bussiness.zip
      )
    ) {
      errors.zip = "Please enter number only";
    }

    if (!values.residential.zip) {
      errors.zip = "This field is required";
    } else if (
      !/^(0*[1-9][0-9]*(\.[0-9]*)?|0*\.[0-9]*[1-9][0-9]*)$/.test(
        values.residential.zip
      )
    ) {
      errors.zip2 = "Please enter number only";
    }

    return errors;
  };
  // const usersDetails = useSelector(state => state && state.user && state.user.data ? state.user.data : null);
  const initialValues = {
    userName: "",
    first_name: userValue && userValue.first_name,
    last_name: userValue && userValue.last_name,
    email: userValue && userValue.email,
    dob: "11/12/1991",
    mobile: userValue && userValue.mobile,
    UserRole: {
      role: userValue && userValue.UserRole.role,
    },
    residential: {
      address1:
        userValue && userValue.residential && userValue.residential.address1,
      address2:
        userValue && userValue.residential && userValue.residential.address2,
      city: userValue && userValue.residential && userValue.residential.city,
      state: userValue && userValue.residential && userValue.residential.state,
      country:
        userValue && userValue.residential && userValue.residential.country,
      district:
        userValue && userValue.residential && userValue.residential.district,
      zip: userValue && userValue.residential && userValue.residential.zip,
    },
    latlng: {
      lat: userValue && userValue.latlng && userValue.latlng.lat,
      lng: userValue && userValue.latlng && userValue.latlng.lng,
      address1: "full address",
    },
    bussiness: {
      address1:
        userValue && userValue.bussiness && userValue.bussiness.address1,
      address2:
        userValue && userValue.bussiness && userValue.bussiness.address2,
      city: userValue && userValue.bussiness && userValue.bussiness.city,
      state: userValue && userValue.bussiness && userValue.bussiness.state,
      district:
        userValue && userValue.bussiness && userValue.bussiness.district,
      country: userValue && userValue.bussiness && userValue.bussiness.country,
      zip: userValue && userValue.bussiness && userValue.bussiness.zip,
      lat: "8883",
      lng: "0003",
    },
    // banks: {
    //   name: "Snak",
    //   number: "1234543234",
    //   bank: "PNB",
    //   ifsc: "PUNB014200",
    //   bank_address: "phase 5 ",
    //   bank_city: "mohali",
    //   bank_zip: "8883",
    //   bank_asso: "ASSo",
    //   swift_code: "swift_code",
    //   status: 1,
    // },
    aadhar: {
      number: userValue?.aadhar?.number,
      file: {
        type: "aadhar",
        data: " data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAg2Q==",
        name: userValue?.aadhar?.file.name,
        id: userValue?.aadhar?.file.id
      },
    },
    pan: {
      number: "1234567890",
      file: {
        type: ".png", data: "", name: userValue?.pan?.file.name,
        id: userValue?.pan?.file.id
      },
    },
    gstin: {
      number: "123456789012",
      file: {
        type: ".jpg", data: "ddddddddddd", name: userValue?.gstin?.file.name,
        id: userValue?.gstin?.file.id
      },
    },
    import: {
      number: "123456789012",
      file: {
        type: ".jpg", data: "ddddddddddd", name: userValue?.import?.file.name,
        id: userValue?.import?.file.id
      },
    },
    export: {
      number: "123456789012",
      file: {
        type: ".jpg", data: "ddddddddddd", name: userValue?.export?.file.name,
        id: userValue?.export?.file.id
      },
    },
    type: "",
    entity: userValue?.entity,
    commodity: userValue && userValue.commodity,
  };
  const myRef = useRef(null)

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });

    let edit = localStorage.getItem("edit");
    if (edit == "edit") {
      SetPageMode("edit");
    } else {
      localStorage.removeItem("edit");
    }
    // dispatch(getUserDetail(params));
    dispatch(getItemPriceList());

    const requestOptions = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    };
    return axios
      .get(`${API_BASE_URL_LIVE}users/${params.id}?all=true`, requestOptions)
      .then((response) => {
        if (response.data) {
          setStatus(response.data.status);
          let residential =
            response.data.Addresses && response.data.Addresses.length > 0
              ? response.data.Addresses.filter((e) => e.type == "residential")
              : null;

          let geo =
            response.data.Addresses && response.data.Addresses.length > 0
              ? response.data.Addresses.filter((e) => e.type == "geo")
              : null;
          let bussiness =
            response.data.Addresses && response.data.Addresses.length > 0
              ? response.data.Addresses.filter((e) => e.type == "bussiness")
              : null;
          let pan =
            response.data.Identities && response.data.Identities.length > 0
              ? response.data.Identities.filter((e) =>
                e.title == "pan" ? e.number : null
              )
              : null;
          let aadhar =
            response.data.Identities && response.data.Identities.length > 0
              ? response.data.Identities.filter((e) =>
                e.title == "aadhar" ? e.number : null
              )
              : null;
          let gstin =
            response.data.Identities && response.data.Identities.length > 0
              ? response.data.Identities.filter((e) =>
                e.title == "gstin" ? e.number : null
              )
              : null;

          let imports =
            response.data.Identities && response.data.Identities.length > 0
              ? response.data.Identities.filter((e) =>
                e.title == "import" ? e.number : null
              )
              : null;
          let gstins =
            response.data.Identities && response.data.Identities.length > 0
              ? response.data.Identities.filter((e) =>
                e.title == "export" ? e.number : null
              )
              : null;
          setHistory(response.data.history);
          setUserValue({
            id: response.data.id,
            userName: response.data.userName,
            first_name: response.data.first_name,
            last_name: response.data.last_name,
            email: response.data.email,
            dob: response.data.dob,
            mobile: response.data.mobile,
            UserRole: {
              role: response.data.UserRole.role,
            },
            residential: {
              address1: residential && residential[0].address1,
              address2: residential && residential[0].address2,
              city: residential && residential[0].cityName ? residential[0].cityName : residential[0].city,
              state: residential && residential[0].stateName ? residential[0].stateName : residential[0].state,
              country: residential && residential[0].countryName ? residential[0].countryName : residential[0].country,
              district: residential && residential[0].district,
              zip: residential && residential[0].zip,
            },
            latlng: {
              lat: geo && geo.length > 0 && geo[0].lat,
              lng: geo && geo.length > 0 && geo[0].lng,
              address1: geo && geo.length > 0 && geo[0].full_address,
            },
            bussiness: {
              address1: bussiness && bussiness[0].address1,
              address2: bussiness && bussiness[0].address2,
              city: bussiness && bussiness[0].cityName ? bussiness[0].cityName : bussiness[0].city,
              state: bussiness && bussiness[0].stateName ? bussiness[0].stateName : bussiness[0].state,
              district: bussiness && bussiness[0].stateName,
              country: bussiness && bussiness[0].countryName ? bussiness[0].countryName : bussiness[0].country,
              zip: bussiness && bussiness[0].zip,
            },
            banks: {
              name: response.data?.Bank?.holder_name,
              number: response.data?.Bank?.account_number,
              bank: response.data?.Bank?.bank,
              ifsc: response.data?.Bank?.ifsc,
              swift_code: response.data?.Bank?.swift,
              status: 1,
            },
            aadhar: {
              number: response.data?.Identities[0]?.number,
              file: {
                type: response.data?.Identities[0]?.title,
                data:
                  " data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAg2Q==",
                name: response.data?.Identities[0]?.EntityFile?.File.title,
                id: response.data?.Identities[0]?.EntityFile?.File.id
              },
            },
            pan: {
              number: response.data?.Identities[1]?.number,
              file: {
                type: response.data?.Identities[1]?.title,
                data:
                  " data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAg2Q==",
                name: response.data?.Identities[1]?.EntityFile?.File.title,
                id: response.data?.Identities[1]?.EntityFile?.File.id
              },
            },
            gstin: {
              number: response.data?.Identities[2]?.number,
              file: {
                type: response.data?.Identities[2]?.title,
                data:
                  " data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAg2Q==",
                name: response.data?.Identities[2]?.EntityFile?.File.title,
                id: response.data?.Identities[2]?.EntityFile?.File.id
              },
            },
            kyc: {
              number: "123456789012",
              file: {
                type: ".jpg",
                data: "ddddddddddd",
                name: "43769-861x484.jpg",
              },
            },
            import: {
              number: response.data?.Identities[3]?.number,
              file: {
                type: response.data?.Identities[3]?.title,
                data:
                  " data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAg2Q==",
                name: response.data?.Identities[3]?.EntityFile?.File.title,
                id: response.data?.Identities[3]?.EntityFile?.File.id
              },
            },
            export: {
              number: response.data?.Identities[4]?.number,
              file: {
                type: response.data?.Identities[4]?.title,
                data:
                  " data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAg2Q==",
                name: response.data?.Identities[4]?.EntityFile?.File.title,
                id: response.data?.Identities[4]?.EntityFile?.File.id
              },
            },
            type:
              response.data.UserRole && response.data.UserRole.length > 0
                ? response.data.UserDetail.role
                : "",
            entity: response.data.entityStr,
            commodity: response.data.EntityCommodities,
          });

        }
      })

      .catch((e) => {
        message.error("Something went wrong");
      });
  }, []);

  let commodity = useSelector((state) =>
    state.itemPrice && state.itemPrice.itemPriceList
      ? state.itemPrice.itemPriceList.data
      : null
  );

  const handleAccept = (id) => {
    setType("approved");
    setUserId(id);
    setVisible('block');
  };

  const handlereject = (id) => {
    setType("reject");
    setUserId(id);
    setVisible('block');
  };

  const editMode = () => {
    SetPageMode("edit");
  };
  const [isCommentError, setCommentError]=useState(null)

  const onSubmitRequest = async () => {
     if(!comment){
       setCommentError(true)
     }else {
      setCommentError(false)
    //console.log('onSubmitRequest',type)
    if (type === "reject") {
      await dispatch(rejectRequest(userId,comment));
      setVisible(false);
      history.push("/user-management");
    } else if (type === "approved") {
      await dispatch(acceptRequest(userId,comment));
      setVisible(false);
      history.push("/user-management");
    }}
  };


  const handleSave = async (id, e) => {
    //console.log('userIduserId', e.values)
    let commodityData = []
    e.values?.commodity && e.values?.commodity.length > 0 && e.values?.commodity.map((item) => {
      
      if(tempCommidity.includes(item?.Commodity?.id)){
      }else{
        commodityData.push(item?.Commodity?.id)
      }
      //console.log('itemitem', item)
    })
    let userData = {
      userName: e.values?.userName,
      first_name: e.values?.first_name,
      last_name: e.values?.last_name,
      email: e.values?.email,
      dob: e.values?.dob,
      mobile: e.values?.mobile,
      residential: {
        address1: e.values?.residential.address1,
        address2: e.values?.residential.address2,
        city: e.values?.residential.city,
        state: e.values?.residential.state,
        country: e.values?.residential.country,
        district: e.values?.residential.district,
        zip: e.values?.residential.zip
      },
      latlng: {
        lat: e.values?.latlng?.lat,
        lng: e.values?.latlng?.lng,
        address1: e.values?.latlng?.address1
      },
      bussiness: {
        address1: e.values?.bussiness?.address1,
        address2: e.values?.bussiness?.address2,
        city: e.values?.bussiness?.city,
        state: e.values?.bussiness?.state,
        district: e.values?.bussiness?.district,
        country: e.values?.bussiness?.country,
        zip: e.values?.bussiness?.zip,
        lat: "",
        lng: ""
      },
      banks: {
        name: e.values?.banks?.name,
        number: e.values?.banks?.number,
        bank: e.values?.banks?.bank,
        ifsc: e.values?.banks?.ifsc,
        bank_address: e.values?.banks?.bank_address,
        bank_city: e.values?.banks?.bank_city,
        bank_zip: e.values?.banks?.bank_zip,
        bank_asso: e.values?.banks?.bank_asso,
        swift_code: e.values?.banks?.swift_code,
        status: e.values?.banks?.status,
      },
      aadhar: {
        number: e.values?.aadhar?.number,
        file: {
          type: e.values?.aadhar?.file.type,
          data: e.values?.aadhar?.file.data,
          name: e.values?.aadhar?.file.name,
        }
      },
      pan: {
        number: e.values?.pan?.number,
        file: {
          type: e.values?.pan?.file.type,
          data: e.values?.pan?.file.data,
          name: e.values?.pan?.file.name,
        }
      },
      gstin: {
        number: e.values?.pan?.number,
        file: {
          type: e.values?.pan?.file.type,
          data: e.values?.pan?.file.data,
          name: e.values?.pan?.file.name,
        }

      },
      kyc: {
        number: "123456789012",
        file: {
          type: ".jpg",
          data: "ddddddddddd",
          name: "43769-861x484.jpg"
        }
      },
      import: {
        number: e.values?.import?.number,
        file: {
          type: e.values?.import?.file.type,
          data: e.values?.import?.file.data,
          name: e.values?.import?.file.name,
        }
      },
      export: {
        number: e.values?.export?.number,
        file: {
          type: e.values?.export?.file.type,
          data: e.values?.export?.file.data,
          name: e.values?.export?.file.name,
        }
      },
      type: e.values?.UserRole.role,
      entity: e.values?.UserRole.entity,
      commodity: commodityData
    }
    //e.preventDefault()
    await dispatch(updateUser(id, userData));
    setVisible(false);
    // history.push("/user-management");

  };

  const onhandleCancel = () => {
    setVisible('none')
    SetPageMode("cancel");
  };

  const columns1 = [
    {
      title: "Sr.No",
      dataIndex: "id",
      key: "id",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Commodity",
      dataIndex: "commodity",
      key: "commodity",
      render: (item) => {
        return item.name;
      },
    },
    {
      title: "Title",
      dataIndex: "commodity",
      key: "commodity",
      render: (item) => {
        return item.name;
      },
    },

    {
      title: "Qty",
      dataIndex: "quantity",
      key: "quantity",
    },
    {
      title: "Created By",
      dataIndex: "CreatedUser",
      key: "CreatedUser",
      render: (item) => {
        return item.first_name ? item.first_name : "N/A";
      },
    },
    {
      title: "Create Date",
      dataIndex: "createdAt",
      key: "createdAt",
    },
    {
      title: "Total No. of Quotes",
      dataIndex: "createdAt",
      key: "createdAt",
    },
    {
      title: "Low Quote Value",
      dataIndex: "createdAt",
      key: "createdAt",
    },
    {
      title: "High Quote Value",
      dataIndex: "createdAt",
      key: "createdAt",
    },

    {
      title: " Broadcast Date",
      dataIndex: "broadcastDate",
      key: "broadcastDate",
      render: (item) => {
        return item ? item : "N/A";
      },
    },

    {
      title: "Status",
      key: "status",
      dataIndex: "status",
      render: (status) => (
        <>
          <span
            className={
              status == 2
                ? "status rejected"
                : status == 3
                  ? "status pending"
                  : "status approved"
            }
          >
            {status == 2 ? "Rejected" : status == 3 ? "Pending" : "Approved"}
          </span>
        </>
      ),
    },
    {
      title: "Action",
      key: "action",
      render: (item) => (
        <ul class="list">
          <li>
            <Link
              title="View"
              onClick={() => {
                handleView(item.id);
              }}
            >
              <i class="fa fa-eye"></i>
            </Link>
          </li>
        </ul>
      ),
    },
  ];

  const columns = [
    {
      title: "Sr.No",
      dataIndex: "id",
      key: "id",
      render: (text) => <a>{text}</a>,
    },
    {
      title: "Modified By",
      dataIndex: "CreatedUser",
      key: "CreatedUser",
      render: (item) => {
        return "Admin";
      },
    },
    {
      title: "Current Status",
      key: "newData",
      dataIndex: "newData",
      render: (status) => (
        <>
          <span
            className={
              status == "Pending"
                ? "status pending"
                : status == "Rejected"
                  ? "status rejected"
                  : "status approved"
            }
          >
            {status}
          </span>
        </>
      ),
    },

    {
      title: "Modified Date",
      dataIndex: "updatedAt",
      key: "updatedAt",
      render: (item) => {
        return item ? moment(item).format("MMMM DD, YYYY LTS") : "";
      },
    },
  ];

  const handleView = (id) => {
    history.push("/view-user-trade-management/" + id);
  };

  const onCancle = (e) => { };

  const formik = useFormik({
    initialValues: {
      email: '',
    },
    onSubmit: values => {
      alert(JSON.stringify(values, null, 2));
    },
  });

  
  return (

    <DashboardLayout>

      <div ref={myRef}>
        <div className="content">
          <div className="page-inner pt-2">
            <div className="container-fluid pl-0 pr-0">
              <Formik
                initialValues={initialValues}
                enableReinitialize
                validate={validate}
                onSubmit={(values) => {
                  //console.log('values', values)
                  alert(JSON.stringify(values, null, 2));
                  // const requestOptions = {
                  //   method: "PUT",
                  //   headers: {
                  //     "Content-Type": "application/json",
                  //     Authorization: "Bearer " + localStorage.getItem("token"),
                  //   },
                  // };
                  // return axios
                  //   .put(
                  //     `${API_BASE_URL_LIVE}users/${params.id}`,
                  //     values,
                  //     requestOptions
                  //   )
                  //   .then((response) => {
                  //     if (response.data) {
                  //       message.success("Successfully Updated!");
                  //     }
                  //   });
                }}
              >


                {(props) => (

                  <form onSubmit={props.handleSubmit}>
                    <div
                      className="detail-panel"
                      style={{ overflow: "hidden" }}
                    >
                      <div className="row card-gutter ml-0 mr-0">
                        <div className="pt-3">
                          <h2 className="screenName">User Details</h2>
                        </div>
                        <ul className="actionList">
                          <li>
                            <h3 className="h3">
                              ID: <span>{userValue ? userValue.id : 0}</span>
                            </h3>
                          </li>

                          {status !== 1 && status !== 2 ? (
                            <li  onClick={() => {
                              handleAccept(userValue.id);
                            }}>
                              <a
                                className="comment_box"
                                title="Approve"
                               
                              >
                                <i
                                  className="fa fa-check-circle-o approve"
                                  aria-hidden="true"
                                ></i>
                                Approve
                              </a>
                            </li>
                          ) : (
                            ""
                          )}
                          {status !== 2 && status !== 1 ? (
                            <li onClick={() => {
                              handlereject(userValue.id);
                            }}>
                              <a className="comment_reject" title="Reject">
                                <i
                                  className="fa fa-times-circle-o reject"
                                  aria-hidden="true"
                                  
                                ></i>
                                Reject
                              </a>
                            </li>
                          ) : (
                            ""
                          )}

                          {/* <li>
                            <a onClick={editMode} title="Edit">
                              <i className="fa fa-edit"></i>Edit
                            </a>
                          </li> */}
                          {/* <li>
                            <button
                              onClick={() => { handleSave(userValue.id, props) }}
                              type="submit"
                              className="bg-transparent border-0"
                              title="Save"
                              style={{ cursor: "pointer" }}
                            >
                              <i className="fa fa-save mr-1"></i>Save
                            </button>
                          </li> */}
                          {/* <li>
                            <a onClick={onhandleCancel} title="Cancel">
                              <i className="fa fa-cancel"></i>Cancel
                            </a>
                          </li> */}
                          <li className="last">
                            Created Date: <br />
                            <span className="titleName">
                              {userValue
                                ? moment(userValue.createdAt).format(
                                  "MMMM DD, YYYY LTS"
                                )
                                : ""}
                            </span>
                          </li>
                        </ul>
                        <div
                          id="comment_box"
                          className="comment-box"
                          style={{ display: visible }}
                        >
                          <div class="form-row">
                            <div class="col-md-10 mb-2">
                              <label>Comments</label>
                              <textarea
                                type="text"
                                name="comments"
                                className="form-control"
                                rows="1"
                                onChange={(e)=>{
                                  setComment(e.target.value)
                                }}
                                placeholder="Your comment here..."
                              ></textarea>
                            </div>
                            <div class="col-md-2 mb-2">
                              <button
                                type="button"
                                class="btn btn-green btn-top w-100"
                                onClick={onSubmitRequest}
                              >
                                Submit
                              </button>
                            </div>
                            <div className="row">
                            {isCommentError && <div className="invalid-feedback" style={{display:'block',paddingLeft:'23px'}}>Please Enter comment</div>}
                            
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="card-gutter ml-0 mr-0">
                        <div className="col-lg-12">
                          <Tabs defaultActiveKey="1" className="tab-content">
                            <TabPane
                              tab={
                                status !== 1 && status !== 2
                                  ? "User Detail"
                                  : "User Detail"
                              }
                              key="1"
                              className="nav nav-tabs"
                            >
                              <div className="tab-content">
                                <div
                                  role="tabpanel"
                                  className="tab-pane active"
                                  id="tab1"
                                >
                                  <UserPersonalInfo
                                    pageMode={pageMode}
                                    onChange={props.handleChange}
                                    value={props.values}
                                    errors={props.errors}
                                  />
                                  <UserAddressInfo
                                    pageMode={pageMode}
                                    onChange={props.handleChange}
                                    value={props.values}
                                    errors={props.errors}
                                  />
                                 

                                  <div style={{ padding: "0.8rem 1rem" }}>
                                    <UserIdentityInfo
                                      pageMode={pageMode}
                                      onChange={props.handleChange}
                                      value={props.values}

                                      errors={props.errors}
                                    />
                                    {/* <UserGeoLocation
                                      pageMode={pageMode}
                                      onChange={props.handleChange}
                                      value={props.values}
                                      errors={props.errors}
                                    /> */}
                                    <UserCommodityDetails
                                    setTempCommidity={setTempCommidity}
                                    tempCommidity={tempCommidity}
                                      commodity={commodity}
                                      pageMode={pageMode}
                                      onChange={props.handleChange}
                                      value={props.values}
                                      onCancle={onCancle}
                                      errors={props.errors}
                                    />
                                  </div>

                                  {status == 1 || status == 2 ? (
                                    <div className="container pl-0 pr-0">
                                      <h2 className="display-h2 heading-bg">
                                        Approver History
                                      </h2>
                                      <div className="dataTable-panel">
                                        <div className="row ml-0 mr-0">
                                          <div className="table-responsive">
                                            {
                                              <Table
                                                className="table"
                                                columns={columns}
                                                pagination={{ pageSize: 5 }}
                                                dataSource={historystatus}
                                              />
                                            }
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  ) : (
                                    ""
                                  )}
                                </div>
                              </div>
                            </TabPane>
                           { status !== 1 && status !== 2 ?
                           ''
                           :
                            <TabPane
                              key="2"
                              tab={
                                status !== 1 && status !== 2
                                  ? ""
                                  : "User Bank Detail"
                              }
                            >
                              <div
                                role="tabpanel"
                                className="tab-pane"
                                id="tab2"
                              >

                                <form style={{ padding: "0.8rem 1rem" }}>
                                  <fieldset className="scheduler-border">
                                    <legend className="scheduler-border">
                                      Bank Detail
                                    </legend>
                                    <div className="address-container">
                                      <div className="form-row">
                                        <div className="col-md-4 mb-2">
                                          <label>Account Name</label>
                                          <input
                                            type="text"
                                            name="name"
                                            className="form-control"
                                            placeholder="Value Harvest"
                                            value={
                                              userValue && userValue?.banks.name
                                                ? userValue?.banks.name
                                                : ""
                                            }
                                            disabled
                                          />
                                        </div>
                                        <div className="col-md-4 mb-2">
                                          <label>Acount Number</label>
                                          <div className="input-group">
                                            <input
                                              type="text"
                                              name="number"
                                              className="form-control"
                                              placeholder="000000001254"
                                              value={
                                                userValue && userValue?.banks.number
                                                  ? userValue?.banks.number
                                                  : ""
                                              }
                                              disabled
                                            />
                                          </div>
                                        </div>
                                        <div className="col-md-4 mb-2">
                                          <label>Bank Name</label>
                                          <div className="input-group">
                                            <div className="input-group">
                                              <input
                                                type="text"
                                                name="bank"
                                                value={
                                                  userValue && userValue?.banks.bank
                                                    ? userValue?.banks.bank
                                                    : ""
                                                }
                                                className="form-control"
                                                placeholder="HDFC Bank"
                                                disabled
                                              />
                                            </div>
                                          </div>
                                        </div>
                                        <div className="col-md-4 mb-2">
                                          <label>IFSC Code</label>
                                          <div className="input-group">
                                            <input
                                              type="text"
                                              name="ifsc"
                                              value={
                                                userValue && userValue?.banks.ifsc
                                                  ? userValue?.banks.ifsc
                                                  : ""
                                              }
                                              className="form-control"
                                              placeholder="ABC00002"
                                              disabled
                                            />
                                          </div>
                                        </div>

                                        <div className="col-md-4 mb-2">
                                          <label>Swift Code</label>
                                          <div className="input-group">
                                            <input
                                              type="text"
                                              name="swift_code"
                                              value={
                                                userValue &&
                                                userValue?.banks.swift_code
                                              }
                                              className="form-control"
                                              placeholder="101010"
                                              disabled
                                            />
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </fieldset>
                                </form>
                              </div>
                            </TabPane>
                }
                            {/* 
                            <TabPane
                              tab={
                                status !== 1 && status !== 2
                                  ? ""
                                  : "User Trade Detail"
                              }
                              key="3"
                            >
                              <div
                                role="tabpanel"
                                className="tab-pane"
                                id="tab3"
                              >
                                <div className="container-fluid pl-0 pr-0">
                                  <div className="row">
                                    <div className="col-lg-12">
                                      <div className="card pb-0 mb-0">
                                        <div className="card-body pb-2 pt-0">
                                          <div className="mb-3 pt-3">
                                            <a
                                              href="javascript:void(0);"
                                              className="refreshBtn"
                                            >
                                              <i
                                                className="fa fa-undo pr-2"
                                                aria-hidden="true"
                                              ></i>
                                            </a>
                                            <span className="infoText">
                                              Request you to press the refress
                                              button to see the updated quote
                                              values
                                            </span>
                                          </div>

                                          <div className="table-responsive">
                                            <Input.Search
                                              style={{
                                                margin: "0 0 10px 0",
                                                width: "auto",
                                              }}
                                              placeholder="Search by..."
                                              enterButton
                                              onSearch={search}
                                            />

                                            <Table
                                              className="table"
                                              columns={columns1}
                                              dataSource={
                                                filterTable == null
                                                  ? tradeList &&
                                                    tradeList.data &&
                                                    tradeList.data.data
                                                  : filterTable
                                              }
                                            />
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </TabPane> */}
                          </Tabs>
                        </div>
                      </div>
                    </div>
                  </form>
                )}
              </Formik>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default UserDetail;
