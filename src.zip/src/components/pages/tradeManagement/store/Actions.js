import * as ActionTypes from './ActionTypes';
import Axios from 'axios';
import { message } from 'antd';

export const setLoading = (payload) => ({
    type: ActionTypes.TRADES_LOADING,
    payload
})

export const setError = (payload) => ({
    type: ActionTypes.LOAD_TRADES_FAILURE,
    payload
})

export const setSuccess = () => ({
    type: ActionTypes.LOAD_TRADES_SUCCESS
})

export const loadTrades = (payload) => ({
    type: ActionTypes.LOAD_TRADES,
    payload
})

export const loadActiveTrade = payload => ({
    type: ActionTypes.LOAD_ACTIVE_TRADE,
    payload
})
export const setQoutes = payload => ({
    type: ActionTypes.SET_QOUTES_TRADE,
    payload
})
export const setPO = payload => ({
    type: ActionTypes.SET_PO,
    payload
})
export const getTransitSuccess = payload => ({
    type: ActionTypes.SET_TRANSIT_DATA,
    payload
})
export const setPaymentSuccess = payload => ({
    type: ActionTypes.SET_PAYMENT_DATA,
    payload
})

export const setTradeHistory = (payload) => ({
    type: ActionTypes.SET_TRADE_HISTORY,
    payload
})

export const deleteTrades = payload => ({
    type: ActionTypes.DELETE_TRADE,
    payload
})

export const addTrades = (payload) => ({
    type: ActionTypes.ADD_TRADE,
    payload
})
export const updateSync = () => ({
    type: ActionTypes.UPDATE_SYNC,
})
export const modalOpned = (payload) => ({
    type: ActionTypes.MODAL_INIT,
    payload
})

export const getTrades = () => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.get(`${process.env.REACT_APP_API_URL}trade`,
        )
            .then(res => {
                dispatch(setLoading(false));
                if (res.data && res.data.status) {
                    dispatch(setSuccess());
                    dispatch(loadTrades(res.data.data));

                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}

export const search = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.post(`${process.env.REACT_APP_API_URL}trade/search`,
            payload,
        )
            .then(res => {
                dispatch(setLoading(false));
                if (res.data && res.data.status) {
                    dispatch(setSuccess());
                    dispatch(loadTrades(res.data.data));

                } else {
                    message.error('Something went wrong');  
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}

export const getTradeById = (id) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.get(`${process.env.REACT_APP_API_URL}trade/${id}`,
        )
            .then(res => {
                dispatch(setLoading(false));

                if (res.data && res.data.status) {
                    dispatch(loadActiveTrade(res.data.data));
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}
export const getTradeQoutes = (id) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.get(`${process.env.REACT_APP_API_URL}trade/${id}/qoutes`,
        )
            .then(res => {
                dispatch(setLoading(false));

                if (res.data && res.data.status) {
                    dispatch(setQoutes(res.data.data));
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}
export const getTradePO = (id) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.get(`${process.env.REACT_APP_API_URL}po/trade/${id}`,
        )
            .then(res => {
                dispatch(setLoading(false));

                if (res.data && res.data.status) {
                    dispatch(setPO(res.data.data));
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}
export const getTradeHistory = payload => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.get(`${process.env.REACT_APP_API_URL}trade/history/trade/${payload}`)
            .then(res => {
                dispatch(setLoading(false));
                if (res) {
                    if (res.data && res.data.status) {
                        dispatch(setLoading(false));
                        dispatch(setTradeHistory(res.data.data));
                    }
                    else {
                        message.error(res.data.errors[0].msg);
                        dispatch(setLoading(false));
                        dispatch(setError(res.data.errors));
                    }
                   
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}

export const deleteTrade = (id, history) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.delete(`${process.env.REACT_APP_API_URL}/trades/${id}`,
        )
            .then(res => {
                dispatch(setLoading(false));
                if (res.status === 200) {
                   
                    if (!res.data.errors) {
                        dispatch(deleteTrades(id));
                        // dispatch(getLicence());
                        message.success('Trade Deleted successfully');
                    }
                    else {
                        message.error(res.data.errors[0].msg);
                        dispatch(setLoading(false));
                        dispatch(setError(res.data.errors));
                    }
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}

export const getTransit = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.get(`${process.env.REACT_APP_API_URL}transit/trade/${payload}` )
            .then(res => {
                dispatch(setLoading(false));
                if (res.data && res.data.status) {
                        dispatch(getTransitSuccess(res.data.data));
                    }
                    else {
                        message.error(res.data.errors[0].msg);
                        dispatch(setLoading(false));
                        dispatch(setError(res.data.errors));
                    }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}
export const getPayment = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.get(`${process.env.REACT_APP_API_URL}payment/trade/${payload}` )
            .then(res => {
                dispatch(setLoading(false));
                if (res.data && res.data.status) {
                        dispatch(setPaymentSuccess(res.data.data));
                    }
                    else {
                        message.error(res.data.errors[0].msg);
                        dispatch(setLoading(false));
                        dispatch(setError(res.data.errors));
                    }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}
export const approveOrReject = (id,payload, history, sync=false,pathname) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.put(`${process.env.REACT_APP_API_URL}trade/approveOrReject/${id}` ,payload)
            .then(res => {
                dispatch(setLoading(false));
                if (res.data && res.data.status) {
                         message.success('Trade updated successfully');
                         history.push({
                            pathname: `/trades/`
                        });
                        // dispatch(setPaymentSuccess(res.data.data));
                        // if(!sync && history){
                        //     history.push({
                        //         pathname: `${pathname}`
                        //     });
                        // }
                        // if(sync){
                        //     dispatch(updateSync());
                        // }
                        
                    }
                    else {
                        message.error('Something went wrong');
                    }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}

export const modalInit = (payload) => {
    return dispatch => {
        dispatch(modalOpned(payload));
    }
}