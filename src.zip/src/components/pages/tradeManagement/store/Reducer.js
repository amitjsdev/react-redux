import * as ActionTypes from './ActionTypes';

const initialState = {
    data: [],
    qoutes: [],
    poData: [],
    activeTrade: null,
    loading: false,
    loaded: false,
    error: {},
    licence: null,
    count: undefined,
    modalCloseOnSuccess: false,
    transitData: undefined,
    paymentData: [],
    sync:undefined,
    historyData:[]

}

export default (state = initialState, { type, payload }) => {
    switch (type) {

        case ActionTypes.LOAD_TRADES:
            return { ...state, data: payload.data ? payload.data : [], count: payload.count ? payload.count : undefined }
        case ActionTypes.SET_QOUTES_TRADE:
            return { ...state, qoutes: payload }
        case ActionTypes.SET_PO:
            return { ...state, poData: payload }
        case ActionTypes.SET_TRANSIT_DATA:
            return { ...state, transitData: payload }
        case ActionTypes.SET_PAYMENT_DATA:
            return { ...state, paymentData: payload }
        case ActionTypes.SET_TRADE_HISTORY:
            return { ...state, historyData: payload }
        case ActionTypes.UPDATE_SYNC:
                    return { ...state, sync: (new Date()).getTime() }

        case ActionTypes.MODAL_INIT:
            return { ...state, modalCloseOnSuccess: payload }

        case ActionTypes.LOAD_TRADES_SUCCESS:
            return { ...state, loaded: true }

        case ActionTypes.LOAD_TRADES_FAILURE:
            return { ...state, error: payload, modalCloseOnSuccess: false }

        case ActionTypes.TRADES_LOADING:
            return { ...state, loading: payload }

        case ActionTypes.LOAD_ACTIVE_TRADE:
            return { ...state, activeTrade: payload }

        case ActionTypes.DELETE_TRADE: {
            let data = [...state.data];
            data = data.map(trade => {
                if (trade.id === payload) {
                    trade.status = false;
                }
                return trade;
            }
            )
            return { ...state, data, modalCloseOnSuccess: true }
        }
        case ActionTypes.UPDATE_TRADE: {
            let data = [...state.data];
            data = data.map(trade => {
                if (trade.id === payload.id) {
                    return payload;
                } else {
                    return trade;
                }

            }
            )
            return { ...state, data, modalCloseOnSuccess: true }
        }



        case ActionTypes.ADD_TRADE: {
            let data = [...state.data];
            data.unshift(payload);
            return { ...state, data, modalCloseOnSuccess: true };
        }

        default:
            return state;
    }
}
