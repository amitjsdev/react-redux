
import React, { useEffect } from 'react'
import { Spin } from 'antd'
import DateFormat from '../../common/DateFormat'
import { formattedDate } from '../../common/util'
import { Table } from 'antd'

const Transit = ({ data, id, loading, getData, }) => {
    useEffect(() => {
        getData(id)
    }, [id])


    const columns = [
        {
            title: 'Sr. No',
            dataIndex: 'id'
        },
        {
            title: 'Qoute ID',
            dataIndex: 'qid'
        },
        {
            title: 'Qoute Price',
            dataIndex: 'qt',
            render:qt=>qt && qt.price ? qt.price :''
        },
        {
            title: 'Tracking Number',
            dataIndex: 'tracking_number'
        },
         {
            title: 'Vehical Number',
            dataIndex: 'vehical'
        }, 
        
        {
            title: 'Expected Date',
            dataIndex: 'expected',
            render:date=><DateFormat date={date} />
        }, 
        {
            title: 'Initiated Date',
            dataIndex: 'initiated',
            render:date=><DateFormat date={date} />
        }, 
        {
            title: 'Delivery Date',
            dataIndex: 'delivery_date',
            render:date=><DateFormat date={date} />
        }, 
        {
            title: 'Canceled Date',
            dataIndex: 'canceledAt',
            render:date=><DateFormat date={date} />
        }, 
        {
            title: 'Status',
            dataIndex: 'statusStr',
        },
    ]

    const expandedRowRender = ({TransitHistories}) => {
        const columns = [
            {
                title: 'Comment',
                dataIndex: 'comment'
            },
             {
                title: 'Tracking Number',
                dataIndex: 'tracking_number'
            },
             {
                title: 'Vehical Number',
                dataIndex: 'vehical'
            }, 
            
            {
                title: 'Expected Date',
                dataIndex: 'expected',
                render:date=><DateFormat date={date} />
            }, 
           
            {
                title: 'Delivery Date',
                dataIndex: 'delivery_date',
                render:date=><DateFormat date={date} />
            }, 
            {
                title: 'Canceled Date',
                dataIndex: 'canceledAt',
                render:date=><DateFormat date={date} />
            }, 
            {
                title: 'Status',
                dataIndex: 'statusStr',
            },
        
        ];
        return <Table columns={columns} dataSource={TransitHistories} pagination={false} rowKey={rc=>rc.id}/>;
      };

    return <>
        {loading ? <Spin /> : <Table
            columns={columns}
            rowKey={rc=>rc.id}
            dataSource={data}
            loading={loading}
            expandable={{ expandedRowRender }}
            pagination={{ hideOnSinglePage: true }}
        /> 
}
</>
}
export default Transit
