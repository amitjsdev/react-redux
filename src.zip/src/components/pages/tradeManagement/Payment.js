
import React, { useEffect } from 'react'
import { Card, Spin } from 'antd'
import DateFormat from '../../common/DateFormat'
import { formattedDate } from '../../common/util'
import { Table } from 'antd'

const Payment = ({ data, id, loading, getData, }) => {
    useEffect(() => {
        getData(id)
    }, [id])


    const columns = [
        {
            title: 'Sr. No',
            dataIndex: 'id'
        },
        {
            title: 'Qoute ID',
            dataIndex: 'qid'
        },
        {
            title: 'Amount',
            dataIndex: 'amount',
        },
        {
            title: 'Commision',
            dataIndex: 'commision'
        },
         {
            title: 'Tax',
            dataIndex: 'tax'
        }, 
          {
            title: 'Total',
            dataIndex: 'total'
        }, 
        
      
        {
            title: 'Created Date',
            dataIndex: 'createdAt',
            render:date=><DateFormat date={date} />
        }, 
          {
            title: 'Updated Date',
            dataIndex: 'updatedAt',
            render:date=><DateFormat date={date} />
        }, 
        {
            title: 'Status',
            dataIndex: 'statusStr',
        },
    ]

    const expandedRowRender = ({transactions}) => {
        const columns = [
            {
                title: 'Transaction Id',
                dataIndex: 'id',
                render:(id, record)=> id && record && record.tId ? `${id}TIM${record.tId}`:''
            },
             {
                title: 'Mode',
                dataIndex: 'mode'
            },
             {
                title: 'Transaction status',
                dataIndex: 'transaction_status'
            }, 
            {
                title: 'Qoute Id',
                dataIndex: 'qId',
            },
            {
                title: 'Created Date',
                dataIndex: 'createdAt',
                render:date=><DateFormat date={date} />
            }, 
              {
                title: 'Updated Date',
                dataIndex: 'updatedAt',
                render:date=><DateFormat date={date} />
            }, 
        
        ];
        return <Table columns={columns} dataSource={transactions} rowKey={rc=>rc.tId}
        //  expandable={{expandedRowRender:expandedRowRender2}}  
         pagination={false} />;
      };
      const expandedRowRender2 = ({meta}) => {
          return <Card>
                  Payu Response:
              {meta}
          </Card>
      };
    return <>
        {loading ? <Spin /> : <Table
            rowKey={rc=>rc.id}
            columns={columns}
            dataSource={data}
            loading={loading}
            expandable={{ expandedRowRender }}
            pagination={{ hideOnSinglePage: true }}
        /> 
}
</>
}
export default Payment
