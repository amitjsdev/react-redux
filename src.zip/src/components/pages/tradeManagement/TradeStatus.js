import React from 'react';
import { connect } from 'react-redux';
const TradeStatus = ({st,data}) => {
    const status = data && data.status &&  data.status.trade  ? data.status.trade :undefined;
    //console.log('status',st,status);
    const myStatus = st;
    // const myStatus = ''
    const className =myStatus ? myStatus.replace(/\s/g, "_"):'';
    return (<span className={`test status ${className.toLowerCase()}`}>{myStatus}</span>)
}
const mapStateToProps = state => ({
    data: state.app.data,
});

const mapDispatchToProps = dispatch => ({
   
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(TradeStatus);

