
import React, { useEffect } from 'react'
import { Spin } from 'antd'
import DateFormat from '../../common/DateFormat'
import { formattedDate } from '../../common/util'
import { Table } from 'antd'

const PODetail = ({ data, id, loading, getData, }) => {
    useEffect(() => {
        getData(id)
    }, [id])


    const columns = [
        {
            title: 'Sr. No',
            dataIndex: 'id'
        },
        {
            title: 'Qoute ID',
            dataIndex: 'qid'
        },
        {
            title: 'Qoute Price',
            dataIndex: 'qt',
            render:qt=>qt && qt.price ? qt.price :''
        },
        {
            title: 'Total',
            dataIndex: 'total'
        },
         {
            title: 'Tax',
            dataIndex: 'taxTotal'
        }, 
         {
            title: 'Platform Charge',
            dataIndex: 'platformCharge'
        },
        {
            title: 'Accepted Date',
            dataIndex: 'acceptedAt',
            render:date=><DateFormat date={date} />
        }, 
        {
            title: 'Rejected Date',
            dataIndex: 'rejectedAt',
            render:date=><DateFormat date={date} />
        }, 
        {
            title: 'Submitted Date',
            dataIndex: 'submittedAt',
            render:date=><DateFormat date={date} />
        }, 
        {
            title: 'Canceled Date',
            dataIndex: 'canceledAt',
            render:date=><DateFormat date={date} />
        }, 
        {
            title: 'Status',
            dataIndex: 'statusStr',
        },
    ]

    return <>
        {loading ? <Spin /> : <Table
            columns={columns}
            dataSource={data}
            loading={loading}
            pagination={{ hideOnSinglePage: true }}
        /> 
}
</>
}
export default PODetail
