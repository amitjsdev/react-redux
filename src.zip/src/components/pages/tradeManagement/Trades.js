import { Input, Select, DatePicker, Space,Pagination  } from 'antd';
import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import DashboardLayout from "../../Layout/DashboardLayout";
import { getTrades,search } from './store/Actions'
import TradeList from './TradeList';
import { useLocation } from 'react-router-dom';
import moment from 'moment';
const { RangePicker } = DatePicker;
const { Option } = Select;
const Trades = (props) => {
    const search = useLocation().search;
    const pathname = useLocation().pathname;
    let { data, count, loading, app } = props;

    let commodities = app && app.commodities ? app.commodities : [];
    let status = app && app.status && app.status.trade ? app.status.trade : [];

    const [selectedCommodities, setCommodity] = useState([])
    const [selectedStatus, setStatus] = useState([])
    const [range, setRange] = useState([null, null])
    const [searchFilter, setSearchFilter] = useState([])
    const detailPage = new URLSearchParams(search).get("detailPage");
    const [currentPage, setCurrentPage] = useState(1)

    useEffect(() => {
        if(!!detailPage){
            
            let searchParams ={
                limit:10, offset:0
            }

            let from_date = localStorage.getItem('fromDate');
            let to_date = localStorage.getItem('toDate');
            let commodityIdData;
            if(!!localStorage.getItem('commodityId')){
                commodityIdData =  localStorage.getItem('commodityId').split(',').map(x=>+x);
                setCommodity(commodityIdData);
            }
            let statusData;
            if(!!localStorage.getItem('tradeStatus')){
             statusData = localStorage.getItem('tradeStatus').split(',');
             setStatus(statusData);

            }
           
          
            if(!!from_date && !!to_date){
                setRange([moment(from_date),moment(to_date)]);
                searchParams ={...searchParams, fromDate:from_date, toDate:to_date}  
            }
            if(!!commodityIdData){
                searchParams ={...searchParams, commodityId: commodityIdData}  
            }
            if(!!statusData){
                searchParams ={...searchParams, status: statusData}  
            }
            setSearchFilter(searchParams)
        }else{
            props.search({status:[0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,99],offset:0,limit:10})

        }
    }, []);

    useEffect(() => {
if(searchFilter?.commodityId && searchFilter?.commodityId.length > 0 || searchFilter?.status && searchFilter?.status.length > 0 ){
    props.search(searchFilter)

}

    }, [searchFilter]);


    const resetFilter = (e) => {
        window.history.pushState('',
        "", pathname);
            localStorage.setItem('commodityId','')
            localStorage.setItem('tradeStatus','')
            localStorage.setItem('fromDate','')
            localStorage.setItem('toDate','')

        e.preventDefault()    
        setStatus([]);
        setCommodity([])
        setRange([null, null])
        props.search({status:[0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,99],offset:0,limit:10})

    }
    const [offset, setOffSet] = useState(0);

    const doSearchHandler = (e) => {
            e.preventDefault() 
            doSearch(0)
            }
    const doSearch = (newOffset=offset) => {    
        if(newOffset == 0){
            setCurrentPage(1)     
        }                    
        let searchParams ={
            status:selectedStatus,commodityId: selectedCommodities,
            limit:10, offset:newOffset
        }
        if(range && range[0] && range[1]){
            searchParams ={...searchParams, fromDate:range[0], toDate:range[1]}  
        }
        if(!!searchParams?.commodityId){
            localStorage.setItem('commodityId',selectedCommodities)
        }
        if(!!searchParams?.status){
            localStorage.setItem('tradeStatus',searchParams.status)
        }
        if(!!searchParams?.fromDate && !!searchParams?.toDate){
            localStorage.setItem('fromDate',range[0])
            localStorage.setItem('toDate',range[1])
        }
       props.search(searchParams)
    }
    const itemRender=(current, type, originalElement) =>{
        if (type === 'prev') {
          return <a className="page-link" >Previous</a>;
        }
        if (type === 'next') {
          return <a className="page-link" >Next</a>;
        }
        return originalElement;
      }

      const paginationChange =(page, pageSize)=>{
        setCurrentPage(page)   
          const newOffset =(page-1)*pageSize;
          setOffSet(newOffset);
        doSearch(newOffset) 
          
      }

    return (
        <div>
            <DashboardLayout>
                <div class="page-inner">
                    <div class="container-fluid">
                        <form name="form" >
                            <div class="row">
                                <div class="col-lg-12 card pt-3 pb-3 mb-3">
                                    <div class="font-weight-bold pb-2">Search By:</div>
                                    <div class="form-row">
                                        <div class="col-md-3 mb-3">
                                            <label for="validationDefaultUsername">Commodity Type</label>
                                            <div class="input-group">
                                                <Select
                                                    mode="multiple"
                                                    allowClear
                                                    style={{ width: '100%' }}
                                                    placeholder="Please select"
                                                    value={selectedCommodities}
                                                    onChange={setCommodity}

                                                >
                                                    
                                                    {commodities && commodities.length > 0 ? commodities.map(c =>
                                                        <option selected key={c.id} value={c.id}>{c.name}</option>
                                                    ) : null}
                                                </Select>

                                            </div>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <label for="validationDefaultUsername">Trade Request Status</label>
                                            <div class="input-group">

                                                <Select
                                                    mode="multiple"
                                                    allowClear
                                                    style={{ width: '100%' }}
                                                    placeholder="Please select"
                                                    value={selectedStatus}
                                                    onChange={setStatus}

                                                >
                                                    
                                                    {status && Object.values(status).length > 0 ? Object.values(status).map(c =>
                                                        <option key={c} value={c}>{c}</option>
                                                    ) : null}
                                                </Select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label className="col-md-12" for="validationDefault01">From Date - To Date</label>
                                            <Space direction="vertical" size={12}>
                                                <RangePicker format="DD/MM/YYYY"
                                                    value={range}
                                                    placeholder={['From Date', 'To Date']}
                                                    onChange={setRange}
                                                />
                                            </Space>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <button onClick={doSearchHandler} class="btn btn-green btn-top" type="submit">Search</button>
                                            <button onClick={resetFilter} style={{ marginLeft: '10px' }} class="btn btn-green btn-top" type="reset" >Clear</button>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="container-fluid pl-0 pr-0">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card pb-0 mb-0">
                                    <div class="card-body pb-2 pt-0">
                                        <div class="mb-3 pt-3"><a class="refreshBtn" onClick={doSearchHandler}><i class="fa fa-undo pr-2" aria-hidden="true"></i></a>
                                            <span class="infoText" >Request you to press the refress button to see the updated quote values</span></div>
                                        <div className="table-responsive tradeUsers">
                                            {/* <Input.Search
                                                style={{ margin: "0 0 10px 0", width: "auto" }}
                                                placeholder="Search by..."
                                                enterButton
                                                onSearch={search}
                                            /> */}

                                            <TradeList
                                                data={data}
                                                loading={loading}
                                            />
                                            <nav aria-label="Page navigation example">
                                            <Pagination total={count} itemRender={itemRender}
                                            className="pagination justify-content-end float-none"
                                            onChange={paginationChange}
                                            hideOnSinglePage={true}
                                            current={currentPage}
                                            />
                                            </nav>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </DashboardLayout>
        </div>

    )
}
const mapStateToProps = state => ({
    loading: state.trades.loading,
    loaded: state.trades.loaded,
    error: state.trades.error,
    // commodities: state.masterdata.commodities,
    app: state.app.data,
    data: state.tradesData.data,
    count: state.trades.count
});

const mapDispatchToProps = dispatch => ({
    getTrades: (payload) => dispatch(getTrades(payload)),
    search: (payload) => dispatch(search(payload)),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Trades);

