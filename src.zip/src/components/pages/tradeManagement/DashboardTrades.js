import React, { useEffect,useState } from 'react';
import { connect } from 'react-redux';
import { search,approveOrReject } from './store/Actions'
import TradeList from './TradeList'
import {Link,useHistory,useLocation} from 'react-router-dom';
import { Button, Form, Input, Modal, Space, Spin, Table, Radio } from "antd";
const DashboardTrades = (props) => {
    const history = useHistory();
    let pathname = useLocation().pathname;
    const [visible,setVisible] = useState(false);
    const [comment,setComment] = useState();
    const [type,setType] = useState();
    const [currentId,setCurrentId] = useState();
    useEffect(() => {
        props.search({ status: [1], limit: 5000000, offset: 0 })
    }, [props.sync]);

    useEffect(() => {
        //console.log('typetype',type,!!type)
        if(!!type){
            setVisible(true);
        }
        }, [type]);

    let { data, loading, count } = props;
    const approve = (e,id) => {
       
        setType('approved');
        e.preventDefault();
        setCurrentId(id);   
     }
    const reject = (e,id) => {
        e.preventDefault();
        setCurrentId(id);   
        setType('reject');
    }
    const onSubmit = () => {
        if (type === 'reject') {
            props.approveOrReject(currentId, {status:0,comment}, history, true,pathname)
            setVisible(false);
            // const payload = ({ limit, offset, roles, status });
            // dispatch(getUserList(payload));
        }
        else if (type === 'approved') {
            props.approveOrReject(currentId, {status:2,comment}, history, true,pathname)
            setVisible(false);
        }
    };

    const onCancel = () => {
        setType('')
        setVisible(false);
    }
    const [form] = Form.useForm();

    return (
        <>
            {/* {count > 5 ? <Link to="/trades/requests" className="viewAll font-weight-bold">View All</Link> : null} */}
           
            <Modal
                visible={visible}
                title={
                  type == "reject"
                    ? "Are you sure you want to reject this trade?"
                    : "Are you sure you want to approve this trade?"
                }
                okText="Submit"
                cancelText="Cancel"
                onCancel={() => {
                    form.resetFields(); 
                    onCancel();}}
                onOk={() => {
                  form
                    .validateFields()
                    .then((values) => {
                      form.resetFields();
                      onSubmit();
                    })
                    .catch((info) => {
                      //console.log("Validate Failed:", info);
                    });
                }}
              >
                <Form
                  form={form}
                  layout="vertical"
                  name="form_in_modal"
                  initialValues={{
                    modifier: "public",
                  }}
                >
                  <Form.Item
                    name="comment"
                    label="Comments"
                    rules={[
                      {
                        required: true,
                        message: "Field is required",
                      },
                    ]}
                  >
                    <Input onChange={(e)=>{
                      setComment(e.target.value)
                    }}/>
                  </Form.Item>
                </Form>
              </Modal>
               <TradeList
                data={data}
                loading={loading}
                action={true}
                approve={approve}
                reject={reject}
                dashboard={true}
            />
        </>


    )
}
const mapStateToProps = state => ({
    loading: state.trades.loading,
    data: state?.tradesData?.data,
    sync: state.trades.sync,
});

const mapDispatchToProps = dispatch => ({
    search: (payload) => dispatch(search(payload)),
    approveOrReject: (id,payload,history, sync,pathname) => dispatch(approveOrReject(id,payload,history,sync,pathname)),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(DashboardTrades);

