import DateFormat from '../../common/DateFormat'
import {formattedDate} from '../../common/util'
import React ,{useEffect} from 'react'
import {Table} from 'antd'
const Qoutes = ({ data, id, loading, getData,tradeStatus }) =>{
useEffect(()=>{
    getData(id)
},[id])
const columns = [
    {
        title: 'Sr. No',
        dataIndex: 'id'
    },
    {
        title: 'Seller Name',
        dataIndex: 'CreatedUser',
        render:user=> user ? `${user.first_name} ${user.last_name}`: ''

    },
    {
        title: 'Seller Price',
        dataIndex: 'price',
    },
    {
        title: 'Seller City',
        dataIndex: 'CreatedUser',
        render:a=> a && a.bAddress && a.bAddress.cityName ? a.bAddress.cityName :''
            
        
    },
    {
        title: 'Seller State',
        dataIndex: 'CreatedUser',
        render:a=> a && a.bAddress && a.bAddress.stateName ? a.bAddress.stateName :''
    },
    {
        title: 'Seller Quote Date',
        dataIndex: 'createdAt',
        render:date=><DateFormat date={date} />
    }, 
    {
        title: 'Status',
        dataIndex: 'statusStr',
    },
]

return <Table 
columns={columns}
dataSource={data}
loading={loading}
pagination={{hideOnSinglePage:true}}
/>
}
export default Qoutes
