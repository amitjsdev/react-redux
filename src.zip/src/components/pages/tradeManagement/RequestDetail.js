import DateFormat from '../../common/DateFormat'
import {formattedDate} from '../../common/util'
const RequestDetail = ({ data ,historyData}) =>{
const address = (data.buyer && data.buyer.bAddress) ? data.buyer?.bAddress :null;
const history =historyData
return <div role="tabpanel" class="tab-pane active" id="tab1">
        <form style={{ padding: "0.8rem 1rem" }}>
            <fieldset class="scheduler-border">
                <legend class="scheduler-border">Request Detail</legend>
                <div class="form-row">
                    <div class="col-md-3 mb-2">
                        <label>Commodity Item</label>
                        <input type="text" class="form-control" placeholder="Chana" value={data && data.commodity ? data.commodity.name : ''} disabled />
                    </div>
                    <div class="col-md-3 mb-2">
                        <label>Item QTY</label>
                        <input type="text" class="form-control" value={`${data?.quantity} ${data?.unit?.name}`}  disabled />
                    </div>
                    <div class="col-md-3 mb-2">
                        <label>Description</label>
                        <div class="input-group">
                            <input type="text" class="form-control"
                                placeholder="Indian Black Chana" value={data && data.commodity ? data.commodity.description : ''} disabled />
                        </div>
                    </div>
                    <div class="col-md-3 mb-2">
                        <label>Expected Live Date</label>
                        <div class="input-group">
                        <input type="text" class="form-control"disabled 
                         value ={formattedDate(data ? data.broadcastDate :null,"N/A")} />
                            
                        </div>
                    </div> 
                    <div class="col-md-3 mb-2">
                        <label>Closure Date</label>
                        <div class="input-group">
                        <input type="text" class="form-control"disabled 
                         value ={formattedDate(data ? data.closeDate :null,"N/A")} />
                            
                        </div>
                    </div>
                </div>
            </fieldset>
            <fieldset class="scheduler-border">
                <legend class="scheduler-border">Trade Information</legend>
                <div class="form-row">
                    <div class="col-md-4 mb-2">
                        <label>Total No. of Quotes</label>
                        <input type="text" class="form-control" value={data.total ? data.total :0} disabled />
                    </div>
                    <div class="col-md-4 mb-2">
                        <label>Low Quote Value</label>
                        <input type="text" class="form-control" value={data.minPrice ? data.minPrice :0}  disabled />
                    </div>
                    <div class="col-md-4 mb-2">
                        <label>High Quote Value</label>
                        <div class="input-group">
                            <input type="text" class="form-control" value={data.maxPrice ? data.maxPrice :0} 
                                disabled />
                        </div>
                    </div>
                </div>
            </fieldset>
            <fieldset class="scheduler-border">
                <legend class="scheduler-border">Buyer Information</legend>
                <fieldset class="scheduler-border">
                    <div class="form-row pt-3">
                        <div class="col-md-3 mb-2">
                            <label>First Name</label>
                            <input type="text" class="form-control"
                            value={ data.buyer && data.buyer.first_name ? data.buyer.first_name  : ''}
                                disabled />
                        </div>
                        <div class="col-md-3 mb-2">
                            <label>Last Name</label>
                            <input type="text" class="form-control" 
                            value={ data.buyer && data.buyer.last_name ? data.buyer.last_name  : ''} disabled />
                        </div>
                        <div class="col-md-3 mb-2">
                            <label>Email ID</label>
                            <div class="input-group">
                                <input type="text" class="form-control"
                                    placeholder="value_harvest@gmail.com" 
                                    value={ data.buyer && data.buyer.email ? data.buyer.email  : ''} 
                                     disabled />
                            </div>
                        </div>
                        <div class="col-md-3 mb-2">
                            <label>Mobile Number</label>
                            <div class="input-group">
                                <input type="text" class="form-control" 
                                value={ data.buyer && data.buyer.mobile ? data.buyer.mobile  : ''} 
                                disabled />
                            </div>
                        </div>
                    </div>
                </fieldset>
                <fieldset class="scheduler-border">
                    <legend class="scheduler-border">Business Address</legend>
                    <div class="address-container">
                        <div class="form-row">
                            <div class="col-md-4 mb-2">
                                <label>Address 1</label>
                                <input type="text" class="form-control" 
                                value={ address && address.address1 ? address.address1  : ''} 
                                    disabled />
                            </div>
                            <div class="col-md-4 mb-2">
                                <label>Address 2</label>
                                <div class="input-group">
                                    <input type="text" class="form-control"
                                    value={ address && address.address2 ? address.address2  : ''}  disabled />
                                </div>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label>City</label>
                                <div class="input-group">
                                <input type="text" class="form-control"
                                    value={ address && address.cityName ? address.cityName  : ''}  disabled />
                                </div>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label>State</label>
                                <div class="input-group">
                                <input type="text" class="form-control"
                                    value={ address && address.stateName ? address.stateName  : ''}  disabled />
                                </div>
                            </div>
                            <div class="col-md-4 mb-2">
                                <label>Zip Code</label>
                                <input type="text" class="form-control" value={ address && address.zip ? address.zip  : ''}
                                    disabled />
                            </div>
                            <div class="col-md-4 mb-2">
                                <label>Country</label>
                                <div class="input-group">
                                <input type="text" class="form-control" value={ address && address.countryName ? address.countryName  : ''}
                                    disabled />
                                </div>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </fieldset>
        </form>
        <div class="container-fluid pl-0 pr-0 pb-0">
            <h2 class="display-h2 heading-bg">Approver History</h2>
            <div class="dataTable-panel pb-0">
                <div class="row ml-0 mr-0">
                    <div class="table-responsive">
                        <table id="document_history_list_container"
                            class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Sr. No</th>
                                    <th>Modified By</th>
                                    <th>Current Status</th>
                                    <th>Comments</th>
                                    {/* <th>Forward To</th> */}
                                    <th>Modified Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {history && history.length > 0 ? history.map(h=>
                                <tr id={h.id}>
                                    <td>{h.id}</td>
                                    <td>{h.CreatedUser ? `${h.CreatedUser.first_name} ${h.CreatedUser.last_name}` : ''}</td>
                                    <td><span class={`status ${h.newData.toLowerCase()}`}>{h.newData}</span></td>
                                    <td>{h.comment}</td>
                                    {/* <td>{h.CreatedUser ? `${h.CreatedUser.first_name} ${h.CreatedUser.last_name}` : ''}</td> */}
                                    <td><DateFormat date={h.createdAt}  el=""/></td>
                                </tr>
                                ): null}
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
}
export default RequestDetail
