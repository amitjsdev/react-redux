import { Input, message, Space, Spin, Table } from 'antd';
import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { Link, useLocation } from 'react-router-dom';
import DateFormat from '../../common/DateFormat'
import TradeStatus from './TradeStatus';
const TradeList = ({ data, loading, action, approve, reject , dashboard}) => {
    const pathname = useLocation().pathname
    // if(!pathname){
    // let pathVal = home;
    // }
    function itemRender(current, type, originalElement) {
        if (type === 'prev') {
            return <a>Previous</a>;
        } else if (type === 'next') {
            return <a>Next</a>;
        }
        return originalElement;
    }
    const columns = [
        {
            title: 'Sr.No',
            dataIndex: 'id',
            key: 'id'
        },
        {
            title: 'Commodity',
            dataIndex: 'commodity',
            key: 'commodity',
            render: (item) => {
                return item.name;
            }
        },
        {
            title: 'Title',
            dataIndex: 'title',
            key: 'title'
        },
        // {
        //     title: 'Description',
        //     dataIndex: 'description',
        //     key: 'description',
        // },
        {
            title: 'Qty',
            dataIndex: 'quantity',
            key: 'quantity',
            render: (qty, record) => `${qty} ${record?.unit?.name}`
        },
        {
            title: 'Created By',
            dataIndex: 'CreatedUser',
            key: 'CreatedUser',
            render: (item) => {
                return item.first_name;
            }
        },
        {
            title: 'Create Date',
            dataIndex: 'createdAt',
            key: 'createdAt',
            render: date => <DateFormat date={date} />
        },
        {
            title: 'Expected Live Date',
            dataIndex: 'broadcastDate',
            key: 'broadcastDate',
            render: date => <DateFormat date={date} el="N/A" />
        },
        {
            title: 'Closure Date',
            dataIndex: 'closeDate',
            key: 'closeDate',
            render: date => <DateFormat date={date} el="N/A" />
        },

        {
            title: 'Status',
            className: 'statusRow',
            key: 'status',
            dataIndex: 'statusStr',
            render: (item) => {
                return <TradeStatus st={item} />;
            }
        },
        {
            title: 'Action',
            key: 'action',
            render: (item) =>

            (
                <ul class="list">
                    {action ? <>
                        <li><a href="#" onClick={e => reject(e, item.id)} title="Rejecte"><i class="fa fa-times-circle-o reject" aria-hidden="true"></i></a></li>

                        <li><a href="#" onClick={e => approve(e, item.id)} title="Approve"><i class="fa fa-check-circle-o approve" aria-hidden="true"></i></a></li>
                        {dashboard ?    <li><Link title="View" to={`/user-trade-detail/${item.id}`}><i class="fa fa-eye"></i></Link></li>: 
                        <li><Link title="View" to={`/trades/${item.id}`}><i class="fa fa-eye"></i></Link></li>}
                    </>
                        :
                        <li><Link title="View" to={`/trades/${item.id}`}><i class="fa fa-eye"></i></Link></li>
                    }
                </ul>
            ),
        },
    ];
    return (
        <Table
            pagination={{ pageSize: 5 }}
            loading={loading}
            className="table"
            columns={columns}
            dataSource={data}
            itemRender={itemRender}
        />

    )
}
export default TradeList
