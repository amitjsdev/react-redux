import { Tabs } from 'antd';
import React, { useEffect, useState } from 'react';
import { Link, useHistory,useLocation } from "react-router-dom";
import { connect } from 'react-redux';
import DashboardLayout from "../../Layout/DashboardLayout";
import { getTradeById,getTradeHistory, search, getTradeQoutes, getTradePO, getTransit, getPayment, approveOrReject } from './store/Actions'
import RequestDetail from './RequestDetail'
import Qoutes from './Qoutes';
import PODetail from './PODetail';
import Transit from './Transit';
import Payment from './Payment';
import { data } from 'jquery';
import DateFormat from '../../common/DateFormat';

const { TabPane } = Tabs;


const TradeDetail = (props) => {
    const history = useHistory();
    const search = useLocation().search;
        const url = new URLSearchParams(search).get("url");
    const { match: { params: { id, edit } } } = props;
    const [showComment, setVisibility] = useState(false)
    const [error, setError] = useState('')
    const [comment, setComment] = useState('')
    const [approveOrRejectStatus, approveOrRejectStatusSet] = useState(undefined)
    const status = {
        0: 'Pending', 1: 'Approved', 2: 'Rejected', 3: 'Deleted'
    }
    let tradeStatus = props.app && props.app.status && props.app.status.trade ? props.app.status.trade : [];
    useEffect(() => {
        props.getTradeById(id)
        props.getTradeHistory(id)
        setError('')
        setVisibility(false)
        setComment('')
        approveOrRejectStatusSet(undefined)

    }, [id, edit]);

    useEffect(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });

        if(!!url){
                localStorage.setItem('currentUrl',url)
        }
        if (props.data && (props.data.status == 1 || props.data.status == 2)) {
            props.history.push(`/trades/${id}`)
        }

    }, [props.data]);


    const onChange = (e) => {
        setComment(e.target.value)
        if (e.target.value) {
            setError('')
        }
    }
    const commentHandler = (e) => {
        e.preventDefault();
        if (comment) {
            props.approveOrReject(id, { status: approveOrRejectStatus, comment }, props.history)
        } else {
            setError('Enter comment')
        }


    }

    const approve = (e) => {
        e.preventDefault();
        setVisibility(true)
        approveOrRejectStatusSet(1)
    }
    const reject = (e) => {
        e.preventDefault();
        setVisibility(true)
        approveOrRejectStatusSet(2)
    }
    //go back function
    const PreviousPage = (e) => {
        let from_date = localStorage.getItem('fromDate');
        let to_date = localStorage.getItem('toDate');
        let commodityId = localStorage.getItem('commodityId');
        let status = localStorage.getItem('tradeStatus');
        let currentUrl = localStorage.getItem('currentUrl');
        if(currentUrl == '/trades'){
            if(from_date == '' && to_date == '' && commodityId ==='' && status == ''){
                history.push({
                    pathname: `/trades`
                });
            }else{
                history.push({
                    pathname: `/trades`,
                    search: `detailPage=${e}`
                });
            }
        }else{
            history.push({
                pathname: `/`,
            });
        }
   
    }

    return (
        <div>
            <DashboardLayout>
                {props.data && <div class="page-inner pt-2">

                    <div class="container-fluid pl-0 pr-0">
                        <div class="detail-panel" style={{ overflow: 'hidden' }}>
                            <div class="row card-gutter ml-0 mr-0">
                                <div class="headTitle pt-3">
                                    <h2 class="screenName">Trade Details</h2>
                                </div>
                                <div className="backBtnDiv"><button onClick={() => { PreviousPage(props.data.id) }} className="backBtn">Go Back</button></div>


                                {/* <div className="headTitle pt-3"><h2 className="screenName">User Management Details</h2></div> */}
                                {/* <div className="backBtnDiv"><button onClick={() => { PreviousPage(usersDetails?.id) }} className="backBtn">Go Back</button></div> */}


                                <ul class="actionList">
                                    <li>
                                        <h3 class="h3">ID: <span>{props.data.id}</span></h3>
                                    </li>
                                    {/* {edit ? <>
                                        <li><a href="#" onClick={approve} class="comment_box" title="Approve"><i class="fa fa-check-circle-o approve" aria-hidden="true"></i>Approve</a></li>
                                        <li><a href="#" onClick={reject} class="comment_reject" title="Reject"><i class="fa fa-times-circle-o reject" aria-hidden="true"></i>Reject</a></li>
                                    </>
                                        :
                                        <>
                                            {
                                                props.data.status == 1 ?
                                                    <li><a href="#" class="comment_box" title="Approve"><i class="fa fa-check-circle-o approve" aria-hidden="true"></i>Approved</a></li>
                                                    : props.data.status == 2 ? <li><a href="#" class="comment_reject" title="Reject"><i class="fa fa-times-circle-o reject" aria-hidden="true"></i>Rejected</a></li>
                                                        : null
                                            }
                                        </>
                                    } */}
                                    {!edit ?
                                        <li>
                                            {tradeStatus && tradeStatus[props.data.status] && <a title="Status">Request Status: <span
                                                class={`status ${tradeStatus[props.data.status].toLowerCase()}`}> {props.data.statusStr}</span></a>
                                            }
                                        </li> : null
                                    }

                                    <li class="last">Request Close Date: <br /><span class="titleName">
                                        <DateFormat date={props.data.close_date} el="N/A" />
                                    </span>
                                    </li>
                                    <li class="last">Created Date: <br /><span class="titleName">
                                        <DateFormat date={props.data.createdAt} el="N/A" />
                                    </span></li>
                                </ul>
                                <div id="comment_box" class="comment-box" style={{ display: showComment ? 'block' : 'none' }}>
                                    <form >
                                        <div class="form-row">
                                            <div class="col-md-10 mb-2">
                                                <label>Comments</label>
                                                <textarea type="text" value={comment} name="comments" onChange={onChange} className={`form-control ${error ? 'is-invalid' : ''}`} rows="1" placeholder="Your comment here..."></textarea>
                                                <div className="invalid-feedback">{error}</div>
                                            </div>
                                            <div class="col-md-2 mb-2">
                                                <button onClick={commentHandler} class="btn btn-green btn-top w-100" type="submit">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="card-gutter ml-0 mr-0">
                                <div class="col-lg-12">

                                    <Tabs defaultActiveKey="1" >
                                        <TabPane tab="Request Detail" key="1">
                                            <RequestDetail data={props.data} historyData={props.historyData} />
                                        </TabPane>
                                        <TabPane tab="Quote Detail" key="2">
                                            <div role="tabpanel" class="tab-pane" id="tab2">
                                                <Qoutes data={props.qoutesData} loading={props.loading} id={id} getData={props.getTradeQoutes} tradeStatus={tradeStatus} />
                                            </div>
                                        </TabPane>
                                        <TabPane tab="PO Detail" key="3">
                                            <PODetail
                                                data={props.poData}
                                                loading={props.loading}
                                                id={id}
                                                getData={props.getTradePO}
                                            />
                                        </TabPane>
                                        <TabPane tab="Transit Detail" key="4">
                                            <Transit
                                                data={props.transitData}
                                                loading={props.loading}
                                                id={id}
                                                getData={props.getTransit}
                                            />
                                        </TabPane>
                                        <TabPane tab="Payment Detail" key="5">
                                            <Payment
                                                data={props.paymentData}
                                                loading={props.loading}
                                                id={id}
                                                getData={props.getPayment}
                                            />

                                        </TabPane>

                                    </Tabs>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>}
            </DashboardLayout>
        </div>
    )
}
const mapStateToProps = state => ({
    loading: state.tradesData.loading,
    loaded: state.tradesData.loaded,
    error: state.tradesData.error,
    app: state.app.data,
    data: state.tradesData.activeTrade,
    poData: state.tradesData.poData,
    count: state.tradesData.count,
    qoutesData: state.tradesData.qoutes,
    transitData: state.tradesData.transitData,
    paymentData: state.tradesData.paymentData,
    historyData: state.tradesData.historyData,
});

const mapDispatchToProps = dispatch => ({
    getTradeById: (id) => dispatch(getTradeById(id)),
    getTradeQoutes: (id) => dispatch(getTradeQoutes(id)),
    getTradePO: (id) => dispatch(getTradePO(id)),
    getTransit: (id) => dispatch(getTransit(id)),
    getPayment: (id) => dispatch(getPayment(id)),
    getTradeHistory: (id) => dispatch(getTradeHistory(id)),
    search: (payload) => dispatch(search(payload)),
    approveOrReject: (id, payload, history) => dispatch(approveOrReject(id, payload, history)),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(TradeDetail);