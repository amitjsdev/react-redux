import { Table } from 'antd';
import React from 'react';
import { Link } from 'react-router-dom';
import DateFormat from '../../common/DateFormat'
import Image from '../../common/Image'
const List = ({ data, loading, deleteItem }) => {
    function itemRender(current, type, originalElement) {
        if (type === 'prev') {
            return <a>Previous</a>;
        } else if (type === 'next') {
            return <a>Next</a>;
        }
        return originalElement;
    }
    const columns = [
        {
            title: 'ID',
            dataIndex: 'id',
            key: 'id'
        },
        {
            title: 'Picture',
            dataIndex: 'EntityFile',
            key: 'EntityFile',
            render: item => <Image data={item} />
        },
        {
            title: 'Item Name',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: 'Min. Price',
            dataIndex: 'min_price',
            key: 'min_price',
        },
        {
            title: 'Max. Price',
            dataIndex: 'max_price',
            key: 'max_price',
        },
        {
            title: 'Nodal Price',
            dataIndex: 'nodal_price',
            key: 'nodal_price',
        },
        {
            title: 'Create Date',
            dataIndex: 'createdAt',
            key: 'createdAt',
            render: date => <DateFormat date={date} />
        },
       
        {
            title: 'Status',
            key: 'status',
            dataIndex: 'status',
            render: status =>

            (
                <>
                    <span className={status == 0 ? 'status rejected' : 'status approved'}>{status == 0 ? 'InActive' : status == 1 ? 'Active':''}</span>

                </>
            ),
        },
        {
            title: 'Action',
            key: 'action',
            render: (item) =>

            (
                <ul class="list">
                    <li><Link title="View" to={`/commodity/${item.id}`}><i class="fa fa-eye"></i></Link></li>
                    <li><Link title="Edit" to={`/commodity/${item.id}/edit`}><i class="fa fa-edit"></i></Link></li>
                   <li><Link title="Delete" to="#" onClick={e=>deleteItem(e, item.id)}><i class="fa fa-trash"></i></Link></li>
                  
                </ul>
            ),
        },
    ];
    return (
        <Table
            pagination={false}
            loading={loading}
            className="table"
            columns={columns}
            dataSource={data}
            itemRender={itemRender}
        />

    )
}
export default List
