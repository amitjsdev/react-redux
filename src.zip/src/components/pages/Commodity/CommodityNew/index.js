import { Form, Input, Button, Space, Spin } from 'antd';

import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom'
import { connect } from 'react-redux';
import DashboardLayout from "../../../Layout/DashboardLayout";
import { getCommodityById, addCommodity ,updateCommodity} from '../store/Actions'
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import DetailsNewForm from './DetailsNewForm'
import DateFormat from '../../../common/DateFormat';
const Commodity = (props) => {
    const { data } = props
    const [form] = Form.useForm();
    const { match: { params: { id, edit } } } = props;
    const [mode, setMode] = useState('new')
    useEffect(() => {
        if (id && id == 'new') {
            setMode('new')
        } 
    }, [id, edit]);

    const onFinish = (values) => {
            props.addCommodity(values, props.history)
    };
    const onSubmit = (e) => {
        e.preventDefault()
        //console.log({ form });
        form.submit()
    };

    const onFinishFailed = (errorInfo) => {
        //console.log('Failed:', errorInfo);
    };
    const onReset = (e) => {
        e.preventDefault()
        form.resetFields();
    };
    const initialValues = {
        name: data && data.name ? data.name : '',
        min_price: data && data.min_price ? data.min_price : '',
        max_price: data && data.max_price ? data.max_price : '',
        nodal_price: data && data.nodal_price ? data.nodal_price : '',
        description: data && data.description ? data.description : '',
        attributes: data && data.attributes ? JSON.parse( data.attributes) : '',
        certifications: data && data.certifications ? JSON.parse( data.certifications) : '',
    }

    
    return (
        <div>
            <DashboardLayout>
                {
                        <DetailsNewForm
                            data={data}
                            mode={mode}
                            onFinish={onFinish}
                            onFinishFailed={onFinishFailed}
                            onReset={onReset}
                            onSubmit={onSubmit}
                        />
                        
                }

            </DashboardLayout>
        </div>

    )
}
const mapStateToProps = state => ({
    loading: state.commodity.loading,
    loaded: state.commodity.loaded,
    error: state.commodity.error,
    data: state.commodity.activeCommodity,
});

const mapDispatchToProps = dispatch => ({
    getCommodityById: (payload) => dispatch(getCommodityById(payload)),
    addCommodity: (payload, history) => dispatch(addCommodity(payload,history)),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Commodity);

