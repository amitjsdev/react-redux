import { Form, Input, Button, Space,Spin, Upload } from 'antd';

import React, { useEffect, useState } from 'react';
import {Link} from 'react-router-dom'
import { MinusCircleOutlined, PlusOutlined,InboxOutlined } from '@ant-design/icons';
import DateFormat from '../../../common/DateFormat';
import Image from '../../../common/Image'
const DetailForm = ({onFinish,onFinishFailed, data, mode}) => {
    const [fileData, SetFileData] =useState(null) 
    const [form] = Form.useForm();
    useEffect(() => {
        form.resetFields();
    }, [data]);

    
    const normFile = (e) => {
        //console.log('Upload event:', e);
      
        if (Array.isArray(e)) {
          return e;
        }
      
        return e && e.fileList;
      };
      const fileToBase64 = async (file) =>
        new Promise((resolve, reject) => {
            const reader = new FileReader()
            reader.readAsDataURL(file)
            reader.onload = () => resolve(reader.result)
            reader.onerror = (e) => reject(e)
        })


      const onChangeFiles= async({file, files}) => {
        const imageStr = await fileToBase64(file)
        SetFileData({
            name:file.name,
            size:file.size,
            type:file.type,
           data:imageStr
        })
       
      }
      const onFinishHandler =(data)=>{
        onFinish({
            ...data,
            file:fileData
        })
      }
      console.log('datatatat',data)

      const attributes  = JSON.parse(data?.attributes);
      const certification  = JSON.parse(data?.certifications);
    return (<Form
                    name="basic"
                    form={form}
                    layout="vertical"
                    // initialValues={initialValues}
                    onFinish={onFinishHandler}
                    onFinishFailed={onFinishFailed}
                >
                    <div class="page-inner pt-2">
                        <div class="container-fluid pl-0 pr-0">
                            <div class="detail-panel">
                                <div class="row card-gutter ml-0 mr-0">
                                    {mode=='new' ? <div class="pt-3"><h2 class="screenName">Add Commodity</h2></div>:
                                    <div class="pt-3"><h2 class="screenName">Commodity Detail</h2></div>}
                                    <ul class="actionList" style={{padding:'0 10px'}}>
                                    {mode !='new' ? <li><h3 class="h3">ID: <span>{data ? data.id :''}</span></h3></li>: null }
                                        
                                        {(mode =='edit' || mode=='new')  ? <><li style={{ marginRight: '10px' }}>
                                            <Form.Item>
                                                <Button type="primary" htmlType="submit">
                                                    <i class="fa fa-save" style={{ marginRight: '5px' }}></i>Save
                                                </Button>
                                            </Form.Item>
                                        </li>
                                        <li style={{ marginRight: '10px' }}>
                                        <Link title="Cancel" to={`/commodity/${data ? data.id:'s'}`}>
                                                <Button >
                                                    <i class="fa fa-times-circle-o reject" aria-hidden="true" style={{ marginRight: '5px' }}></i>Cancel
                                                </Button>
                                            </Link>
                                        </li></>: null}
                                        {mode =='view'  ?<li style={{ marginRight: '10px' }}><Link title="Edit" to={`/commodity/${data.id}/edit`}>
                                        <i class="fa fa-edit"></i>Edit</Link></li>:null
                                        }
                                        {mode !='new'  && data && data.createdAt ?
                                        <li class="last">Created Date: <br />
                                       <DateFormat date={data.createdAt} /> 
                                        </li>
                                        : null }
                                    </ul>

                                    <div class="pt-3"><h3 class="screenName font-weight-normal">Organic black chickpeas chana</h3></div>
                                </div>
                                <div class="card-gutter ml-0 mr-0">
                                    <div class="col-lg-12">

                                        <fieldset class="scheduler-border">
                                            <legend class="scheduler-border">Commodity Item Detail</legend>
                                            <div class="form-row">
                                            <div class="col-md-6 mb-2">
                                                    <Form.Item
                                                        label="Name"
                                                        name="name"
                                                        initialValue={data && data?.name}
                                                        rules={[{ required: true, message: 'Please input valid Name' }]}
                                                    >
                                                        {/* {console.log('insideForm',data && data?.name)} */}
                                                        <Input value={data && data?.name} type="text" disabled={mode =='view'} />

                                                    </Form.Item>


                                                </div>
                                                <div class="col-md-2 mb-2">
                                                    <Form.Item
                                                        label="Minimum Price"
                                                        name="min_price"
                                                        type="number"
                                                        initialValue={data && data?.min_price}
                                                        rules={[{ required: true, message: 'Please input valid Minimum Price' }]}
                                                    >
                                                        <Input type="number" min="0" disabled={mode =='view'} />

                                                    </Form.Item>


                                                </div>
                                                <div class="col-md-2 mb-2">
                                                    <Form.Item
                                                        label="Maximum Price"
                                                        name="max_price"
                                                        initialValue={data && data?.max_price}
                                                        rules={[{ required: true, message: 'Please input valid Maximum Price' }]}
                                                    >
                                                        <Input type="number" min="0" disabled={mode =='view'}/>
                                                    </Form.Item>

                                                </div>
                                                <div class="col-md-2 mb-2">
                                                    <Form.Item
                                                        label="Nodal Price"
                                                        name="nodal_price"
                                                        initialValue={data && data?.nodal_price}
                                                        rules={[{ required: true, message: 'Please input valid Nodal Price' }]}
                                                    >
                                                        <Input type="number" min="0"  disabled={mode =='view'}/>
                                                    </Form.Item>

                                                </div>
                                                <div class="col-md-6 mb-2">
                                                    <Form.Item
                                                        label="Description"
                                                        name="description"
                                                        initialValue={data && data?.description}
                                                        rules={[{ required: true, message: 'Please enter Description' }]}
                                                    >
                                                        <Input disabled={mode =='view'} />
                                                    </Form.Item>

                                                </div> 
                                                <div class="col-md-6 mb-2">
                                                   

                                                </div>
                                                <div class="col-md-6 mb-2">
                                                    
                                                  {mode =='view' ? <Image width={200} height={200} data={data && data.EntityFile ? data.EntityFile : null} /> : 
                                                <Form.Item name="file" valuePropName="fileList" getValueFromEvent={normFile} noStyle>
                                                    <Upload.Dragger name="file"
                                                    accept={['.png','.jpg','.jpeg']}
                                                    beforeUpload={e=> false}
                                                    multiple={false}
                                                    disabled={mode =='view'}
                                                    onChange={onChangeFiles}
                                                     >
                                                        <p className="ant-upload-drag-icon">
                                                        <InboxOutlined />
                                                        </p>
                                                        <p className="ant-upload-text">Click or drag file to this area to upload</p>
                                                    </Upload.Dragger>
                                                    </Form.Item>}

                                                   </div>
                                            </div>
                                        </fieldset>
                                        { attributes && attributes.length > 0 &&

                                        <fieldset class="scheduler-border">
                                            <legend class="scheduler-border">Key Attributes</legend>
                                                        {attributes && attributes.map((item,key) => (
                                                            <>
                                                                {console.log('itemitem',item,key)}

                                                            <Space key={key} style={{ display: 'flex', marginBottom: 8 }} align="baseline">
                                                                <Form.Item
                                                                   initialValue={item?.key}
                                                                >
                                                                    <Input value={item?.key}  placeholder="Enter Key" disabled={mode=='view'} />
                                                                </Form.Item>
                                                                <Form.Item
                                                                 initialValue={item?.value}

                                                                >
                                                                    <Input value={item?.value} placeholder="Key value" disabled={mode=='view'} />
                                                                </Form.Item>
                                                            </Space>
                                                            </>
                                                        ))}
                                        </fieldset>
                                            }
                                        { certification && certification.length > 0 &&
                                        <fieldset class="scheduler-border">
                                            <legend class="scheduler-border">Certificaton</legend>
                                            {certification && certification.map((item,key) => (
                                                            <Space key={key} style={{ display: 'flex', marginBottom: 8 }} align="baseline">
                                                                <Form.Item
                                                                    
                                                                  initialValue={item.certification}
                                                                >
                                                                    <Input value={item?.certification}  placeholder="Certification Name"  disabled={mode=='view'}/>
                                                                </Form.Item>
                                                            </Space>
                                                        ))
                                                        
                                                        }
                                        </fieldset>
                                        }


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Form>)
}

export default DetailForm;

