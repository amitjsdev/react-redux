import { Form, Input, Button, Space, Spin } from 'antd';

import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom'
import { connect } from 'react-redux';
import DashboardLayout from "../../../Layout/DashboardLayout";
import { getCommodityById, addCommodity ,updateCommodity} from '../store/Actions'
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import DetailForm from './DetailForm'
import DateFormat from '../../../common/DateFormat';
const Commodity = (props) => {
    const { data } = props
    const [form] = Form.useForm();
    const { match: { params: { id, edit } } } = props;
    const [mode, setMode] = useState('new')
    useEffect(() => {
         if (id && id != 'new' && !edit) {
            setMode('view')
        }

        if (id && id != 'new') {

            props.getCommodityById(id)
        }

    }, [id, edit]);

  
    const onReset = (e) => {
        e.preventDefault()
        form.resetFields();
    };
    const initialValues = {
        name: data && data.name ? data.name : '',
        min_price: data && data.min_price ? data.min_price : '',
        max_price: data && data.max_price ? data.max_price : '',
        nodal_price: data && data.nodal_price ? data.nodal_price : '',
        description: data && data.description ? data.description : '',
        attributes: data && data.attributes ? JSON.parse( data.attributes) : '',
        certifications: data && data.certifications ? JSON.parse( data.certifications) : '',
    }

    
    return (
        <div>
            <DashboardLayout>
                            {
                                props.loading ? <Spin /> :
                                <> {
                                    props.data  &&
                                    <DetailForm
                                    data={data}
                                    // initialValues={initialValues}
                                    mode={`view`}
                                    onReset={onReset}
                                />

                                }
                                </>
                                   
                            }

            </DashboardLayout>
        </div>

    )
}
const mapStateToProps = state => ({
    loading: state.commodity.loading,
    loaded: state.commodity.loaded,
    error: state.commodity.error,
    data: state.commodity.activeCommodity,
});

const mapDispatchToProps = dispatch => ({
    getCommodityById: (payload) => dispatch(getCommodityById(payload)),
    addCommodity: (payload, history) => dispatch(addCommodity(payload,history)),
    updateCommodity: (id,payload, history) => dispatch(updateCommodity(id,payload,history)),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Commodity);

