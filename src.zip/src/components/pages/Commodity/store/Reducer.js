import * as ActionTypes from './ActionTypes';

const initialState = {
    data: [],
    activeCommodity: null,
    loading: false,
    loaded: false,
    error: {},

}

export default (state = initialState, { type, payload }) => {
    switch (type) {

        case ActionTypes.LOAD_COMMODITIES:
            return { ...state, data: payload}
        case ActionTypes.SET_QOUTES_COMMODITY:
            return { ...state, qoutes: payload }
        case ActionTypes.SET_PO:
            return { ...state, poData: payload }
        case ActionTypes.SET_TRANSIT_DATA:
            return { ...state, transitData: payload }
        case ActionTypes.SET_PAYMENT_DATA:
            return { ...state, paymentData: payload }
        case ActionTypes.SET_COMMODITY_HISTORY:
            return { ...state, historyData: payload }
        case ActionTypes.UPDATE_SYNC:
                    return { ...state, sync: (new Date()).getTime() }

        case ActionTypes.MODAL_INIT:
            return { ...state, modalCloseOnSuccess: payload }

        case ActionTypes.LOAD_COMMODITIES_SUCCESS:
            return { ...state, loaded: true }

        case ActionTypes.LOAD_COMMODITIES_FAILURE:
            return { ...state, error: payload, modalCloseOnSuccess: false }

        case ActionTypes.COMMODITIES_LOADING:
            return { ...state, loading: payload }

        case ActionTypes.LOAD_ACTIVE_COMMODITY:
            return { ...state, activeCommodity: payload }

        case ActionTypes.DELETE_COMMODITY: {
            let data = [...state.data];
            data = data.filter(c =>c.id !=payload)
            return { ...state, data, modalCloseOnSuccess: true }
        }
        case ActionTypes.UPDATE_COMMODITY: {
            let data = [...state.data];
            data = data.map(trade => {
                if (trade.id === payload.id) {
                    return payload;
                } else {
                    return trade;
                }

            }
            )
            return { ...state, data, modalCloseOnSuccess: true }
        }



        case ActionTypes.ADD_COMMODITY: {
            let data = [...state.data];
            data.unshift(payload);
            return { ...state, data, modalCloseOnSuccess: true };
        }

        default:
            return state;
    }
}
