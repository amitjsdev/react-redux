import * as ActionTypes from './ActionTypes';
import Axios from 'axios';
import { message } from 'antd';

export const setLoading = (payload) => ({
    type: ActionTypes.COMMODITIES_LOADING,
    payload
})

export const setError = (payload) => ({
    type: ActionTypes.LOAD_COMMODITIES_FAILURE,
    payload
})

export const setSuccess = () => ({
    type: ActionTypes.LOAD_COMMODITIES_SUCCESS
})

export const loadCommodities = (payload) => ({
    type: ActionTypes.LOAD_COMMODITIES,
    payload
})

export const loadActiveCommodity = payload => ({
    type: ActionTypes.LOAD_ACTIVE_COMMODITY,
    payload
})
export const setQoutes = payload => ({
    type: ActionTypes.SET_QOUTES_COMMODITY,
    payload
})
export const setPO = payload => ({
    type: ActionTypes.SET_PO,
    payload
})
export const getTransitSuccess = payload => ({
    type: ActionTypes.SET_TRANSIT_DATA,
    payload
})
export const setPaymentSuccess = payload => ({
    type: ActionTypes.SET_PAYMENT_DATA,
    payload
})

export const setCommodityHistory = (payload) => ({
    type: ActionTypes.SET_COMMODITY_HISTORY,
    payload
})

export const deleteCommodities = payload => ({
    type: ActionTypes.DELETE_COMMODITY,
    payload
})

export const addCommodities = (payload) => ({
    type: ActionTypes.ADD_COMMODITY,
    payload
})
export const updateSync = () => ({
    type: ActionTypes.UPDATE_SYNC,
})
export const modalOpned = (payload) => ({
    type: ActionTypes.MODAL_INIT,
    payload
})

export const getCommodities = () => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.get(`${process.env.REACT_APP_API_URL}commodity`,
        )
            .then(res => {
                dispatch(setLoading(false));
                if (res.data && res.data.status) {
                    dispatch(setSuccess());
                    dispatch(loadCommodities(res.data.data));

                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}

export const search = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.post(`${process.env.REACT_APP_API_URL}commodity/search`,
            payload,
        )
            .then(res => {
                dispatch(setLoading(false));
                if (res.data && res.data.status) {
                    dispatch(setSuccess());
                    dispatch(loadCommodities(res.data.data));

                } else {
                    message.error('Something went wrong');  
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}

export const getCommodityById = (id) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.get(`${process.env.REACT_APP_API_URL}commodity/${id}`,
        )
            .then(res => {
                dispatch(setLoading(false));

                if (res.data && res.data.status) {
                    dispatch(loadActiveCommodity(res.data.data));
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}
export const addCommodity= (payload, history) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.post(`${process.env.REACT_APP_API_URL}commodity`,payload,
        )
            .then(res => {
                dispatch(setLoading(false));

                if (res.data && res.data.status) {
                    message.success('Commodity added successfully');
                    history.push('/commodity')
                } else  if(res.data && res.data.errors){
                    message.error(res.data.errors);
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}
export const updateCommodity= (id,payload, history) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.put(`${process.env.REACT_APP_API_URL}commodity/${id}`,payload,
        )
            .then(res => {
                dispatch(setLoading(false));

                if (res.data && res.data.status) {
                    message.success('Commodity Updated successfully');
                    history.push('/commodity')
                } else  if(res.data && res.data.errors){
                    message.error(res.data.errors);
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}
export const deleteCommodity = (id, history) => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.delete(`${process.env.REACT_APP_API_URL}commodity/${id}`,
        )
            .then(res => {
                dispatch(setLoading(false));
                if (res.status === 200) {
                   
                    if (!res.data.errors) {
                         dispatch(deleteCommodities(id))   
                        history.push('/commodity')
                        message.success('Commodity Deleted successfully');
                    }
                    else {
                        message.error(res.data.errors[0].msg);
                        dispatch(setLoading(false));
                        dispatch(setError(res.data.errors));
                    }
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
                dispatch(setError(e));
            });
    }
}

export const modalInit = (payload) => {
    return dispatch => {
        dispatch(modalOpned(payload));
    }
}