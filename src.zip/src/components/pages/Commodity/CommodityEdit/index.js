import { Form, Input, Button, Space, Spin } from 'antd';

import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom'
import { connect } from 'react-redux';
import DashboardLayout from "../../../Layout/DashboardLayout";
import { getCommodityById, addCommodity ,updateCommodity} from '../store/Actions'
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import DetailEditForm from './DetailEditForm'
import DateFormat from '../../../common/DateFormat';
const Commodity = (props) => {
    const { data } = props
    const [form] = Form.useForm();
    const { match: { params: { id, edit } } } = props;
    const [mode, setMode] = useState('new')
    const [key, setKey] =useState((new Date()).getTime())
    useEffect(() => {
        if (id && id != 'new' && edit) {
            setMode('edit')
            setKey((new Date()).getTime())
        }

        if (id && id != 'new') {
            setKey((new Date()).getTime())
            props.getCommodityById(id)
        }

    }, [id, edit]);

    const onFinish = (values) => {
        if(mode=='edit'){
            props.updateCommodity(id, values, props.history)

        } else {
            props.addCommodity(values, props.history)

        }
       
    };
    const onSubmit = (e) => {
        e.preventDefault()
        //console.log({ form });
        form.submit()
    };

    const onFinishFailed = (errorInfo) => {
        //console.log('Failed:', errorInfo);
    };
    const onReset = (e) => {
        e.preventDefault()
        form.resetFields();
    };
    const initialValues = {
        name: data && data.name ? data.name : '',
        min_price: data && data.min_price ? data.min_price : '',
        max_price: data && data.max_price ? data.max_price : '',
        nodal_price: data && data.nodal_price ? data.nodal_price : '',
        description: data && data.description ? data.description : '',
        attributes: data && data.attributes ? JSON.parse( data.attributes) : '',
        certifications: data && data.certifications ? JSON.parse( data.certifications) : '',
    }

    
    return (
        <div>
            <DashboardLayout key={key}>
                {
                        <>
                            {
                                props.loading ? <Spin /> :
                                <> {
                                    props.data  &&
                                    <DetailEditForm
                                    data={data}
                                    initialValues={initialValues}
                                    mode={mode}
                                    onFinish={onFinish}
                                    onFinishFailed={onFinishFailed}
                                    onReset={onReset}
                                    onSubmit={onSubmit}
                                />

                                }
                                </>
                                   
                            }
                        </>
                }

            </DashboardLayout>
        </div>

    )
}
const mapStateToProps = state => ({
    loading: state.commodity.loading,
    loaded: state.commodity.loaded,
    error: state.commodity.error,
    data: state.commodity.activeCommodity,
});

const mapDispatchToProps = dispatch => ({
    getCommodityById: (payload) => dispatch(getCommodityById(payload)),
    // addCommodity: (payload, history) => dispatch(addCommodity(payload,history)),
    updateCommodity: (id,payload, history) => dispatch(updateCommodity(id,payload,history)),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Commodity);

