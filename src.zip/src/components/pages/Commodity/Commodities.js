import { Input, Select, DatePicker, Space,Pagination  } from 'antd';
import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import {Link} from 'react-router-dom'
import DashboardLayout from "../../Layout/DashboardLayout";
import { getCommodities,search,deleteCommodity } from './store/Actions'
import List from './List'
const Commodities = (props) => {
    const {data,loading, count}=props;
    useEffect(() => {
        props.getCommodities()
    }, []);
    const [offset, setOffSet] = useState(0);
    
    const doSearch = (newOffset=offset) => {                         
        
        props.search({
            limit:10, offset:newOffset
        })
    }
    const itemRender=(current, type, originalElement) =>{
        if (type === 'prev') {
          return <a className="page-link" >Previous</a>;
        }
        if (type === 'next') {
          return <a className="page-link" >Next</a>;
        }
        return originalElement;
      }

      const paginationChange =(page, pageSize)=>{
          const newOffset =(page-1)*pageSize;
          setOffSet(newOffset);
            doSearch(newOffset) 
          
      }

      const deleteItem=(e, id)=>{
        e.preventDefault()
        props.deleteCommodity(id, props.history)
      }

    return (
        <div>
            <DashboardLayout>
                <div class="page-inner">
                    
                    <div class="container-fluid pl-0 pr-0">
                        <div class="row card-gutter ml-0 mr-0">
                        <div class="pt-3"><h2 class="screenName">Item Price Lists</h2></div>
                        <ul class="actionList">
                            <li><Link class="comment_box" title="Add" to="/commodity/new"><i class="fa fa-plus"></i>Add</Link></li>

                        </ul>
                        
                    </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card pb-0 mb-0">
                                    <div class="card-body pb-2 pt-0">
                                        <div className="table-responsive">
                                            <List
                                                data={data}
                                                loading={loading}
                                                deleteItem={deleteItem}
                                            />
                                            <nav aria-label="Page navigation example">
                                            <Pagination total={count} itemRender={itemRender}
                                            className="pagination justify-content-end float-none"
                                            onChange={paginationChange}
                                            hideOnSinglePage={true}
                                            />
                                            </nav>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </DashboardLayout>
        </div>

    )
}
const mapStateToProps = state => ({
    loading: state.commodity.loading,
    loaded: state.commodity.loaded,
    error: state.commodity.error,
    data: state.commodity.data,
});

const mapDispatchToProps = dispatch => ({
    getCommodities: (payload) => dispatch(getCommodities(payload)),
    deleteCommodity: (payload, history) => dispatch(deleteCommodity(payload, history)),
    search: (payload) => dispatch(search(payload)),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Commodities);

