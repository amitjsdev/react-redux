import React, { useState } from 'react';
import SideImage from "../../../assets/images/agriculture.jpg";
import { Form, Input } from 'antd';
import { Link, useLocation } from 'react-router-dom';
import axios from 'axios';
import { message } from 'antd';
import { API_BASE_URL_LIVE } from "../../../config/constants";
import { useDispatch, useSelector } from 'react-redux';
import { doLogin } from '../../AuthenticatedApp/store/redux/auth/Actions';
import AuthLayout from "../../Layout/AuthLayout";
import { useHistory } from "react-router-dom";
const Login = () => {
    const dispatch = useDispatch();

    const handleLogin = (values) => {
        let payload = {
            email: values.email,
            password: values.password
        }
        dispatch(doLogin(payload));

    };

    const onFinishFailed = (errorInfo) => {
        //console.log('Failed:', errorInfo);
    };

    return (
        <div>
            <AuthLayout>
                <div className="container-fluid pl-0 pr-0">
                    <div className="row custom-gutter">
                        <div className="d-none d-md-flex col-md-6 col-lg-6">
                            <picture>
                                <source media="(min-width:650px)" srcSet={SideImage} />
                                <source media="(min-width:465px)" srcSet={SideImage} />
                                <img className="loginImg" src={SideImage} alt="Case Studies" />
                            </picture>
                        </div>
                        <div className="col-md-6">
                            <div className="login d-flex align-items-center">
                                <div className="container-fluid">
                                    <div className="row">
                                        <div className="col-lg-10 mx-auto">
                                            <div className="col-lg-12 logoContainer">
                                                <div className="row">
                                                    <div className="brand-logo">
                                                        <div className="brandTag"><span className="headTop">Value Harvest</span></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="loginInner">
                                                <div className="col-lg-12"><h2 className="login-heading">Sign In</h2> </div>
                                                <div className="col-lg-12">
                                                    <Form

                                                        initialValues={{ remember: true }}
                                                        onFinish={handleLogin}

                                                        onFinishFailed={onFinishFailed}
                                                    >
                                                        <div className="form-group">
                                                            <label>Username</label>
                                                            <Form.Item
                                                                name="email"
                                                                rules={[
                                                                    {
                                                                        required: true,
                                                                        type: "email",
                                                                        message: 'Please input your E-mail!',
                                                                    },
                                                                ]}
                                                            >
                                                                <Input placeholder="E.g. valueharvest@gmail.com" />
                                                            </Form.Item>
                                                        </div>
                                                        <div className="form-group">
                                                            <label className="pt-2">Password</label>

                                                            <Form.Item
                                                                name="password"
                                                                rules={[
                                                                    {
                                                                        required: true,
                                                                        message: 'Please input your password!',
                                                                    },
                                                                ]}
                                                            >
                                                                <Input placeholder="E.g. password123" type="password" />
                                                            </Form.Item>
                                                        </div>
                                                        <div className="form-group">
                                                            <button className="btn btn-blue btn-custom mr-2 mt-3">Sign In</button>
                                                        </div>
                                                    </Form>
                                                </div>
                                            </div>
                                            <div className="loginFooter">&nbsp;</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </AuthLayout>
        </div>


    )
}

export default Login
