import React from 'react';
import { message, notification } from 'antd';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux'
import Dashboard from '../pages/Dashboard';
import socketIOClient from "socket.io-client";
// import ItemList from '../pages/item-list/ItemList';
import NewTradeDetails from '../pages/task-list/NewTradeDetails';
import NewTradingRequestList from '../pages/task-list/NewTradingRequestList';
import NewUserRequestList from '../pages/task-list/NewUserRequestList';
import UserDetail from '../pages/task-list/UserDetail';
import Trades from '../pages/tradeManagement/Trades';
import TradeDetail from '../pages/tradeManagement/TradeDetail';
import Commodities from '../pages/Commodity/Commodities';
import CommodityEdit from '../pages/Commodity/CommodityEdit/index';
import  Commodity from '../pages/Commodity/CommodityView/index';
import CommodityNew from '../pages/Commodity/CommodityNew/index';

import UserManagement from '../pages/userManagement/UserManagement';
import ViewUserManagement from '../pages/userManagement/ViewUserManagement';
import Notifications from '../common/Notifications'
import { getMasterData, postUserSocket ,getNotification} from './store/redux/auth/Actions';
class AuthenticatedApp extends React.Component {
  // state = {
  //   socket: socketIOClient.connect(process.env.REACT_APP_SOCKET_URL),
  // }

  componentDidMount() {
    return
    this.props.getNotification()
    const { user } = this.props;

    const socket = this.state.socket;
    const { postUserSocket } = this.props;
    socket.on("connect", () => {
      postUserSocket({ socketId: socket.id, userId: user.id });
    });

    socket.on('fromServerNotification', data => {
      //console.log('2', { data })
      this.openNotification({
        type:'success',
        title:data.subject,
        msg:data.content
      });
     
      this.props.getNotification()
      
    });

  }
  openNotification = data => {
    notification[data.type]({
      message: data.title,
      description:data.msg
    });
  };

  componentWillUnmount() {
    this.state.socket.close();
  }
  render() {
    const { location: { pathname } } = this.props;

    if (pathname == '/login') {
      return <Redirect to="/" />
    }
    return (
      <Switch>
        <Route path="/new-user-request" component={NewUserRequestList} />
        <Route path="/new-trade-request" component={NewTradingRequestList} />
        <Route path="/user-trade-detail/:id" component={NewTradeDetails} />
        <Route path="/user-management" component={UserManagement} />

        <Route path="/trades/:id/:edit" component={TradeDetail} />
        <Route path="/trades/:id" component={TradeDetail} />
        <Route path="/trades" component={Trades} />
        <Route path="/commodity/new" component={CommodityNew} />
        <Route path="/commodity/:id/:edit" component={CommodityEdit} />
        <Route path="/commodity/:id" component={Commodity} />
        <Route path="/commodity" component={Commodities} />
        <Route path="/trades/:id" component={TradeDetail} />
        <Route path="/trades" component={Trades} />
        <Route path="/notifications" component={Notifications} />

        <Route path="/view-user-management/:id" component={ViewUserManagement} />
        {/* <Route path="/view-user-trade-management/:id" component={ViewUserTradeManagement} /> */}
        <Route path="/user-detail/:id" component={UserDetail} />
        <Route path="/" component={Dashboard} />
      </Switch>
    );
  }
}

const mapStateToProps = state => ({
  authenticated: state.auth.authenticated,
  user: state.auth.user
});

const mapDispatchToProps = dispatch => ({
  getMasterData: () => dispatch(getMasterData()),
  getNotification: () => dispatch(getNotification()),
  postUserSocket: (payload) => dispatch(postUserSocket(payload)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AuthenticatedApp);