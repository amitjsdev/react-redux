import * as ActionTypes from './ActionTypes';
import Axios from 'axios';
import { message } from 'antd';
import {API_BASE_URL_LIVE} from '../../../config/constants' 
export const setLoading = (payload) => ({
    type: ActionTypes.MASTERDATA_LOADING,
    payload
})
export const setMasterData = (payload) => ({
    type: ActionTypes.LOAD_MASTERDATA_SUCCESS,
    payload
})

export const getMasterData = () => {
    return dispatch => {
        dispatch(setLoading(true));
        Axios.get(`${API_BASE_URL_LIVE}master-data`,
        )
            .then(res => {
                dispatch(setLoading(false));
                if (res.data ) {
                    dispatch(setMasterData(res.data));

                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                // dispatch(setLoading(false));
                // dispatch(setError(e));
            });
    }
}