import * as ActionTypes from './ActionTypes';
import axios from 'axios';
import { API_BASE_URL_LIVE } from "../../../../../config/constants";
import { authHeader } from '../../../../../config/auth-header';
import { message } from 'antd';

export const setLoading = (payload) => ({
    type: ActionTypes.SET_LOADING,
    payload
})

export const setUserTradeList = (payload) =>
({
    type: ActionTypes.SET_TRADE_USER_LIST,
    payload
})

export const setUserPaymentList = (payload) => ({
    type: ActionTypes.SET_USER_PAYMENT_LIST,
    payload
})

export const setPOTradeList = (payload) => ({
    type: ActionTypes.SET_PO_TRADE_LIST,
    payload
})

export const setUserTrasistList = (payload) => ({
    type: ActionTypes.SET_USER_TRANSIS_LIST,
    payload
})

export const setRejectRequest = (payload) =>
({
    type: ActionTypes.REJECT_ACCEPT_USER_TRADE_REQUEST,
    payload
})


export const acceptTradeRequest = (userID,descp,history) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.put(`${API_BASE_URL_LIVE}trade/approveOrReject/${userID}`, { status: 2,comment:descp }, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    message.success('User Trade Successfully Approved');

                    history.push({
                        pathname: `/trades/`
                    });
                    dispatch(setRejectRequest(res.data));
                   
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }
}

export const rejectTradeRequest = (userID,descp,history) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.put(`${API_BASE_URL_LIVE}trade/approveOrReject/${userID}`, { status: 0,comment:descp }, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    message.success('User Trade Successfully Rejected');
                    history.push({
                        pathname: `/trades/`
                    });
                   // dispatch(setRejectRequest(res.data));
                    
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }

}

export const getUserTradeList = (payload) => {
    return dispatch => {
        // dispatch(setLoading(true));
        axios.post(`${API_BASE_URL_LIVE}trade/search`, payload, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    dispatch(setUserTradeList(res.data));
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }
}
export const getUserTrasistList = (payload) => {
    return dispatch => {
        // dispatch(setLoading(true));
        axios.get(`${API_BASE_URL_LIVE}transit/trade/${payload.id}`, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    //console.log('setUserTrasistList',res.data)
                    dispatch(setUserTrasistList(res.data));
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }
}

export const getPOTradeDetail = (payload) => {
    return dispatch => {
        // dispatch(setLoading(true));
        axios.get(`${API_BASE_URL_LIVE}po/trade/${payload.id}`, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    dispatch(setPOTradeList(res.data));
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }
}

export const getUserTradePaymentList = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.get(`${API_BASE_URL_LIVE}payment/trade/${payload.id}`, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    dispatch(setUserPaymentList(res.data));
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }
}

export const getUserTradeDetail = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        const requestOptions = {
            method: 'GET',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        };

        return axios
            .get(`${API_BASE_URL_LIVE}trade/${payload.id}`, requestOptions)
            .then(response => {
                dispatch(setLoading(false));
                if (response.data) {
                    dispatch(setUserTradeDetail(response.data));
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
            });

    }
}

export const setUserTradeDetail = (payload) =>
({
    type: ActionTypes.SET_TRADE_USER_DETAIL,
    payload
})


function handleResponse(response) {
    return response.text().then(text => {
        const data = text && JSON.parse(text);
        if (!response.ok) {
            if (response.status === 401) {
                // auto logout if 401 response returned from api

                ;
            }

            const error = (data && data.message) || response.statusText;
            return Promise.reject(error);
        }

        return data;
    });
}