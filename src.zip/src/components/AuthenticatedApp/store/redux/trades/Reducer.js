import * as ActionTypes from './ActionTypes';
const initialState = {
    data: [],
    loading: false,
}

export const trades = (state = initialState, { type, payload }) => {
    //console.log('trades-payload',payload)
    switch (type) {

        case ActionTypes.SET_LOADING:
            return { ...state, loading: payload }

        case ActionTypes.SET_TRADE_USER_DETAIL:
            return { ...state, data: payload }

        case ActionTypes.SET_USER_PAYMENT_LIST:
            return { ...state, payment: payload };

        case ActionTypes.SET_USER_TRANSIS_LIST:
            return { ...state, transit: payload };

        case ActionTypes.SET_TRADE_USER_LIST:
            return { ...state, usertradelist: payload };

        case ActionTypes.SET_PO_TRADE_LIST:
            return { ...state, Potradelist: payload };

        case ActionTypes.REJECT_ACCEPT_USER_TRADE_REQUEST:
            const objIndex = state.usertradelist.data.rows.findIndex((obj => obj.id == payload.id));
            state.usertradelist.data.rows[objIndex].status = payload.status;
            return {
                ...state,
                usertradelist: state.usertradelist
            }

        default:
            return state;
    }
}
