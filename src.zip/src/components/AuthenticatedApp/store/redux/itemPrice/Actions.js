import * as ActionTypes from './ActionTypes';
import axios from 'axios';
import { API_BASE_URL_LIVE } from "../../../../../config/constants";
import { message } from 'antd';

export const setLoading = (payload) => ({
    type: ActionTypes.SET_LOADING,
    payload
})

export const setItemPriceList = (payload) =>
({
    type: ActionTypes.SET_ITEM_PRICE_LIST,
    payload
})

export const getItemPriceList = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.get(`${API_BASE_URL_LIVE}commodity`, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    dispatch(setItemPriceList(res.data));
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }
}




function handleResponse(response) {
    return response.text().then(text => {
        const data = text && JSON.parse(text);
        if (!response.ok) {
            if (response.status === 401) {
                // auto logout if 401 response returned from api

                ;
            }

            const error = (data && data.message) || response.statusText;
            return Promise.reject(error);
        }

        return data;
    });
}