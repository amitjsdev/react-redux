import * as ActionTypes from './ActionTypes';
const initialState = {
    data: [],
    loading: false,
}

export const itemPrice = (state = initialState, { type, payload }) => {
    switch (type) {

        case ActionTypes.SET_LOADING:
            return { ...state, loading: payload }

        case ActionTypes.SET_ITEM_PRICE_LIST:
            return { ...state, itemPriceList: payload }

        default:
            return state;
    }
}
