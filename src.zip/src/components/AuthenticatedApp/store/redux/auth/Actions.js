import * as ActionTypes from './ActionTypes';
import axios from 'axios';
import { message } from 'antd';
import { API_BASE_URL_LIVE } from "../../../../../config/constants";
export const setLoading = (payload) => ({
    type: ActionTypes.SET_LOADING,
    payload
})

export const setMasterData = (payload) => ({
    type: ActionTypes.SET_MASTER_DATA,
    payload
})

export const LoginData = (payload) =>

({
    type: ActionTypes.SET_LOGIN_SUCCESS,
    payload
})
export const LogoutSuccess = () =>({
    type: ActionTypes.SET_LOGOUT_SUCCESS,
})
export const updateUserNotification = (payload) =>({
    type: ActionTypes.SET_NOTIFICATION,
    payload
})

export const getMasterData = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.get(`${API_BASE_URL_LIVE}master-data`)
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    dispatch(setMasterData(res.data));
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }
}


export const doLogin = (payload, from) => {
    return dispatch => {
        axios.post(`${API_BASE_URL_LIVE}auth/login`, payload)
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    localStorage.setItem('vhtoken', res.data.token);
                    localStorage.setItem('userDetail', JSON.stringify(res.data));
                    dispatch(LoginData(res.data));

                }
            })
            .catch(e => {
                message.error('Invalid credentials', 1);
                // dispatch(setLoading(false));
            });
    }
};
export const doLogout = () => {
    return dispatch => {
                    localStorage.clear();
                    dispatch(LogoutSuccess());
    }
};


export const postUserSocket = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.post(`${process.env.REACT_APP_API_URL}master-data/postUserSocket/`,payload)
        .then(res => {
            dispatch(setLoading(false));
            if (res.data) {
            }
        })
        .catch(e => {
            dispatch(setLoading(false));
            
        })
    }
}
export const getNotification = () => {
    return dispatch => {
        axios.get(`${process.env.REACT_APP_API_URL}notification`)
        .then(res => {
            
            if (res && res.data )  {
                const data =res.data
                dispatch(updateUserNotification(data))
            }
        })
        .catch(e => {
            //console.log(e);
        });
    }
}
