import * as ActionTypes from './ActionTypes';
const initialState = {
    data: [],
    loading: false,
    authenticated: false, 
    user: undefined,
    authLoading:true,
    notification:[],
    newTrade:0,
    newUser:0
}

export const auth = (state = initialState, { type, payload }) => {
    switch (type) {

        case ActionTypes.SET_LOADING:
            return { ...state, loading: payload }

        case ActionTypes.SET_MASTER_DATA:
            return { ...state, data: payload }

        case ActionTypes.SET_LOGIN_DETAIL:
            return { ...state, data: payload }
        case ActionTypes.SET_LOGIN_SUCCESS:
                    return { ...state, authenticated: true,user:payload }
        case ActionTypes.SET_LOGOUT_SUCCESS:
            return { ...state, authenticated: false,user:undefined }
        case ActionTypes.SET_NOTIFICATION:
            //console.log({payload});
                    return { ...state, notification: payload.data,
                         newTrade: payload.newTrade,
                         newUser: payload.newUser
                        }

        default:
            return state;
    }
}
