import * as ActionTypes from './ActionTypes';
import axios from 'axios';
import { API_BASE_URL_LIVE } from "../../../../../config/constants";
import { authHeader } from '../../../../../config/auth-header';
import { message } from 'antd';

export const setLoading = (payload) => ({
    type: ActionTypes.SET_LOADING,
    payload
})

export const setUserList = (payload) =>
({
    type: ActionTypes.SET_USER_LIST,
    payload
})

export const setRejectRequest = (payload) =>
({
    type: ActionTypes.REJECT_ACCEPT_USER_REQUEST,
    payload
})

//starrt get user list 
export const getCountUserList = (payload) => {
       return axios.post(`${API_BASE_URL_LIVE}users/search`, payload, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                if (res.data) {
                    let data = res.data;
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
              //  dispatch(setLoading(false));
            });
   
}
//end user list 
export const updateUser = (userID,data) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.put(`${API_BASE_URL_LIVE}users/${userID}`, data, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    message.success('User successfully updated')
                    dispatch(setUserDetail(res.data));
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }
}

export const acceptRequest = (userID,descrp,history) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.put(`${API_BASE_URL_LIVE}users/approveOrReject/${userID}`, { status: 1,comment:descrp }, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    message.success('User successfully approved')
                    history.push({
                        pathname: `/user-management/`
                    });
                    dispatch(setRejectRequest(res.data));
                  
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }
}

export const rejectRequest = (userID,descrp,history) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.put(`${API_BASE_URL_LIVE}users/approveOrReject/${userID}`, { status: 2,comment:descrp }, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    message.success('User successfully rejected')
                    history.push({
                        pathname: `/user-management/`
                    });
                     dispatch(setRejectRequest(res.data));
                    
                    
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }

}

export const disbledRequest = (userID) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.put(`${API_BASE_URL_LIVE}users/approveOrReject/${userID}`, { status: 0 }, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    message.success('User successfully disabled')
                    return dispatch(setRejectRequest(res.data));
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }

}

export const getUserList = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        axios.post(`${API_BASE_URL_LIVE}users/search`, payload, {
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        })
            .then(res => {
                dispatch(setLoading(false));
                if (res.data) {
                    dispatch(setUserList(res.data));
                }
            })
            .catch(e => {
                // message.error('Something went wrong');
                dispatch(setLoading(false));
            });
    }
}

export const getUserDetail = (payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        const requestOptions = {
            method: 'GET',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        };

        return axios
            .get(`${API_BASE_URL_LIVE}users/${payload.id}?all=true`, requestOptions)
            .then(response => {
                dispatch(setLoading(false));
                if (response.data) {
                    dispatch(setUserDetail(response.data));
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
            });

    }
}

//user trades

export const getUserTrades = (params,payload) => {
    return dispatch => {
        dispatch(setLoading(true));
        const requestOptions = {
            method: 'GET',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        };

        return axios
            .get(`${API_BASE_URL_LIVE}trade/usertrades/${params.id}?offset=${payload.offset}&limit=${payload.limit}`, requestOptions)
            .then(response => {
                dispatch(setLoading(false));
                if (response.data) {
                    dispatch(setUsertrades(response.data));
                }
            })
            .catch(e => {
                message.error('Something went wrong');
                dispatch(setLoading(false));
            });

    }
}

export const setUserDetail = (payload) =>
({
    type: ActionTypes.SET_USER_DETAIL,
    payload
})

export const setUsertrades = (payload) =>
({
    type: ActionTypes.SET_USER_TRADES,
    payload
})

function handleResponse(response) {
    return response.text().then(text => {
        const data = text && JSON.parse(text);
        if (!response.ok) {
            if (response.status === 401) {
                // auto logout if 401 response returned from api

                ;
            }

            const error = (data && data.message) || response.statusText;
            return Promise.reject(error);
        }

        return data;
    });
}