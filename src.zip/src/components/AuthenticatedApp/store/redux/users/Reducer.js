import * as ActionTypes from './ActionTypes';
const initialState = {
    data: [],
    loading: false,
}

export const user = (state = initialState, { type, payload }) => {
    switch (type) {

        case ActionTypes.SET_LOADING:
            return { ...state, loading: payload }

        case ActionTypes.SET_USER_DETAIL:
            return { ...state, data: payload }

            case ActionTypes.SET_USER_TRADES:
                return { ...state, dataTrades: payload }

        case ActionTypes.SET_USER_LIST:
            return { ...state, userlist: payload }

        case ActionTypes.REJECT_ACCEPT_USER_REQUEST:
            const objIndex = state.userlist.data.rows.findIndex((obj => obj.id == payload.id));
            state.userlist.data.rows[objIndex].status = payload.status;
            return {
                ...state,
                userlist: state.userlist
            }

        default:
            return state;
    }
}
