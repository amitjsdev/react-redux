import { combineReducers } from "redux";
import { auth } from "../../store/redux/auth/Reducer";
import { user } from "../../store/redux/users/Reducer";
import { trades } from "../../store/redux/trades/Reducer";
import  tradeReducer from "../../../pages/tradeManagement/store/Reducer";
import  commodityReducer from "../../../pages/Commodity/store/Reducer";
import  appReducer from "../Reducer";
import { itemPrice } from "../../store/redux/itemPrice/Reducer";
const rootReducer = combineReducers({
  auth,
  trades,
  user,
  tradesData:tradeReducer,
  commodity:commodityReducer,
  itemPrice,
  app:appReducer
});
export default rootReducer;
