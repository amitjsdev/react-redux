import * as ActionTypes from './ActionTypes';

const initialState = {
    data: [],
    loading: false,
    loaded: false,
    error: {},
}

export default (state = initialState, { type, payload }) => {
    switch (type) {

    case ActionTypes.LOAD_MASTERDATA_SUCCESS:
        return { ...state, data: payload }
    
    case ActionTypes.MASTERDATA_LOADING:
        return { ...state, loading: payload }
    default:
        return state;
    }
}
