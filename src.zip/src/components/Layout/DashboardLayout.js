import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { Layout } from 'antd';
import Topbar from '../common/Topbar';
import Sidebar from '../common/Sidebar';
const { Sider, Header, Content } = Layout;

const DashboardLayout = ({ children, className }) => {
    const history = useHistory();
    const [toggle, settoggle] = useState(false)

    const onSidebarClick = () => {
        //console.log("Working")
        settoggle(!toggle)
    }

    const onSidebarHover = () => {
        settoggle(false)
    }


  
    return (
        <Layout className="wrapper">
            <Header>
                <Topbar onSidebarClick={onSidebarClick} toggle={toggle} />
            </Header>
            <Layout>
                <Sidebar toggle={toggle} onSidebarHover={onSidebarHover} />
                <Content
                    style={toggle ? { marginLeft: 55 } : {
                        marginLeft: 240
                    }}
                // className="content"
                >
                    {children}
                    {/* <BrowserRouter>
                        <Switch>
                            <Route exact path="*" component={Dashboard} />
                            <Route path="/new-user-request" component={NewUserRequest} />
                            <Route path="/new-trading-request" component={NewTradingRequest} />
                            <Route path="/user-detail" component={UserDetail} />
                            <Route path="/user-trade-detail" component={UserTradeDetails} />
                        </Switch>
                    </BrowserRouter> */}
                </Content>
            </Layout>
        </Layout>

    )
};

export default DashboardLayout;
