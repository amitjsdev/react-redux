import React, { useEffect } from "react";
import { useHistory } from "react-router-dom";

const AuthLayout = ({ children, className }) => {
  const history = useHistory();
  useEffect(
    () => {
      if (localStorage.getItem("token") && localStorage.getItem("userDetail")) {
        history.push("/");
      }
    },
    [history]
  );
  return <div className={`auth ${className}`}>{children}</div>;
};

export default AuthLayout;
