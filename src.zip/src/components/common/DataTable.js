import React from 'react'

const DataTable = ({ thead, children }) => {
    const theadData = thead || []
    return (
        <div className="table-responsive">
            <table className="table table-striped table-bordered">
                <thead>
                    <tr>
                        {
                            theadData.map(item => (
                                <th className="text-capitalize" key={item}>{item}</th>
                            ))
                        }
                    </tr>   
                </thead>
                <tbody>
                    {children}
                </tbody>
            </table> 
        </div>
    )
}

export default DataTable
