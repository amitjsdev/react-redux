import { message } from "antd";
import React, { useState } from "react";
import { API_BASE_URL_LIVE } from "../../config/constants";
const UserIdentityInfo = ({ value, onChange, pageMode, errors }) => {
  const [panFile, setPanFile] = useState(true);
  const [gstinFile, setgstinFile] = useState(true);
  const [aadharFile, setaadharFile] = useState(true);
  const [importFile, setImportFile] = useState(true);


  const onHandleCancle = (e) => { };
  return (
    <fieldset className="scheduler-border">
      <legend className="scheduler-border">Identity Information</legend>
      <div className="form-row">
        <div className="col-md-3 mb-2">
          <label>PAN Number</label>
          <div className="input-group">
            <input
              type="text"
              name="pan.number"
              value={value.pan.number}
              className="form-control"
              placeholder=""
              onChange={onChange}
              readOnly={pageMode !== "edit"}
            />
          </div>
          {errors && errors.pan ? (
            <p className="text-danger">{errors.pan}</p>
          ) : null}
        </div>
        <div className="col-md-3 mb-2">
          <label>Aadhar Card Number</label>
          <div className="input-group">
            <input
              type="text"
              name="aadhar.number"
              value={value.aadhar.number}
              className="form-control"
              placeholder=""
              onChange={onChange}
              readOnly={pageMode !== "edit"}
            />
          </div>
          {errors && errors.aadhar ? (
            <p className="text-danger">{errors.aadhar}</p>
          ) : null}
        </div>
        <div className="col-md-3 mb-2">
          <label>GSTIN</label>
          <div className="input-group">
            <input
              type="text"
              name="gstin.number"
              value={value.gstin.number}
              className="form-control"
              placeholder=""
              onChange={onChange}
              readOnly={pageMode !== "edit"}
            />
          </div>
          {errors && errors.gstin ? (
            <p className="text-danger">{errors.gstin}</p>
          ) : null}
        </div>
        <div className="col-md-3 mb-2">
          <label>Export Code</label>
          <div className="input-group">
            <input
              type="text"
              name="export.number"
              value={value.export.number}
              className="form-control"
              placeholder=""
              onChange={onChange}
              readOnly={pageMode !== "edit"}
            />
          </div>
          {/* <p className="text-danger">{error.export_code}</p> */}
        </div>
        <div className="col-md-3 mb-2">
          <label>Import Code</label>
          <div className="input-group">
            <input
              type="text"
              name="import.number"
              value={value.import.number}
              className="form-control"
              placeholder=""
              onChange={onChange}
              readOnly={pageMode !== "edit"}
            />
          </div>
          {/* <p className="text-danger">{error.import_code}</p> */}
        </div>
        {/* <div className="col-md-3 mb-2">
          <label>&nbsp;</label>
          <div className="attach-placeholder">
           {importFile ? value.import.file.name : ""}
            <span
              onClick={() => (pageMode == "edit" ? setImportFile(false) : "")}
            >
              <a>
                {importFile && value.import.file.name ? (
                  <i class="fa fa-close ml-5"></i>
                ) : (
                  ""
                )}
              </a>
            </span>
          </div>
        </div> */}
        {/* {pageMode == "edit" ? (
          <div className="col-md-3 mb-2">
            <label>Import License</label>
            <div className="custom-file">
              <input
                type="file"
                readOnly={pageMode !== "edit"}
                name="import.file"
                class="custom-file-input"
                id="validatedCustomFile"
                onChange={(event) => {
                  if (importFile && value.import.file.name) {
                    message.error("please delete old file first");
                  } else {
                    value.import.file.name =
                      event.currentTarget.files[0].name;
                    setImportFile(value.import.file.name);
                  }
                }}
              />
              <label className="custom-file-label" for="validatedCustomFile">
                Choose file...
              </label>
            </div>
          </div>
        ) : (
          ""
        )} */}

        <fieldset class="scheduler-border w-100">
          <legend class="scheduler-border">KYC Documents [Attachements]</legend>
          <div class="address-container">
            <div class="form-row">
            {importFile && value.import.file.name &&
                <div class="col-md-4 d-flex flex-wrap mb-2">
                  <label className="w-100">Import License</label>
                  <div class="attach">
                  <a target="_blank" href={`${API_BASE_URL_LIVE}file/${value?.import.file.id}`}>{importFile ? value.import.file.name : ""}</a>    
                    
                    {/* <span
                      onClick={() =>
                        pageMode == "edit" ? setPanFile(false) : ""
                      }
                    >
                      <a>
                        {importFile && value.import.file.name? (
                          <i class="fa fa-close ml-5"></i>
                        ) : (
                          ""
                        )}
                      </a>
                    </span> */}
                  </div>
                  <label></label>
                  {/* {pageMode == "edit" ? (
                    <div className="custom-file align-self-end">
                      <input
                        type="file"
                        readOnly={pageMode !== "edit"}
                        name="pan.file"
                        class="custom-file-input"
                        id="validatedCustomFile"
                        onChange={(event) => {
                          if (importFile && value.import.file.name) {
                            message.error("please delete old file first");
                          } else {
                            value.import.file.name =
                              event.currentTarget.files[0].name;
                            setImportFile(value.import.file.name);
                          }
                        }}
                      />
                      <label class="custom-file-label" for="validatedCustomFile">
                        Choose file...
                    </label>
                    </div>
                  ) : (
                    ""
                  )} */}
                </div>
              }
              {panFile && value.pan.file.name &&
                <div class="col-md-4 d-flex flex-wrap mb-2">
                  <label className="w-100">Pan Card</label>
                  <div class="attach">
                    
                    <a target="_blank" href={`${API_BASE_URL_LIVE}file/${value?.pan.file.id}`}>{panFile ? value.pan.file.name : ""}</a>
                    {/* <span
                      onClick={() =>
                        pageMode == "edit" ? setPanFile(false) : ""
                      }
                    >
                      <a>
                        {panFile && value.pan.file.name ? (
                          <i class="fa fa-close ml-5"></i>
                        ) : (
                          ""
                        )}
                      </a>
                    </span> */}
                  </div>
                  <label></label>
                  {/* {pageMode == "edit" ? (
                    <div className="custom-file align-self-end">
                      <input
                        type="file"
                        readOnly={pageMode !== "edit"}
                        name="pan.file"
                        class="custom-file-input"
                        id="validatedCustomFile"
                        onChange={(event) => {
                          if (panFile && value.pan.file.name) {
                            message.error("please delete old file first");
                          } else {
                            value.pan.file.name =
                              event.currentTarget.files[0].name;
                            setPanFile(value.pan.file.name);
                          }
                        }}
                      />
                      <label class="custom-file-label" for="validatedCustomFile">
                        Choose file...
                    </label>
                    </div>
                  ) : (
                    ""
                  )} */}
                </div>
              }
              {aadharFile && value.aadhar.file.name &&
                <div class="col-md-4 d-flex flex-wrap mb-2">
                  <label className="w-100">Aadhar/UID Card</label>
                  <div class="attach">
                    <a target="_blank" href={`${API_BASE_URL_LIVE}file/${value?.aadhar.file.id}`}>{aadharFile ? value.aadhar.file.name : ""}</a>
                    {/* <span
                      onClick={() =>
                        pageMode == "edit" ? setaadharFile(false) : ""
                      }
                    >
                      {aadharFile && value.aadhar.file.name ? (
                        <a>
                          <i class="fa fa-close ml-5"></i>
                        </a>
                      ) : (
                        ""
                      )}
                    </span> */}
                  </div>
                  {/* {pageMode == "edit" ? (
                    <div className="custom-file align-self-end">
                      <input
                        type="file"
                        class="custom-file-input"
                        readOnly={pageMode !== "edit"}
                        id="validatedCustomFile"
                        name="aadhar.file"
                        onChange={(event) => {
                          if (aadharFile && value.aadhar.file.name) {
                            message.error("please delete old file first");
                          } else {
                            value.aadhar.file.name =
                              event.currentTarget.files[0].name;
                            setaadharFile(value.aadhar.file.name);
                          }
                        }}
                      />
                      <label class="custom-file-label" for="validatedCustomFile">
                        Choose file...
                    </label>
                    </div>
                  ) : (
                    ""
                  )} */}
                </div>
              }
              {gstinFile && value.gstin.file.name &&
                <div className="col-md-4 d-flex flex-wrap mb-2">
                  <label className="w-100">Certificate Of Incorporation</label>
                  <div class="attach">
                    <a target="_blank" href={`${API_BASE_URL_LIVE}file/${value?.gstin.file.id}`}>{gstinFile ? value.gstin.file.name : ""}</a>
                    {/* <span
                      onClick={() =>
                        pageMode == "edit" ? setgstinFile(false) : ""
                      }
                    >
                      {gstinFile && value.gstin.file.name ? (
                        <a>
                          <i class="fa fa-close ml-5"></i>
                        </a>
                      ) : (
                        ""
                      )}
                    </span> */}
                  </div>

                  {/* {pageMode == "edit" ? (
                    <div class="custom-file align-self-end">
                      <input
                        type="file"
                        class="custom-file-input"
                        id="validatedCustomFile"
                        readOnly={pageMode !== "edit"}
                        name="gstin.file"
                        onChange={(event) => {
                          if (gstinFile && value.gstin.file.name) {
                            message.error("please delete old file first");
                          } else {
                            value.gstin.file.name =
                              event.currentTarget.files[0].name;
                            setgstinFile(value.gstin.file.name);
                          }
                        }}
                      />
                      <label class="custom-file-label" for="validatedCustomFile">
                        Choose file...
                    </label>
                    </div>
                  ) : (
                    ""
                  )} */}
                </div>
              }
            </div>
          </div>
        </fieldset>
      </div>
    </fieldset>
  );
};

export default UserIdentityInfo;
