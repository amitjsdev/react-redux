import { Button, Table } from 'antd';
import React, { Component } from 'react';
import { connect } from 'react-redux';
import moment from 'moment'
import { Link } from 'react-router-dom';
import { Badge } from 'antd';
import DashboardLayout from "../Layout/DashboardLayout";
// import {updateUserUnreadNotification} from '../../store/actions/User'
import {
    // markNotificationsRead , markNotificationsUnRead,
    getNotification
} from '../AuthenticatedApp/store/redux/auth/Actions';
export class Notifications extends Component {
    state = {
        selectedNotificationRowKeys: [],
        notificationPerPage: 10,
        currentPage: 1,
    }
    componentDidMount() {
        this.props.getNotification(10000);
    }

    rowNotificationSelection = selectedNotificationRowKeys => {
        this.setState({ selectedNotificationRowKeys })
    }

    markNotificationsRead = () => {
        this.props.markNotificationsRead(this.state.selectedNotificationRowKeys);
        this.setState({
            selectedNotificationRowKeys: []
        })
    }

    markNotificationsUnRead = () => {
        this.props.markNotificationsUnRead(this.state.selectedNotificationRowKeys);
        this.setState({
            selectedNotificationRowKeys: []
        })
    }
  
    handlePaginationChanges = currentPage => {
        this.setState({ currentPage })
    }

    render(props) {

        let { data } = this.props;
        //console.log(data);
        const columns = [
            {
                title: 'Entity',
                key: 'type',
                dataIndex:'type',
                render: (text, record) => <Link to={record.type == 'user' ? `/user-detail/${record.id}`:`/trades/${record.id}`} >
                    <span className={` circle-${record.isRead ? 'read':'unread'}`}></span>
                    {text}</Link>
                



            },
            {
                title: 'Subject',
                key: 'subject',
                dataIndex:'subject',


            }, {
                title: 'Description',
                key: 'description',
                dataIndex:'content',

            },

            {
                title: 'Date',
                dataIndex: 'createdAt',
                key: 'createdAt',
                render:(date) =>moment(date).format('DD-MM-YYYY hh:mm:ss A').toString()

            }
        ];


        return (
            <div>
                <DashboardLayout>
                    <div class="page-inner">
                        <div class="container-fluid">
                            <div className="title-wrapper">
                                <div className="module-header" style={{margin:'20px 0'}}>
                                <span >Notifications</span> &nbsp;
                                <Badge count={data ? data.length : 0}>
                                
    </Badge>
                                  
                                </div>
                               
                            </div>
                            <div className="card mt-20">
                                <Table
                                    rowKey={record => record.id}
                                    className="notification-table"
                                    size="small"
                                    pagination={{ pageSize: 10, position: 'top', showTotal: (total, range) => `${range[0]}-${range[1]} of ${total}` }}
                                    columns={columns}
                                    dataSource={data}
                                    onChange={this.handleChange} />
                            </div>
                        </div>
                    </div>
                </DashboardLayout>
            </div>

        )
    }
}

const mapStateToProps = state => {
    return {
        data: state.auth.notification,
        loading: state.auth.loading,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        // markNotificationsRead: notifications => dispatch(markNotificationsRead(notifications)),
        // markNotificationsUnRead: notifications => dispatch(markNotificationsUnRead(notifications)),
        getNotification: notifications => dispatch(getNotification(notifications)),
        // updateUserUnreadNotification: notifications => dispatch(updateUserUnreadNotification()),

    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Notifications)