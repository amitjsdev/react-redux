import React, { useState } from "react";

const UserCommodityDetails = ({
  commodity,
  value,
  onChange,
  pageMode,
  onCancle,
  errors,
  setTempCommidity,
  tempCommidity,
}) => {

  const [values, setValues] = useState([])

  //console.log('setTempCommidity--', tempCommidity)

  const onChangeUpdate = (e) => {

    setTempCommidity([...tempCommidity, e])
  }

  return (
    <fieldset className="scheduler-border">
      <legend className="scheduler-border">Commodity Details</legend>
      <div className="form-row">
        {value.commodity &&
          value.commodity.length > 0 &&
          value.commodity.map((option) => {
            if (!tempCommidity.includes(option.Commodity.id)) {
              return (
                <div class="attach">
                  {option.Commodity.name}
                  <span>
                    <a onClick={() => { onChangeUpdate(option.Commodity.id) }} id={option.id} >
                      <i class="fa fa-close ml-2 mr-3"></i>
                    </a>
                  </span>
                </div>
              )
            }
          }
          )}

        {pageMode == "edit" ? (
          <div className="col-md-2 mb-2 text-sm-right pt-2">
            <label>Select Commodity</label>
          </div>
        ) : (
          ""
        )}
        {pageMode == "edit" ? (
          <div className="col-md-3 mb-2">
            <div className="input-group">
              <select onChange={onChange} className="form-control form-select">
                {commodity &&
                  commodity.length > 0 &&
                  commodity.map((item) => {
                    //console.log('items',item)
                    if (tempCommidity && tempCommidity.length > 0 && tempCommidity.includes(item.id)) {
                      return (

                        <option disabled={false} id={item.id}>{item.name}</option>
                      )
                    } else {
                      return (
                      <option disabled={value.commodity && value.commodity.find((val => val.Commodity.id == item.id)) ? true : false} id={item.id}>{item.name}</option>

                      )
                    }
                  }
                  )}
              </select>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </fieldset>
  );
};

export default UserCommodityDetails;
