import React, { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory,useLocation } from "react-router-dom";
import useTableActions from "../../hooks/useTableActions";
import useTableSearch from "../../hooks/useTableSearch";
import {
  acceptRequest,
  getUserList,
  rejectRequest,
} from "../AuthenticatedApp/store/redux/users/Actions";
import { Button, Form, Input, Modal, Space, Spin, Table, Radio } from "antd";

const NewUserRequest = () => {
  const pathname = useLocation().pathname;
  let users = useSelector((state) =>
    state.user && state.user.userlist ? state.user.userlist.data : null
  );
  const {
    columns,
    visible,
    type,
    userId,
    onCancel,
    onSubmit,
    setComment,
    postData,
    isUserDelete,
  } = useTableActions(users);
  const { search, filterTable } = useTableSearch(users);
  const [formRef, setFormRef] = useState(null);
  const [offset, setOffSet] = useState(0);
  const [limit, setLimit] = useState(500000);
  const [status, setStatus] = useState([3]);
  /*1- approved, 2- reject,3-pending */
  const [roles, setRoles] = useState([ 2, 3]);

  const dispatch = useDispatch();
  useEffect(() => {
    let payload;
    let value = localStorage.getItem("editRequest");
    if (value) {
      payload = { offset, roles, status };
    } else {
      payload = { limit, offset, roles, status };
    }
    dispatch(getUserList(payload));
  }, [isUserDelete, visible]);

  const [form] = Form.useForm();

  return (
    <div>
      <div class="card pl-0 pr-0 shadow-none">
        <div class="card-body dataTable-panel pb-0">
          <div class="row ml-0 mr-0">
            <div class="table-responsive">
              {/* <Modal
                visible={visible}
                title="Are you sure you want to approved this user ?"
                okText="Submit"
                cancelText="Cancel"
                onCancel={e=> {}}
                footer={[
                  <Button key="cancel">Cancel</Button>,
                  () => {
                      
                    form
                      .validateFields()
                      .then((values) => {
                        onSubmit(values);
                      })
                      .catch((info) => {
                        //console.log("Validate Failed:", info);
                      });
                  },
                  <Button
                    key="submit"
                    type="primary"
                    loading={postData.loading}
                    onClick={onSubmit}
                  >
                    Submit
                  </Button>,
                ]}
              >
                <Form
                  form={form}
                  layout="vertical"
                  name="form_in_modal"
                  initialValues={{
                    modifier: "public",
                  }}
                >
                  <Form.Item
                    label="Comments"
                    name="comments"
                    rules={[
                      {
                        required: true,
                        message: "This Field is required!",
                      },
                    ]}
                  >
                    <Input />
                  </Form.Item>

                  {postData.error && (
                    <>
                      <br />
                      <span style={{ color: "red" }}>{postData.data}</span>
                    </>
                  )}
                </Form>
              </Modal> */}
              <Modal
                visible={visible}
                title={
                  type == "reject"
                    ? "Are you sure you want to reject this user?"
                    : "Are you sure you want to approve this user?"
                }
                okText="Submit"
                cancelText="Cancel"
                onCancel={() => {
                    form.resetFields(); 
                    onCancel();}}
                onOk={() => {
                  form
                    .validateFields()
                    .then((values) => {
                      form.resetFields();
                      onSubmit();
                    })
                    .catch((info) => {
                      //console.log("Validate Failed:", info);
                    });
                }}
              >
                <Form
                  form={form}
                  layout="vertical"
                  name="form_in_modal"
                  initialValues={{
                    modifier: "public",
                  }}
                >
                  <Form.Item
                    name="comment"
                    label="Comments"
                    rules={[
                      {
                        required: true,
                        message: "Field is required",
                      },
                    ]}
                  >
                    <Input onChange={(e)=>{
                      setComment(e.target.value)
                    }}/>
                  </Form.Item>
                </Form>
              </Modal>
              {/* { pathname != '/' &&
              <Input.Search
                style={{ margin: "0 0 10px 0", width: "auto" }}
                placeholder="Search by..."
                enterButton
                onSearch={search}
              /> */}
                  
                <Table
                  className="table"
                  columns={columns}
                  pagination={{ pageSize: 5 }}
                  dataSource={filterTable == null ? users && users.rows : filterTable}
                />
            
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewUserRequest;
