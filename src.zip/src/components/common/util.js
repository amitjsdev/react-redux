import moment from 'moment'
export  const formattedDate =(date,el='')=>{
     date = moment(date);
    if(date.isValid()){
        return date.format('MMM DD,YYYY hh:mm:ss A').toString()
    }
    return el
}