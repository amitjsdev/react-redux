
import { useState } from "react";
import { Link,useLocation } from "react-router-dom";
import {connect} from 'react-redux'
import moment from 'moment'
import {doLogout} from '../AuthenticatedApp/store/redux/auth/Actions'
import images from "../../assets/images/images.jpg";
const Topbar = ({ onSidebarClick, toggle ,data,doLogout,notifications, newTrade, newUser}) => {
const pathname = useLocation().pathname;
    let total=data && data.earning && data.earning.total ? data.earning.total :0;
    let commision=data && data.earning && data.earning.commision ? data.earning.commision :0;
    const [show, setshow] = useState(false)
    const [notificationshow, setNotificationshow] = useState(false)
    const openDropdown = () => {
        setshow(!show)
    }
    const openNotificationDropdown = () => {
            setNotificationshow(!notificationshow)
        }

    const logout =(e) =>{
        e.preventDefault();
        doLogout()
    }

    const FromNow=({date})=>{
        date = moment(date).fromNow()
        
        return date
    }

    const totalNotification = newTrade+newUser
    const sliced = notifications && notifications.length >0  ? notifications.slice(0,3):[]
    return (
        <div className={`main-header ${toggle ? 'active' : ''}`} data-background-color="purple">

            <div className="logo-header">
                <a href="#" className="logo"><span className="brandName navbar-brand">Value Harvest</span></a>
                <button className="navbar-toggler sidenav-toggler ml-auto" type="button">
                    <span className="navbar-toggler-icon">
                        <i className="fa fa-bars"></i>
                    </span>
                </button>
                <div className="navbar-minimize">
                    <button className="btn btn-minimize btn-rounded" onClick={onSidebarClick}>
                        {
                            !toggle ? <i className="fa fa-bars"></i> :
                                <i className="fa fa-ellipsis-v"></i>
                        }
                    </button>
                </div>
            </div>

            <nav className="navbar navbar-header navbar-expand-lg">

                <div className="container-fluid">
                    <h2 className="font-weight-bold toph2">{pathname == '/user-management' ? 'User Management System' : 'Trade Management System'}</h2>
                    <div className="value">
                        <span>Total Trade Value: <span style={{ color: '#000' }}><span style={{color: 'red', fontSize: 16}}>{'\u20B9'} </span> {total.toFixed(2)}</span></span>
                        <span className="pipe">|</span>
                        <span>Total Earning Value: <span style={{ color: '#000' }}><span style={{color: 'red', fontSize: 16}}>{'\u20B9'} </span> {commision.toFixed(2)}</span></span>
                    </div>
                    <ul className="navbar-nav topbar-nav ml-md-auto align-items-center">
                        

                        <li className="nav-item dropdown hidden-caret" onClick={openNotificationDropdown}>
                            <a className="nav-link dropdown-toggle" href="#" id="notifDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i className="fa fa-bell"></i>
                                <span className="notification">{totalNotification}</span>
                            </a>
                            <ul className={`dropdown-menu notif-box animated fadeIn ${notificationshow ? 'show' : ''}`} aria-labelledby="notifDropdown">
                                <li>
                                    <div className="dropdown-title">You have {totalNotification} new notification</div>
                                </li>
                                <li>
                                    <div className="notif-center">
                                    {sliced && sliced.length > 0  ? sliced.map(noti=>
                                  
                                   <Link key={noti.id} to={noti.type == 'user' ? `/user-detail/${noti.id}`:`/trades/${noti.id}`} > <div className="notif-icon notif-success" style={{height:20, width:20}}> <i className="fa fa-comment"></i> </div>
                                   <div className="notif-content">
                                       <span className="block">
                                          {noti.subject}
                                   </span>
                                       <span className="time"><FromNow date={noti.createdAt} /></span>
                                   </div>
                                   </Link>
                                    ) : null}
                                
                                      
                                     
                                    </div>
                                </li>
                                <li>
                                    <Link className="see-all" to="/notifications">See all notifications<i className="fa fa-angle-right"></i> </Link>
                                </li>
                            </ul>
                        </li>

                        <li className="nav-item dropdown hidden-caret" onClick={openDropdown}>
                            <a className="dropdown-toggle profile-pic" data-toggle="dropdown" aria-expanded="false">
                                <div className="user">
                                    <div className="avatar-sm float-right mr-4">
                                        <img src={images} alt="" className="avatar-img rounded-circle" />
                                    </div>
                                    <a href="#">
                                        <span>Administrator</span>
                                    </a>

                                    <div className="userMenu">
                                        <a className="ellipse dropdown text-center" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                                            <i className="fa fa-ellipsis-v"></i>
                                        </a>

                                        <div className={`collapse profile-panel dropdown-menu animated fadeIn ${show ? 'show' : ''}`} aria-labelledby="dropdownMenuButton">
                                            <ul className="nav profile-list">
                                                <li>
                                                    <a href="profile.html">
                                                        <i className="fa fa-user pr-3"></i>My Profile
                                                </a>
                                                </li>

                                                <li className="pb-3">
                                                    <Link to="/logout" onClick={logout}>
                                                        <i className="fa fa-sign-out pr-3" aria-hidden="true"></i>Logout
                                                </Link>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </a>
                        </li>

                    </ul>
                </div>
            </nav>

        </div>
    )
}

const mapStateToProps = state => ({
    data: state.app.data,
    newTrade: state.auth.newTrade,
    newUser: state.auth.newUser,
    notifications: state.auth.notification
});

const mapDispatchToProps = dispatch => ({
    doLogout: () => dispatch(doLogout()),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Topbar);