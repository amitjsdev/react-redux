import React from "react";

const UserAddressInfo = ({ value, onChange, pageMode, errors }) => {
  return (
    <fieldset className="scheduler-border">
      <legend className="scheduler-border">Address Information</legend>
      <div className="address-one">
        <div className="form-row">
          <div className="col-md-3 mb-2">
            <label>Type of entity</label>
          </div>
          <div className="col-md-3 mb-2">
            <div className="input-group">
              <select
                className="form-control form-select"
                name="UserRole.entity"
                readOnly={pageMode !== "edit"}
                onChange={onChange}
                disabled={pageMode !== "edit"}
                value={value?.entity}
              >
               <option value="Individual" selected={value?.entity == 'Individual' ? true : false} >Individual</option>
                <option value="Partnership" selected={value?.entity == 'Partnership' ? true : false}>Partnership</option>
                <option value="Company" selected={value?.entity == 'Company' ? true : false}>Company</option>
              </select>
            </div>
          </div>
          <div className="col-md-3 mb-2 mt-2 text-sm-center">
            <label>User Type</label>
          </div>
          <div className="col-md-3 mb-2">
            <div className="input-group">
              <select
                name="UserRole.role"
                className="form-control"
                value={value.UserRole.role}
                readOnly={pageMode !== "edit"}
                onChange={onChange}
                disabled={pageMode !== "edit"}
              >
                <option value="buyer">
                  Buyer
                </option>
                <option value="seller">Seller</option>
              </select>
            </div>
          </div>
        </div>
        {value && !!value?.residential &&
        <fieldset className="scheduler-border">
          <legend className="scheduler-border">Residential Address</legend>
          <div className="address-container">
            <div className="form-row">
              <div className="col-md-4 mb-2">
                <label>Address 1</label>
                <input
                  type="text"
                  name="residential.address1"
                  value={value.residential.address1}
                  className="form-control"
                  placeholder=""
                  readOnly={pageMode !== "edit"}
                  onChange={onChange}
                />

                {/* {errors.residential.address1 ? <div  className="text-danger">{errors.residential.address1}</div> : null} */}
              </div>

              <div className="col-md-4 mb-2">
                <label>Address 2</label>
                <div className="input-group">
                  <input
                    type="text"
                    name="residential.address2"
                    value={value.residential.address2}
                    className="form-control"
                    placeholder=""
                    onChange={onChange}
                    readOnly={pageMode !== "edit"}
                  />
                  {/* {errors.residential.address2 ? <div  className="text-danger">{errors.residential.address2}</div> : null} */}
                </div>
              </div>

              <div className="col-md-4 mb-2">
                <label>City</label>
                <div className="input-group">
                  <input
                    type="text"
                    name="residential.city"
                    value={value.residential.city}
                    className="form-control"
                    placeholder=""
                    onChange={onChange}
                    readOnly={pageMode !== "edit"}
                  />
                </div>
                {/* {errors.residential.address2 ? <div  className="text-danger">{errors.residential.address2}</div> : null} */}
              </div>
              <div className="col-md-4 mb-2">
                <label>State</label>
                <div className="input-group">
                  <input
                    type="text"
                    name="residential.state"
                    value={value.residential.state}
                    className="form-control"
                    placeholder=""
                    onChange={onChange}
                    readOnly={pageMode !== "edit"}
                  />
                </div>
              </div>
              <div className="col-md-4 mb-2">
                <label>Zip Code</label>
                <input
                  type="text"
                  name="residential.zip"
                  value={value.residential.zip}
                  className="form-control"
                  placeholder=""
                  onChange={onChange}
                  readOnly={pageMode !== "edit"}
                />
                {errors && errors.zip2 ? (
                  <p className="text-danger">{errors.zip2}</p>
                ) : null}
              </div>

              <div className="col-md-4 mb-2">
                <label>Country</label>
                <div className="input-group">
                  <input
                    type="text"
                    name="residential.country"
                    value={value.residential.country}
                    onChange={onChange}
                    className="form-control"
                    placeholder=""
                    readOnly={pageMode !== "edit"}
                  />
                </div>
              </div>
            </div>
          </div>
        </fieldset>
       
                }
        <fieldset className="scheduler-border">
          <legend className="scheduler-border">Business Address</legend>
          <div className="form-row">
            <div className="col-md-4 mb-2">
              <label>Address 1</label>
              <input
                type="text"
                className="form-control"
                placeholder=""
                name="bussiness.address1"
                onChange={onChange}
                value={value.bussiness.address1}
                readOnly={pageMode !== "edit"}
              />
            </div>
            <div className="col-md-4 mb-2">
              <label>Address 2</label>
              <div className="input-group">
                <input
                  type="text"
                  placeholder=""
                  className="form-control"
                  name="bussiness.address2"
                  value={value.bussiness.address2}
                  onChange={onChange}
                  readOnly={pageMode !== "edit"}
                />
              </div>
            </div>
            <div className="col-md-4 mb-2">
              <label>City</label>
              <div className="input-group">
                <input
                  type="text"
                  name="bussiness.city"
                  value={value.bussiness.city}
                  className="form-control"
                  placeholder=""
                  onChange={onChange}
                  readOnly={pageMode !== "edit"}
                />
              </div>
            </div>
            <div className="col-md-4 mb-2">
              <label>State</label>
              <div className="input-group">
                <input
                  type="text"
                  name="bussiness.state"
                  value={value.bussiness.state}
                  className="form-control"
                  placeholder=""
                  onChange={onChange}
                  readOnly={pageMode !== "edit"}
                />
              </div>
            </div>
            <div className="col-md-4 mb-2">
              <label>Zip Code</label>
              <div className="input-group">
                <input
                  type="text"
                  name="bussiness.zip"
                  value={value.bussiness.zip}
                  className="form-control"
                  placeholder=""
                  onChange={onChange}
                  readOnly={pageMode !== "edit"}
                />
              </div>
              {errors && errors.zip ? (
                <p className="text-danger">{errors.zip}</p>
              ) : null}
            </div>

            <div className="col-md-4 mb-2">
              <label>Country</label>
              <div className="input-group">
                <input
                  type="text"
                  name="bussiness.country"
                  value={value.bussiness.country}
                  className="form-control"
                  placeholder=""
                  onChange={onChange}
                  readOnly={pageMode !== "edit"}
                />
              </div>
            </div>
          </div>
        </fieldset>
      </div>
    </fieldset>
  );
};

export default UserAddressInfo;
