import React from 'react';
import { Pie } from '@ant-design/charts';

const DashboardGraph = ({data, type,color}) => {
    
    let count = 0;
    let records =data && data[type] && data[type].length > 0 ? data[type]:[]
    if (records && records.length > 0) {
        records =records.filter(datum=>datum.statusStr)
        records =records.map(datum=>{
            return {
                type:datum.statusStr,
                value:datum.count
            }
        })
       
    }
    

    var config = {
        appendPadding: 10,
        data: records,
        angleField: 'value',
        colorField: 'type',
        color,
        radius: 1,
        innerRadius: 0.3,
        label: {
            type: 'inner',
            offset: '-50%',
            content: '{value}',
            style: {
                textAlign: 'center',
                fontSize: 14,
            },
        },
        legend: {
            // layout: "vertical",
            position: 'bottom',
        },
        interactions: [{ type: 'element-selected' }, { type: 'element-active' }],
        statistic: {
            title: false,
            content: {
                style: {
                    whiteSpace: 'pre-wrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                },
                formatter: function formatter() {
                    return count;
                },
            },
        },
    };
    return <Pie {...config} height={280} width={280} />;
};

export default DashboardGraph;