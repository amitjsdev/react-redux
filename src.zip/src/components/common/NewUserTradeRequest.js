import { Button, Form, Input, Modal, Space, Spin, Table } from "antd";
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector, connect } from 'react-redux';

import useTableActionsForTrade from '../../hooks/useTableActionsForTrade';
import { getUserTradeList } from '../AuthenticatedApp/store/redux/trades/Actions';
import useTableSearch from "../../hooks/useTableSearch";
import moment from 'moment';

const NewUserTradeRequest = (props) => {
    // let trade = useSelector(state => state.trades && state.trades.data.length > 0  ? state.trades : []);
    let trade = props.data?.usertradelist?.data
    const { setComment, columns1, visible, type, userId, onSubmit, onCancel, postData, isUserDelete } = useTableActionsForTrade(trade);
    //const { search, filterTable } = useTableActionsForTrade(trade);

    const [formRef, setFormRef] = useState(null);
    const [offset, setOffSet] = useState(0);
    const [limit, setLimit] = useState(50000);
    const [status, setStatus] = useState([1]);
    /*1- approved, 2- reject,3-pending */
    const [roles, setRoles] = useState([2, 3]);
    const dispatch = useDispatch();
    const [filterTable, setfilterTable] = useState([]);
    useEffect(() => {
        const payload = ({ limit, offset, roles, status });
        props.getUserTradeList(payload)

    }, []);

    const [form] = Form.useForm();
    const search = (value) => {
        const data = trade && trade.data.length > 0 ? trade.data : [];
        const filterTablesData = data.filter(o =>
            o.commodity?.name.toLowerCase().includes(value.toLowerCase()) ||
            o.description.toLowerCase().includes(value.toLowerCase()) ||
            (o.quantity == value) ||
            o.CreatedUser?.first_name.toLowerCase().includes(value.toLowerCase()) ||
            o.UserRole?.role.toLowerCase().includes(value.toLowerCase()) ||
            moment(o.createdAt).format(
                "MMM DD, YYYY h:mm:ss"
            ).toLowerCase().includes(value.toLowerCase()) ||
            moment(o.broadcastDate).format(
                "MMM DD, YYYY h:mm:ss"
            ).toLowerCase().includes(value.toLowerCase()) ||
            (o.status == value) ||
            (o.id == value)

        );
        //console.log('filterTables',data,filterTablesData)
        setfilterTable(filterTablesData);
    };
    return (
        <div>
            <div class="card pl-0 pr-0 shadow-none">
                <div class="card-body dataTable-panel pb-0">
                    <div class="row ml-0 mr-0">
                        <div class="table-responsive">
                        <Modal
                visible={visible}
                title={
                  type == "reject"
                    ? "Are you sure you want to reject this trade ?"
                    : "Are you sure you want to approve this trade ?"
                }
                okText="Submit"
                cancelText="Cancel"
                onCancel={() => {
                    form.resetFields(); 
                    onCancel();}}
                onOk={() => {
                  form
                    .validateFields()
                    .then((values) => {
                      form.resetFields();
                      onSubmit();
                    })
                    .catch((info) => {
                      //console.log("Validate Failed:", info);
                    });
                }}
              >
                <Form
                  form={form}
                  layout="vertical"
                  name="form_in_modal"
                  initialValues={{
                    modifier: "public",
                  }}
                >
                  <Form.Item
                    name="comment"
                    label="Comments"
                    rules={[
                      {
                        required: true,
                        message: "Field is required",
                      },
                    ]}
                  >
                    <Input onChange={(e)=>{
                      setComment(e.target.value)
                    }}/>
                  </Form.Item>
                </Form>
              </Modal>
                            <Input.Search
                                style={{ margin: "0 0 10px 0", width: "auto" }}
                                placeholder="Search by..."
                                enterButton
                                onSearch={search}
                            />
                            {

                                <Table className="table" columns={columns1} dataSource={filterTable && filterTable.length == 0 ? trade && trade.data && trade.data.length > 0 && trade.data : filterTable}
                                    pagination={{ pageSize: 5 }}
                                />
                                // tradeList && tradeList.data && tradeList.data.data.length > 0 ?
                                //     (<Table className="table" columns={columns1} dataSource={filterTable == null ? tradeList.data.data : filterTable}  />) :
                                //      <div style={{ textAlign: "center" }}>NO DATA FOUND</div> 

                            }

                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

const mapStateToProps = state => ({
    loading: state.trades.loading,
    loaded: state.trades.loaded,
    error: state.trades.error,
    // commodities: state.masterdata.commodities,
    app: state.app.data,
    data: state.trades,
    count: state.trades.count
});

const mapDispatchToProps = dispatch => ({
    getUserTradeList: (payload) => dispatch(getUserTradeList(payload)),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(NewUserTradeRequest);

