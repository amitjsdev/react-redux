import { Link,useLocation } from "react-router-dom";
import React, {useEffect, useState} from "react";
import { Badge} from 'antd';
import { API_BASE_URL_LIVE } from "../../config/constants";
import axios from 'axios';
import {
  // markNotificationsRead , markNotificationsUnRead,
  getNotification
} from '../AuthenticatedApp/store/redux/auth/Actions';
import { connect,useSelector } from 'react-redux'
const Sidebar = ({ toggle, onSidebarHover,newUser, newTrade,getNotification }) => {
  const search = useLocation().search;
  const activeKey = new URLSearchParams(search).get("list");
  const [active, setactive] = useState(activeKey);
  const [newUserRequest, setNewUserRequest] = useState(0);
  const [newTradeRequest, setNewTradeRequest] = useState(0);
  let users = useSelector((state) =>
  state.user && state.user.userlist ? state.user.userlist.data : null
);
  const menuToggle = () => {
      setactive(!active);
    }

  useEffect(() => {
  getNotification();
  }, []);
  return (
    <>
      <div
        className={`sidebar ${toggle ? "active" : ""}`}
        onMouseEnter={onSidebarHover}
      >
        <div className="sidebar-content">
          <ul className="nav" id="sidebarNav">
            <li className="nav-item">
              <Link
                to="/"
                onClick={(e) => localStorage.removeItem("editRequest")}
              >
                <i className="preview fa fa-tv"></i>
                <p>Dashboard</p>
              </Link>
            </li>
            <li className="nav-item">
              <Link onClick={menuToggle}>
                <i class="fa fa-tasks"></i>
                <p>Task List &nbsp;</p>
                <span class="fa fa-angle-down"></span>
              </Link>
              <div className={`menu`}>
                <ul class="nav nav-collapse">
                  <li class="">
                    <Link to="/new-user-request?activeKey=1">
                      <span class="sub-item">New User Request</span>
                      <span class="number-count">{newUser}</span>
                    </Link>
                  </li>

                  <li>
                    <Link to="/new-trade-request?activeKey=2">
                      <span class="sub-item">New Trading Request</span>
                      <span class="number-count">{newTrade}</span>
                      {/* <Badge count={newTrade} size="small" /> */}
                    </Link>
                  </li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <Link to="/user-management">
                <i class="preview fa fa-user"></i>
                <p>User Management</p>
              </Link>
            </li>
            <li class="nav-item">
              <Link to="/trades">
                <i class="preview fa fa-line-chart"></i>
                <p>Trade Management</p>
              </Link>
            </li>
            <li class="nav-item">
              <Link to="/commodity">
                <i class="preview fa fa fa-inr"></i>
                <p>Item Price List</p>
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};


const mapStateToProps = state => ({
  newTrade: state.auth.newTrade,
  newUser: state.auth.newUser
});

const mapDispatchToProps = dispatch => ({
  getNotification: () => dispatch(getNotification()),
});
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Sidebar);
