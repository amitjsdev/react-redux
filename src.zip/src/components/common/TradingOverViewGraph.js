import React from "react";
import { Pie } from "@ant-design/charts";

const TradingOverViewGraph = ({data,color}) => {
  const type ='earning'
  let count =0;
  let records =[]
  if(data && Object.keys(data) && Object.keys(data).length > 0 ){
    records = Object.keys(data).map(el=>{
      return {
        type:el,
        // value:data[el] ? data[el].toFixed(2):0
        value:data && el && data[el]? parseFloat(data[el].toFixed(2)):0
      }
    })
  }
  //console.log({records});
  
  
  var config = {
    appendPadding: 10,
    data: records,
    angleField: "value",
    colorField: "type",
    color:color,
    radius: 1,
    innerRadius: 0.3,
    label: {
      type: "inner",
      offset: "-50%",
      content: "{value}",
      style: {
        textAlign: "center",
        fontSize: 14,
      },
    },
    legend: {
      // layout: "vertical",
      position: "bottom",
    },
    interactions: [{ type: "element-selected" }, { type: "element-active" }],
    statistic: {
      title: false,
      content: {
        style: {
          whiteSpace: "pre-wrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
        },
        formatter: function formatter() {
          return count;
        },
      },
    },
  };
  return <Pie {...config} height={280} width={280} />;
};
export default TradingOverViewGraph;
