import React from 'react'

const UserGeoLocation = ({ value, onChange, pageMode ,errors  }) => {
    return (
        <fieldset className="scheduler-border">
            <legend className="scheduler-border">Geo Location</legend>
            <div className="form-row">
                <div className="col-md-3 mb-2">
                    <label >Latitude</label>
                    <input type="text" name="latlng.lat" value={value.latlng.lat} className="form-control" placeholder="45°N"onChange={onChange} readOnly/>
                </div>
                <div className="col-md-3 mb-2">
                    <label >Longitude</label>
                    <input type="text"name="latlng.lng" value={value.latlng.lng}  className="form-control" placeholder="0°" onChange={onChange} readOnly/>
                </div>
                {/* <div className="col-md-6 mb-2">
                    <label>Geo Location Address</label>
                    <div className="input-group">
                        <input type="text" name="latlng.address1" value={value.latlng.address1} className="form-control" placeholder="Geo location Address"onChange={onChange} readOnly/>
                    </div>
                </div> */}
            </div>
        </fieldset>
    )
}

export default UserGeoLocation
