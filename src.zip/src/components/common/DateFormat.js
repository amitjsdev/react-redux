
import moment from 'moment'
 const DateFormat =({date,el=''})=>{
     date = moment(date);
    if(date.isValid()){
        return date.format('MMM DD,YYYY hh:mm:ss').toString()
    }
    return el
}
export default DateFormat