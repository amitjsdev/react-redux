import React from "react";

const UserPersonalInfo = ({ value, onChange, pageMode ,errors}) => {
  return (
    <fieldset className="scheduler-border">
      <legend className="scheduler-border">Personal Information</legend>
      <div className="form-row">
        <div className="col-md-3 mb-2">
          <label>First Name</label>
          <input
            type="text"
            name="first_name"
            onChange={onChange}
            value={value.first_name}
            placeholder=""
            className="form-control"
            readOnly={pageMode !== 'edit'}
          />
           
         {errors.first_name ? (
            <p className="text-danger">{errors.first_name}</p>
          ) : null} 
        </div>
        <div className="col-md-3 mb-2">
          <label>Last Name</label>
          <input
            type="text"
            name="last_name"
            onChange={onChange}
            value={value.last_name}
            placeholder=""
            className="form-control"
            readOnly={pageMode !== 'edit'}
          />
         {errors.last_name ? (
            <p className="text-danger">{errors.last_name}</p>
          ) : null} 
        </div>
        <div className="col-md-3 mb-2">
          <label>Email ID</label>
          <div className="input-group">
            <input
              type="text"
              name="email"
              value={value.email}
              placeholder=""
              className="form-control"
              onChange={onChange}
              readOnly={pageMode !== 'edit'}
            />
          </div>
          {errors.email ? (
            <p className="text-danger">{errors.email}</p>
          ) : null} 
        </div>
        <div className="col-md-3 mb-2">
          <label>Mobile Number</label>
          <div className="input-group">
            <input
              type="text"
              name="mobile"
              value={value.mobile}
              id="validationDefault01"
              placeholder=""
              className="form-control"
              onChange={onChange}
              readOnly={pageMode !== 'edit'}
            />
          </div>
          {errors.mobile ? (
            <p className="text-danger">{errors.mobile}</p>
          ) : null} 
        </div>
      </div>
    </fieldset>
  );
};

export default UserPersonalInfo;
