//export const API_BASE_URL_LIVE = "http://139.59.74.137:8003/api/v1.0/";
// export const API_BASE_URL_LIVE = "http://localhost:8003/";
export const API_BASE_URL_LIVE = `${process.env.REACT_APP_API_URL}`


export const checkResponse = (response) => {
  let newResponse;
  if (response.status === 200) {
    newResponse = {
      success: true,
      data: response.data.data ? response.data.data : "",
      message: response.data.message
    };
  } else {
    newResponse = {
      success: false,
      error: response.data.error
    };
  }
  return newResponse;
};
