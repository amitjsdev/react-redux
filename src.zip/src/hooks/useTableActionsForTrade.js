import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Link, useHistory } from "react-router-dom";
import DateFormat from '../components/common/DateFormat'
import TradeStatus from '../components/pages/tradeManagement/TradeStatus';
import { acceptTradeRequest, rejectTradeRequest } from '../components/AuthenticatedApp/store/redux/trades/Actions';
import moment from 'moment';
const useTableActionsForTrade = () => {
    const [userId, setUserId] = useState();
    const [userVisible, setVisibleforReject] = useState();
    const [visible, setVisible] = React.useState(false);
    const [type, setType] = useState();
    const [isUserDelete, setisUserDelete] = useState(false)
    const [comment,setComment] = useState();

    const [postData, setPostData] = useState({
        loading: false,
        error: false,
        data: []
    });
    let history = useHistory();
    const dispatch = useDispatch();

    const handleRejectrequest = (id, type) => {
        setUserId(id);
        setVisible(true);
        setType(type)

    }
    const handleAcceptReject = (id, type) => {
        setUserId(id);
        setVisible(true);
        setType(type)
    }

    const onSubmit = () => {
        setPostData({ ...postData, loading: true, error: false });
        if (type === 'reject') {
            setPostData({ ...postData, loading: false, error: false });
            dispatch(rejectTradeRequest(userId,comment,history));
            setVisible(false);
            //console.log(isUserDelete)
            // const payload = ({ limit, offset, roles, status });
            // dispatch(getUserList(payload));
        }
        else if (type === 'approved') {
            setPostData({ ...postData, loading: false, error: false });
           dispatch(acceptTradeRequest(userId,comment,history));
            setVisible(false);
        }
        setisUserDelete(!isUserDelete)
    };

    const onCancel = () => {
        setVisible(false);
    }

    const handleView = (id) => {
        history.push("/user-trade-detail/" + id)
    }

    const columns1 = [
        {
            title: 'Sr.No',
            dataIndex: 'id',
            key: 'id'
        },
        {
            title: 'Commodity',
            dataIndex: 'commodity',
            key: 'commodity',
            render: (item) => {
                return item.name;
            }
        },
        {
            title: 'Title',
            dataIndex: 'title',
            key: 'title'
        },
        // {
        //     title: 'Description',
        //     dataIndex: 'description',
        //     key: 'description',
        // },
        {
            title: 'Qty',
            dataIndex: 'quantity',
            key: 'quantity',
            render: (qty, record) => `${qty} ${record?.unit?.name}`
        },
        {
            title: 'Created By',
            dataIndex: 'CreatedUser',
            key: 'CreatedUser',
            render: (item) => {
                return item.first_name;
            }
        },
        {
            title: 'Create Date',
            dataIndex: 'createdAt',
            key: 'createdAt',
            render: date => <DateFormat date={date} />
        },
        {
            title: 'Expected Live Date',
            dataIndex: 'broadcastDate',
            key: 'broadcastDate',
            render: date => <DateFormat date={date} el="N/A" />
        },
        {
            title: 'Closure Date',
            dataIndex: 'closeDate',
            key: 'closeDate',
            render: date => <DateFormat date={date} el="N/A" />
        },

        {
            title: 'Status',
            className: 'statusRow',
            key: 'status',
            dataIndex: 'statusStr',
            render: (item) => {
                return <TradeStatus st={item} />;
            }
        },
        {
            title: 'Action',
            key: 'action',
            render: (item) =>

            (
                <ul class="list">
                    <li><Link title="Rejected" onClick={() => handleRejectrequest(item.id,'reject')}><i class="fa fa-times-circle-o reject" aria-hidden="true"></i></Link></li>

                    <li><Link title="Approved" onClick={() => {
                        handleAcceptReject(item.id,'approved');
                    }}><i class="fa fa-check-circle-o approve" aria-hidden="true"></i></Link></li>

                    <li><Link title="View" onClick={() => {
                        handleView(item.id);
                    }}><i class="fa fa-eye"></i></Link></li>
                </ul>
            ),
        },
    ];

    return   { columns1,setComment, visible, type, userId, onSubmit, onCancel, postData, isUserDelete };
}

export default useTableActionsForTrade
