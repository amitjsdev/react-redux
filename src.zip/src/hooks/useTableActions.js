import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Link, useHistory } from "react-router-dom";
import { acceptRequest, rejectRequest } from '../components/AuthenticatedApp/store/redux/users/Actions';
import moment from 'moment';

const useTableActions = () => {
    const [comment, setComment] = useState();
    const [userId, setUserId] = useState();
    const [userVisible, setVisibleforReject] = useState();
    const [visible, setVisible] = React.useState(false);
    const [type, setType] = useState();
    const [isUserDelete, setisUserDelete] = useState(false)
    const [postData, setPostData] = useState({
        loading: false,
        error: false,
        data: []
    });
    let history = useHistory();
    const dispatch = useDispatch();

    const handleRejectrequest = (id, type) => {
        setUserId(id);
        setVisible(true);
        setType(type)

    }
    const handleAcceptReject = (id, type) => {
        setUserId(id);
        setVisible(true);
        setType(type)
    }
    const handleView = (id) => {
        history.push("/user-detail/" + id)
        localStorage.removeItem('edit');
    }

    const onSubmit = () => {
        setPostData({ ...postData, loading: true, error: false });
        if (type === 'reject') {
            setPostData({ ...postData, loading: false, error: false });
            dispatch(rejectRequest(userId,comment,history));
            setVisible(false);
            //console.log(isUserDelete)
            // const payload = ({ limit, offset, roles, status });
            // dispatch(getUserList(payload));
        }
        else if (type === 'approved') {
            setPostData({ ...postData, loading: false, error: false });
            dispatch(acceptRequest(userId,comment,history));
            setVisible(false);
        }
        setisUserDelete(!isUserDelete)
    };

    const onCancel = () => {
        setVisible(false);
    }


    const columns = [
        {
            title: 'ID',
            dataIndex: 'id',
            key: 'id',
            render: text => <a>{text}</a>,
        },
        {
            title: 'User Type',
            dataIndex: ['UserRole','role'],
            key: 'userName',
            render: text => <a>{text}</a>,
        },
        {
            title: 'First Name',
            dataIndex: 'first_name',
            key: 'first_name',
        },
        {
            title: 'Last Name',
            dataIndex: 'last_name',
            key: 'last',
        },
        {
            title: 'Mobile Number',
            dataIndex: 'mobile',
            key: 'mobile',
        },
        {
            title: 'City',
            dataIndex: ['bAddress','cityName'],
            key: 'cityName',
            render:(item)=>{
                return item ? item : 'N/A'; 
            }
        },
        {
            title: 'Country',
            dataIndex: ['bAddress','countryName'],
            key: 'countryName',
            render:(item)=>{
                return item ? item : 'N/A'; 
            }
        },
        {
            title: 'Created Date',
            dataIndex: 'createdAt',
            key: 'createdAt',
            render:(item)=>{
                return moment(item).format(
                    "MMM DD, YYYY h:mm:ss"
                  )
              
            }
        },

        {
            title: 'Status',
            key: 'statusStr',
            dataIndex: 'statusStr',
            render: (statusStr) =>

            (
                <>
                    <span className={`${statusStr.toLowerCase()} status`}  >{statusStr}</span>

                </>
            ),
        },
        {
            title: 'Action',
            key: 'action',
            render: (item, record) =>

            (
                <ul class="list">
                    <li><Link title="Rejected" onClick={() => handleRejectrequest(item.id, 'reject')}><i class="fa fa-times-circle-o reject" aria-hidden="true"></i></Link></li>

                    <li><Link title="Approved" onClick={() => {
                        handleAcceptReject(item.id, 'approved');
                    }}><i class="fa fa-check-circle-o approve" aria-hidden="true"></i></Link></li>

                    <li><Link title="View" onClick={() => {
                        handleView(item.id);
                    }}><i class="fa fa-eye"></i></Link></li>
                </ul>
            ),
        },
    ];
    return { columns, visible, type, userId, onSubmit,onCancel, postData, isUserDelete,setComment };
}

export default useTableActions
