import { useState } from 'react';
import moment from 'moment';
const useTableSearch = (users) => {
    const [filterTable, setfilterTable] = useState();
    const search = (value) => {
        const data = users.rows || users.data ;
        const filterTables = data.filter(o =>
                   o.full_name.toLowerCase().includes(value.toLowerCase()) ||
                   o.bAddress?.cityName.toLowerCase().includes(value.toLowerCase()) ||
                   o.bAddress?.countryName.toLowerCase().includes(value.toLowerCase()) ||
                   o.UserRole?.role.toLowerCase().includes(value.toLowerCase()) ||
                   (moment(o.createdAt).format(
                    "MMM DD, YYYY h:mm:ss"
                  ) ==  value)  ||
                  moment(o.createdAt).format(
                    "MMM DD, YYYY h:mm:ss"
                  ).toLowerCase().includes(value.toLowerCase()) ||
                   o.statusStr.includes(value.toLowerCase()) ||
                   (o.id == value) 
            
        );
        setfilterTable(filterTables);
    };
    return { filterTable, search };
}

export default useTableSearch
