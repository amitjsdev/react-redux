import React, { useState } from 'react';
import { buyCake } from '../Redux/index';
import {connect} from 'react-redux';

function NewCakeContainer(props){
    const [number,setNumber] = useState(1)
    console.log("numOfCakes",props)
    return(
        <div>
            <h2>Number of cake - {props.numOfCakes}</h2>
            <input type="text" value={number} onChange={e => setNumber(e.target.value)}/>
            <button onClick={()=> props.buyCake(number)}>Buy Cake</button>
        </div>
    )
}

const mapStateToProps = state => {
    console.log("stateCake",state)
    return {
        numOfCakes: state.cake.numOfCakes
    }
}

const mapDispatchToProps = dispatch => {
    return {
        buyCake: number => dispatch(buyCake(number))
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(NewCakeContainer);