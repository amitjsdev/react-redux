import React from 'react';
import { buyIcream } from '../Redux/index';
import {connect} from 'react-redux';

function IceCreamContainer(props){
    console.log("IceCreamContainer",props)
    return(
        <div>
            <h2>Number of cake - {props.numOfIceCreams}</h2>
            <button onClick={props.buyIcream}>Buy buyIcream</button>
        </div>
    )
}

const mapStateToProps = state => {
    return {
        numOfIceCreams: state.iceCream.numOfIceCreams
    }
}

const mapDispatchToProps = dispatch => {
    return {
        buyIcream: () => dispatch(buyIcream())
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(IceCreamContainer);