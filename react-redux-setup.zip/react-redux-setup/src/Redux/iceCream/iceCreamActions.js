import { BUY_ICECREAM } from  './iceCreamTypes';


export const buyIcream = () => {
    return {
        type: BUY_ICECREAM
    }
}